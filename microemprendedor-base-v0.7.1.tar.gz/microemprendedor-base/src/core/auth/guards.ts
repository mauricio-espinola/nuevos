import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/core/auth/current-user'
import type { AppRole } from '@/core/auth/session'

export async function requireAuthenticated() {
  const user = await getCurrentUser()

  if (!user?.id) {
    redirect('/es/login')
  }

  return user
}

export async function requireRole(roles: AppRole[]) {
  const user = await requireAuthenticated()
  if (!roles.includes(user.role)) {
    redirect('/es/dashboard?denied=role')
  }
  return user
}
