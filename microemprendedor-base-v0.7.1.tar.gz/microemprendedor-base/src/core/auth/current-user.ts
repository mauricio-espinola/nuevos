import { cookies } from 'next/headers'
import { prisma } from '@/server/db/prisma'
import { authCookieName, decodeSessionToken, hashSessionToken } from '@/core/auth/session'

export async function getCurrentUser() {
  const cookieStore = await cookies()
  const token = cookieStore.get(authCookieName)?.value
  if (!token) return null

  const payload = await decodeSessionToken(token)
  if (!payload?.sub) return null

  const session = await prisma.session.findUnique({
    where: { tokenHash: hashSessionToken(token) },
    select: { id: true, status: true, expiresAt: true, userId: true }
  })

  if (!session || session.status !== 'ACTIVE' || session.expiresAt <= new Date()) {
    return null
  }

  const user = await prisma.user.findUnique({
    where: { id: payload.sub },
    select: {
      id: true,
      email: true,
      name: true,
      role: true,
      status: true,
      avatar: true,
      company: true,
      position: true,
      createdAt: true,
      lastLoginAt: true,
    }
  })

  return user
}
