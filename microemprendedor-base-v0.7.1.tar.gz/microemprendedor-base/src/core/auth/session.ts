import { SignJWT, jwtVerify } from 'jose'
import { createHash } from 'node:crypto'
import { env } from '@/lib/env'

export type AppRole = 'USER' | 'ADMIN' | 'SUPER_ADMIN'

export type SessionPayload = {
  sub: string
  email: string
  role: AppRole
  displayName?: string
  sid?: string
}

export const authCookieName = env.AUTH_SESSION_COOKIE

const authCookieMaxAgeSeconds = 60 * 60 * 24 * 7 // 7 días

/**
 * Codifica el secret JWT a bytes. `env.AUTH_JWT_SECRET` ya fue validado
 * al arrancar (mínimo 32 chars), así que acá no necesitamos fallbacks.
 */
function getJwtSecret() {
  return new TextEncoder().encode(env.AUTH_JWT_SECRET)
}

export async function issueSessionToken(payload: SessionPayload) {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${authCookieMaxAgeSeconds}s`)
    .sign(getJwtSecret())
}

export async function decodeSessionToken(
  token: string
): Promise<SessionPayload | null> {
  try {
    const verified = await jwtVerify(token, getJwtSecret())
    return verified.payload as SessionPayload
  } catch {
    return null
  }
}

export function hashSessionToken(token: string) {
  return createHash('sha256').update(token).digest('hex')
}

export function getSessionCookieOptions() {
  return {
    name: authCookieName,
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: env.NODE_ENV === 'production',
    path: '/',
    maxAge: authCookieMaxAgeSeconds,
  }
}
