import { log } from '@/core/logger/logger';

export function registerMonitoring() {
  log('info', 'Monitoring initialized');
}
