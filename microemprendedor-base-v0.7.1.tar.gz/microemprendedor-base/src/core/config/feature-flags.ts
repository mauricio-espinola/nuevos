import { prisma } from '@/server/db/prisma'

export async function isFeatureEnabled(key: string) {
  const feature = await prisma.featureFlag.findUnique({ where: { key } })
  return feature?.state === 'ENABLED'
}
