import { env } from '@/lib/env'

/**
 * Re-export de variables NEXT_PUBLIC_* ya validadas.
 *
 * Mantiene la API anterior (`publicEnv.appName`) funcionando,
 * pero apunta al env validado con Zod.
 */
export const publicEnv = {
  appName: env.NEXT_PUBLIC_APP_NAME,
  appUrl: env.NEXT_PUBLIC_APP_URL,
}
