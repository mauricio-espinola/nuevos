/**
 * Fuente única de verdad para permisos y matriz de roles.
 *
 * Este archivo es importado tanto por:
 * - La app Next.js (para chequeos de permisos en runtime)
 * - El seed de Prisma (para poblar la DB inicialmente)
 *
 * Agregar/modificar permisos SIEMPRE aquí, nunca hardcoded en otros lugares.
 *
 * Nota: el seed importa este archivo con path relativo porque corre fuera
 * del runtime de Next.js y no tiene acceso al alias `@/*`.
 */

// ============================================================================
// Catálogo de permisos
// ============================================================================
export const permissionCatalog = {
  'platform.access': 'Ingresar al portal privado',
  'dashboard.read': 'Ver dashboard',
  'admin.access': 'Ingresar al panel admin',
  'users.manage': 'Administrar usuarios',
  'users.promote': 'Promover usuarios a ADMIN',
  'settings.manage': 'Administrar configuración del sistema',
  'articles.read': 'Leer artículos',
  'articles.write': 'Crear y editar artículos',
  'articles.publish': 'Publicar artículos',
  'feature-flags.manage': 'Administrar feature flags',
  'audit.read': 'Consultar logs de auditoría',
  'billing.read': 'Ver suscripciones y facturación',
  'billing.manage': 'Administrar cobros y estados de pago',
} as const

export type PermissionCode = keyof typeof permissionCatalog

// ============================================================================
// Matriz de roles: qué permisos tiene cada rol.
//
// Principio aplicado: menor privilegio.
// SUPER_ADMIN es el único que puede promover otros usuarios a ADMIN.
// ADMIN puede gestionar usuarios normales y contenido, pero no cambiar
// roles administrativos ni manejar feature flags críticos del sistema.
// ============================================================================
export const roleMatrix: Record<
  'USER' | 'ADMIN' | 'SUPER_ADMIN',
  PermissionCode[]
> = {
  USER: ['platform.access', 'dashboard.read', 'articles.read'],
  ADMIN: [
    'platform.access',
    'dashboard.read',
    'admin.access',
    'users.manage',
    'articles.read',
    'articles.write',
    'articles.publish',
    'audit.read',
    'billing.read',
  ],
  SUPER_ADMIN: [
    'platform.access',
    'dashboard.read',
    'admin.access',
    'users.manage',
    'users.promote',
    'settings.manage',
    'articles.read',
    'articles.write',
    'articles.publish',
    'feature-flags.manage',
    'audit.read',
    'billing.read',
    'billing.manage',
  ],
}

// ============================================================================
// Nombres amigables de roles (usados en UI y seed)
// ============================================================================
export const roleDisplayNames: Record<'USER' | 'ADMIN' | 'SUPER_ADMIN', string> =
  {
    USER: 'Usuario',
    ADMIN: 'Administrador',
    SUPER_ADMIN: 'Super administrador',
  }
