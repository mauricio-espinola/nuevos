export async function createCheckoutIntent() {
  return { status: 'placeholder', provider: 'stripe' } as const;
}
