export async function getDashboardSummary() {
  return {
    activeUsers: 1280,
    completionRate: 84,
    openTasks: 19,
    conversionRate: 5.4,
  };
}
