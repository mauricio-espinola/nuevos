import { getDashboardSummary } from '@/server/dal/dashboard';

export async function buildDashboardViewModel() {
  const summary = await getDashboardSummary();
  return {
    hero: {
      title: 'Operational Dashboard',
      description: 'Vista ejecutiva para coordinar crecimiento, operación y adopción.',
    },
    summary,
  };
}
