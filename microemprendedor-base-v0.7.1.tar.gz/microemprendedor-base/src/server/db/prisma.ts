import { PrismaClient } from '@prisma/client'
import { env } from '@/lib/env'

/**
 * Cliente Prisma singleton.
 *
 * En development Next.js hace hot-reload, lo que podría crear múltiples
 * instancias de PrismaClient y agotar el pool de conexiones. Guardamos la
 * instancia en `globalThis` para reutilizarla entre reloads.
 */
declare global {
  // eslint-disable-next-line no-var
  var __prisma__: PrismaClient | undefined
}

export const prisma =
  global.__prisma__ ||
  new PrismaClient({
    log: env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  })

if (env.NODE_ENV !== 'production') {
  global.__prisma__ = prisma
}
