import { log } from '@/core/logger/logger';

export function audit(event: string, meta?: Record<string, unknown>) {
  log('info', `AUDIT:${event}`, meta);
}
