# Repositories

Implementar aquí adapters hacia Prisma, Supabase o servicios HTTP.
