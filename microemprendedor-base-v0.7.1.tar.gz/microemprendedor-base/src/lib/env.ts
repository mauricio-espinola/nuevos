/**
 * Validación de variables de entorno con Zod.
 *
 * Este archivo es la única fuente de verdad para acceder a process.env.
 * Si alguna variable crítica falta o es inválida, la app NO arranca.
 *
 * En lugar de `process.env.DATABASE_URL` directamente, usa `env.DATABASE_URL`.
 * Obtienes autocompletado, type safety y validación en el arranque.
 */

import { z } from 'zod'

// ============================================================================
// Schema del servidor: variables que NUNCA deben exponerse al cliente
// ============================================================================
const serverSchema = z.object({
  // Node environment
  NODE_ENV: z
    .enum(['development', 'test', 'production'])
    .default('development'),

  // Base de datos (Supabase Postgres)
  // - DATABASE_URL: connection pooler (puerto 6543) — usado en runtime
  // - DIRECT_URL: direct connection (puerto 5432) — usado por Prisma para migraciones
  DATABASE_URL: z
    .string()
    .url('DATABASE_URL debe ser una URL válida de Postgres')
    .refine(
      (url) => url.startsWith('postgresql://') || url.startsWith('postgres://'),
      { message: 'DATABASE_URL debe empezar con postgresql:// o postgres://' }
    ),
  DIRECT_URL: z
    .string()
    .url('DIRECT_URL debe ser una URL válida de Postgres')
    .refine(
      (url) => url.startsWith('postgresql://') || url.startsWith('postgres://'),
      { message: 'DIRECT_URL debe empezar con postgresql:// o postgres://' }
    ),

  // Autenticación
  // AUTH_JWT_SECRET se usa para firmar los JWT de sesión.
  // Mínimo 32 caracteres = 256 bits de entropía (requisito de seguridad HS256).
  // Generar con: openssl rand -base64 32
  AUTH_JWT_SECRET: z
    .string()
    .min(
      32,
      'AUTH_JWT_SECRET debe tener al menos 32 caracteres. Genera uno con: openssl rand -base64 32'
    ),

  // Nombre de la cookie de sesión (opcional, tiene default)
  AUTH_SESSION_COOKIE: z.string().min(1).default('app_session'),

  // Seed: credenciales del admin inicial
  // En producción estas DEBEN estar seteadas antes de correr el seed.
  AUTH_SEED_ADMIN_EMAIL: z
    .string()
    .email('AUTH_SEED_ADMIN_EMAIL debe ser un email válido'),
  AUTH_SEED_ADMIN_PASSWORD: z
    .string()
    .min(
      12,
      'AUTH_SEED_ADMIN_PASSWORD debe tener al menos 12 caracteres por seguridad'
    ),

  // Stripe (opcional hasta que se implementen pagos)
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
})

// ============================================================================
// Schema del cliente: variables NEXT_PUBLIC_* expuestas al bundle del browser
// ============================================================================
const clientSchema = z.object({
  NEXT_PUBLIC_APP_NAME: z.string().min(1).default('MicroEmprendedor'),
  NEXT_PUBLIC_APP_URL: z
    .string()
    .url()
    .default('http://localhost:3000'),
})

// ============================================================================
// Parsing y validación. Si falla, la app no arranca.
// ============================================================================
function formatErrors(error: z.ZodError): string {
  return error.issues
    .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
    .join('\n')
}

const _serverEnv = serverSchema.safeParse({
  NODE_ENV: process.env.NODE_ENV,
  DATABASE_URL: process.env.DATABASE_URL,
  DIRECT_URL: process.env.DIRECT_URL,
  AUTH_JWT_SECRET: process.env.AUTH_JWT_SECRET,
  AUTH_SESSION_COOKIE: process.env.AUTH_SESSION_COOKIE,
  AUTH_SEED_ADMIN_EMAIL: process.env.AUTH_SEED_ADMIN_EMAIL,
  AUTH_SEED_ADMIN_PASSWORD: process.env.AUTH_SEED_ADMIN_PASSWORD,
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,
})

if (!_serverEnv.success) {
  console.error(
    '\n❌ Variables de entorno del servidor inválidas:\n' +
      formatErrors(_serverEnv.error) +
      '\n\n→ Revisa tu archivo .env (o .env.local) y compáralo con .env.example\n'
  )
  throw new Error('Variables de entorno inválidas. App abortando.')
}

const _clientEnv = clientSchema.safeParse({
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
})

if (!_clientEnv.success) {
  console.error(
    '\n❌ Variables de entorno del cliente inválidas:\n' +
      formatErrors(_clientEnv.error) +
      '\n'
  )
  throw new Error('Variables de entorno inválidas. App abortando.')
}

// ============================================================================
// Export: objeto `env` tipado y validado, listo para usar en toda la app.
// ============================================================================
export const env = {
  ..._serverEnv.data,
  ..._clientEnv.data,
} as const

export type Env = typeof env
