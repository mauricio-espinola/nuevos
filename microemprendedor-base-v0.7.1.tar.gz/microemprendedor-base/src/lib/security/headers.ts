import { env } from '@/lib/env'

/**
 * Headers de seguridad aplicados globalmente en next.config.ts.
 *
 * Referencia de cada header:
 * - X-Frame-Options: previene clickjacking (nadie puede embeber la app en iframe)
 * - X-Content-Type-Options: previene MIME sniffing
 * - Referrer-Policy: controla qué info se envía en Referer al navegar a otros sitios
 * - Permissions-Policy: desactiva features del browser no usadas (cámara, mic, etc.)
 * - COOP/CORP: aislamiento cross-origin
 * - HSTS: fuerza HTTPS (solo válido en prod con certificado)
 * - CSP: restringe origins permitidos para scripts, estilos, imágenes, etc.
 */
export const securityHeaders = [
  { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=()',
  },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'Cross-Origin-Resource-Policy', value: 'same-origin' },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      env.NODE_ENV === 'development'
        ? "script-src 'self' 'unsafe-eval' 'unsafe-inline'"
        : "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https:",
      "font-src 'self' data:",
      "connect-src 'self' https:",
      "frame-ancestors 'self'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; '),
  },
] satisfies Array<{ key: string; value: string }>
