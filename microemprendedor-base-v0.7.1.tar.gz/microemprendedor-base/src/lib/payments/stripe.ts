import Stripe from 'stripe'
import { env } from '@/lib/env'

let stripeInstance: Stripe | null = null

export function getStripeServer() {
  if (!env.STRIPE_SECRET_KEY) {
    throw new Error('Missing STRIPE_SECRET_KEY')
  }

  if (!stripeInstance) {
    stripeInstance = new Stripe(env.STRIPE_SECRET_KEY)
  }

  return stripeInstance
}
