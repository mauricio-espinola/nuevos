import type { NextRequest } from 'next/server'

export const locales = ['es', 'en'] as const
export const defaultLocale = 'es'
export type AppLocale = (typeof locales)[number]

export function hasLocalePrefix(pathname: string) {
  return locales.some((locale) => pathname === `/${locale}` || pathname.startsWith(`/${locale}/`))
}

export function getPreferredLocale(
  request: NextRequest,
  supportedLocales: readonly string[],
  fallback: string
) {
  const cookieLocale = request.cookies.get('NEXT_LOCALE')?.value
  if (cookieLocale && supportedLocales.includes(cookieLocale)) {
    return cookieLocale
  }

  const acceptLanguage = request.headers.get('accept-language')
  if (!acceptLanguage) return fallback

  const preferred = acceptLanguage
    .split(',')
    .map((item) => item.split(';')[0]?.trim().split('-')[0]?.toLowerCase())
    .find((value): value is string => Boolean(value && supportedLocales.includes(value)))

  return preferred ?? fallback
}
