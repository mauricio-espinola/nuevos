import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/core/auth/current-user'
import { RegisterPortal } from '@/modules/auth/components/register-portal'

export default async function RegisterPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  const currentUser = await getCurrentUser()
  if (currentUser) {
    redirect(`/${locale}/${currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN' ? 'admin' : 'dashboard'}`)
  }
  return <RegisterPortal locale={locale} />
}
