import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/core/auth/current-user'
import { LoginPortal } from '@/modules/auth/components/login-portal'

export default async function LoginPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>
  searchParams: Promise<{ next?: string }>
}) {
  const { locale } = await params
  const currentUser = await getCurrentUser()
  if (currentUser) {
    redirect(`/${locale}/${currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN' ? 'admin' : 'dashboard'}`)
  }
  const { next } = await searchParams

  return <LoginPortal locale={locale} nextPath={next} />
}
