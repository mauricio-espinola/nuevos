export default function PricingPage() {
  return (
    <div className="container section">
      <div className="card p-8 md:p-10">
        <span className="badge">Pricing placeholder</span>
        <h1 className="mt-5 text-4xl font-bold">Planes y monetización</h1>
        <p className="mt-4 max-w-3xl text-white/70">
          Página estática de pricing conectada más adelante con Stripe desde backend seguro y reglas de acceso por plan.
        </p>
      </div>
    </div>
  )
}
