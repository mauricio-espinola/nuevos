import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { MainHeader } from '@/components/layout/main-header'
import { SiteFooter } from '@/components/layout/site-footer'
import { AppProviders } from '@/components/providers/app-providers'
import { locales, type AppLocale } from '@/lib/i18n'

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }))
}

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params
  const language = locales.includes(locale as AppLocale) ? locale : 'es'

  return {
    alternates: {
      languages: {
        es: '/es',
        en: '/en'
      }
    },
    openGraph: {
      locale: language
    }
  }
}

export default async function LocaleLayout({
  children,
  params
}: Readonly<{
  children: React.ReactNode
  params: Promise<{ locale: string }>
}>) {
  const { locale } = await params

  if (!locales.includes(locale as AppLocale)) {
    notFound()
  }

  return (
    <AppProviders>
      <div className="min-h-screen flex flex-col">
        <MainHeader locale={locale as AppLocale} />
        <main className="flex-1">{children}</main>
        <SiteFooter locale={locale as AppLocale} />
      </div>
    </AppProviders>
  )
}
