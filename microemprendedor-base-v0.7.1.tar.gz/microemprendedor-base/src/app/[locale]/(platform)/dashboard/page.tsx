import { requireAuthenticated } from '@/core/auth/guards'
import { DashboardShell } from '@/modules/dashboard/components/dashboard-shell'
import { getDashboardSummary } from '@/modules/dashboard/server/dashboard-loader'

export default async function DashboardPage() {
  await requireAuthenticated()
  const summary = await getDashboardSummary()

  return (
    <DashboardShell
      title="Dashboard operativo"
      description="Centro de control inicial para una instalación única, con foco en actividad, releases, configuración y readiness por módulo."
      summary={summary}
    />
  )
}
