import { requireRole } from '@/core/auth/guards'
import { ModulePlaceholder } from '@/modules/shared/components/module-placeholder'

export default async function FinanzasPage() {
  await requireRole(['ADMIN', 'SUPER_ADMIN'])
  return (
    <ModulePlaceholder
      title="Finanzas"
      description="Portal placeholder de finanzas dentro de la nueva estructura App Router."
      schemaStatus="planned"
      access="admin"
      nextSteps={[
        'Definir el primer conjunto mínimo de entidades y casos de uso del módulo.',
        'Conectar listados, filtros y contratos de servicio en la capa server.',
        'Validar paridad funcional con la versión SPA antes de optimizar.',
      ]}
    />
  )
}
