import { requireRole } from '@/core/auth/guards'
import { AdminPortal } from '@/modules/admin/components/admin-portal'

export default async function AdminPage() {
  await requireRole(['ADMIN', 'SUPER_ADMIN'])
  return <AdminPortal />
}
