import { requireAuthenticated } from '@/core/auth/guards';
import { ArticlesPortal } from '@/modules/articles/components/articles-portal';

export default async function ArticlesPage() {
  await requireAuthenticated();
  return <ArticlesPortal />;
}
