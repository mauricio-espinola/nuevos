import { requireAuthenticated } from '@/core/auth/guards'
import { ModulePlaceholder } from '@/modules/shared/components/module-placeholder'

export default async function MyboardPage() {
  await requireAuthenticated()
  return (
    <ModulePlaceholder
      title="Myboard"
      description="Portal placeholder de myboard dentro de la nueva estructura App Router."
      schemaStatus="planned"
      access="authenticated"
      nextSteps={[
        'Definir el primer conjunto mínimo de entidades y casos de uso del módulo.',
        'Conectar listados, filtros y contratos de servicio en la capa server.',
        'Validar paridad funcional con la versión SPA antes de optimizar.',
      ]}
    />
  )
}
