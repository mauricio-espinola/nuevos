import { redirect } from 'next/navigation'

export default async function PlatformIndex({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  redirect(`/${locale}/dashboard`)
}
