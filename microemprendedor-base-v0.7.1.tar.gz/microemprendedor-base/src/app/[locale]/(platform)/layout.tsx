import { PlatformSidebar } from '@/components/platform/platform-sidebar'

export default async function PlatformLayout({
  children,
  params
}: Readonly<{
  children: React.ReactNode
  params: Promise<{ locale: string }>
}>) {
  const { locale } = await params

  return (
    <div className="container section">
      <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
        <PlatformSidebar locale={locale} />
        <div>{children}</div>
      </div>
    </div>
  )
}
