import { NextResponse } from 'next/server'

export async function POST() {
  return NextResponse.json(
    {
      message:
        'Skeleton endpoint only. Implement Stripe Checkout or Payment Intents here on the server side.',
      status: 'not-implemented'
    },
    { status: 501 }
  )
}
