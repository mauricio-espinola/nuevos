import { NextResponse } from 'next/server'
import { signOutCurrentSession } from '@/modules/auth/server/auth-service'

export async function POST() {
  await signOutCurrentSession()
  return NextResponse.json({ ok: true })
}
