import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/core/auth/current-user'

export async function GET() {
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  return NextResponse.json({ user })
}
