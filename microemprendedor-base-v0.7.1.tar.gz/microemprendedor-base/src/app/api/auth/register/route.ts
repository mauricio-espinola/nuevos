import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { registerWithPassword } from '@/modules/auth/server/auth-service'

const registerSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
  name: z.string().max(200).optional(),
  company: z.string().max(200).optional(),
  position: z.string().max(200).optional(),
  locale: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const parsed = registerSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Datos de registro inválidos.' }, { status: 400 })
    }
    const result = await registerWithPassword(parsed.data)
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 400 })
    }
    return NextResponse.json({ ok: true, redirectTo: result.redirectTo }, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'No se pudo crear la cuenta.' }, { status: 500 })
  }
}
