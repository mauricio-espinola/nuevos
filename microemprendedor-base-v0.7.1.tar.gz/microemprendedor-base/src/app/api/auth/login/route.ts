import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { signInWithPassword } from '@/modules/auth/server/auth-service'

const loginSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
  locale: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const parsed = loginSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Credenciales inválidas.' }, { status: 400 })
    }
    const result = await signInWithPassword(parsed.data)
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 401 })
    }
    return NextResponse.json({ ok: true, redirectTo: result.redirectTo })
  } catch {
    return NextResponse.json({ error: 'No se pudo iniciar sesión.' }, { status: 500 })
  }
}
