import Link from 'next/link'
import { AppLocale } from '@/lib/i18n'
import { siteConfig } from '@/config/site'

export function MainHeader({ locale }: { locale: AppLocale }) {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#07111fcc]/80 backdrop-blur-xl">
      <div className="container flex items-center justify-between py-4">
        <Link href={`/${locale}`} className="font-semibold tracking-tight">
          {siteConfig.name}
        </Link>
        <nav className="hidden gap-6 text-sm text-white/70 md:flex">
          <Link href={`/${locale}#arquitectura`}>Arquitectura</Link>
          <Link href={`/${locale}#modulos`}>Módulos</Link>
          <Link href={`/${locale}/pricing`}>Planes</Link>
          <Link href={`/${locale}/login`}>Login</Link>
          <Link href={`/${locale}/dashboard`}>App</Link>
        </nav>
      </div>
    </header>
  )
}
