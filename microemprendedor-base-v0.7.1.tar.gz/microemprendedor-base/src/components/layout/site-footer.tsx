import { AppLocale } from '@/lib/i18n'
import { siteConfig } from '@/config/site'

export function SiteFooter({ locale }: { locale: AppLocale }) {
  const year = new Date().getFullYear()
  return (
    <footer className="border-t border-white/10 py-8 text-sm text-white/50">
      <div className="container flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <span>
          © {year} {siteConfig.name}
        </span>
        <span>
          Locale: {locale.toUpperCase()} · App Router · White-label ready
        </span>
      </div>
    </footer>
  )
}
