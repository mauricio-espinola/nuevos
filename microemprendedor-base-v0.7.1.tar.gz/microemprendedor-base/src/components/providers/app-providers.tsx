'use client'

/**
 * AppProviders: punto central para wrappers de contexto React.
 *
 * Por ahora pass-through. Acá agregaremos providers cuando los necesitemos
 * (ej. Toaster, Dialog root, AuthContext para client components, etc.).
 */
export function AppProviders({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
