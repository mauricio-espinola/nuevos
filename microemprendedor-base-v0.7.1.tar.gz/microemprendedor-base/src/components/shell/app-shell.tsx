import { ReactNode } from 'react';

export function AppShell({ children }: { children: ReactNode }) {
  return <div className="min-h-screen bg-neutral-50 text-neutral-950">{children}</div>;
}
