import Link from 'next/link'
import { ArrowRight, Lock, Rocket, ShieldCheck, Zap } from 'lucide-react'
import { platformModules } from '@/config/modules'

const principles = [
  {
    title: 'Arquitectura por dominios',
    text: 'Marketing, acceso, plataforma, pagos y administración quedan separados desde el inicio para evitar el acoplamiento que hoy te frena.'
  },
  {
    title: 'Seguridad primero',
    text: 'Headers, middleware, validación de entorno y fronteras server/client definidas antes de montar módulos complejos.'
  },
  {
    title: 'Reconstrucción por módulos',
    text: 'Cada capacidad de la SPA actual se representa ya como portal App Router y luego se desarrolla sin arrastrar archivos monstruo.'
  }
]

const featureCards = [
  {
    icon: ShieldCheck,
    title: 'Security baseline',
    text: 'CSP, HSTS, políticas de permisos, root hardening y estructura lista para auth real.'
  },
  {
    icon: Rocket,
    title: 'Scalable shell',
    text: 'Layouts segmentados, route groups y un pipeline limpio para crecer por módulos y tenants.'
  },
  {
    icon: Lock,
    title: 'Payment boundary',
    text: 'Stripe queda encapsulado en servidor y fuera del layout público, listo para rehacerse sin contaminar el resto.'
  },
  {
    icon: Zap,
    title: 'Performance by design',
    text: 'Base mínima, split natural por rutas y landing estática para cargar rápido desde el día uno.'
  }
]

export function LandingPage() {
  const highlightedModules = platformModules.slice(0, 8)

  return (
    <>
      <section className="section">
        <div className="container grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <span className="badge">App Router skeleton · White-label ready</span>
            <h1 className="mt-6 max-w-4xl text-5xl font-bold leading-tight md:text-6xl">
              Base limpia para reconstruir tu plataforma modular sin arrastrar la complejidad híbrida actual.
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-white/70">
              La landing es estática, pero la plataforma ya está representada por módulos reales como dashboard,
              admin, asistente, finanzas, recursos, myboard y más. Cada portal queda listo para desarrollarse después.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/es/dashboard" className="button-primary">
                Abrir esqueleto de app
                <ArrowRight size={18} />
              </Link>
              <Link href="/es/login" className="button-secondary">
                Ver acceso
              </Link>
            </div>
          </div>
          <div className="card p-8">
            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-white/50">Readiness snapshot</p>
            <div className="mt-6 grid gap-4">
              <Stat label="Route groups" value="Marketing / Auth / Platform" />
              <Stat label="Locales" value="ES / EN" />
              <Stat label="Módulos" value={`${platformModules.length} portales representados`} />
              <Stat label="Pagos" value="Server boundary ready" />
            </div>
          </div>
        </div>
      </section>

      <section id="arquitectura" className="section">
        <div className="container">
          <div className="max-w-2xl">
            <span className="badge">Arquitectura</span>
            <h2 className="mt-6 text-4xl font-bold">Estructura pensada para representar la app real desde el día uno</h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {principles.map((item) => (
              <article key={item.title} className="card p-6">
                <h3 className="text-xl font-semibold">{item.title}</h3>
                <p className="mt-4 text-white/70">{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="modulos" className="section">
        <div className="container">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div className="max-w-3xl">
              <span className="badge">Mapa funcional</span>
              <h2 className="mt-6 text-4xl font-bold">Portales placeholder que ya reflejan la solución actual</h2>
              <p className="mt-4 text-white/70">
                Aquí no hay desarrollo final del módulo, pero sí su representación estructural dentro de App Router.
              </p>
            </div>
            <Link href="/es/dashboard" className="button-secondary">Ir al overview privado</Link>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {highlightedModules.map((item) => (
              <Link key={item.slug} href={`/es/${item.slug}`} className="card p-5 transition hover:-translate-y-0.5">
                <p className="text-sm uppercase tracking-[0.2em] text-white/45">{item.domain}</p>
                <h3 className="mt-3 text-lg font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm text-white/65">{item.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section id="seguridad" className="section">
        <div className="container">
          <div className="card p-8 md:p-10">
            <div className="grid gap-6 md:grid-cols-2">
              {featureCards.map(({ icon: Icon, title, text }) => (
                <article key={title} className="rounded-3xl border border-white/10 bg-white/3 p-6">
                  <Icon className="h-6 w-6" />
                  <h3 className="mt-4 text-xl font-semibold">{title}</h3>
                  <p className="mt-3 text-white/70">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/3 p-5">
      <p className="text-sm text-white/50">{label}</p>
      <p className="mt-2 text-lg font-semibold">{value}</p>
    </div>
  )
}
