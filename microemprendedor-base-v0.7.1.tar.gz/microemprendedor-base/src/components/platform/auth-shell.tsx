import Link from 'next/link'

export function AuthShell({
  title,
  description,
  ctaLabel,
  locale,
  secondaryHref,
  secondaryLabel
}: {
  title: string
  description: string
  ctaLabel: string
  locale: string
  secondaryHref: string
  secondaryLabel: string
}) {
  return (
    <div className="container section">
      <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        <section className="card p-8 md:p-10">
          <span className="badge">Access boundary</span>
          <h1 className="mt-5 text-4xl font-bold">{title}</h1>
          <p className="mt-4 text-white/70">{description}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={`/${locale}/dashboard`} className="button-primary">{ctaLabel}</Link>
            <Link href={secondaryHref} className="button-secondary">{secondaryLabel}</Link>
          </div>
        </section>
        <section className="card p-8 md:p-10">
          <h2 className="text-2xl font-semibold">Placeholder de autenticación</h2>
          <div className="mt-6 grid gap-4">
            <Field label="Email" />
            <Field label="Password" />
            <div className="rounded-2xl border border-dashed border-white/15 p-4 text-sm text-white/55">
              Aquí va el formulario real cuando definamos provider, sesiones, guards y recuperación de cuenta.
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

function Field({ label }: { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-white/60">{label}</span>
      <div className="rounded-2xl border border-white/10 bg-white/4 px-4 py-3 text-white/35">Placeholder</div>
    </label>
  )
}
