import Link from 'next/link'
import { platformModules, type PlatformModule } from '@/config/modules'

export function ModuleShell({ locale, module }: { locale: string; module: PlatformModule }) {
  return (
    <div className="space-y-8">
      <div className="card p-8">
        <span className="badge">{module.domain} · {module.maturity}</span>
        <h1 className="mt-5 text-4xl font-bold">{module.title}</h1>
        <p className="mt-4 max-w-3xl text-white/70">{module.description}</p>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <InfoCard title="Estado" value="Portal placeholder" />
          <InfoCard title="Prioridad" value={module.priority} />
          <InfoCard title="Objetivo" value="Reconstrucción por módulo" />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
        <section className="card p-8">
          <h2 className="text-2xl font-semibold">Qué vive aquí después</h2>
          <ul className="mt-5 space-y-3 text-white/70">
            <li>• UI y flujos del módulo recreados bajo App Router.</li>
            <li>• Data fetching y mutaciones con límites claros entre server y client.</li>
            <li>• Guards de acceso, telemetría y contratos desacoplados.</li>
            <li>• Tests del módulo antes de integrarlo a la plataforma completa.</li>
          </ul>
        </section>

        <aside className="card p-8">
          <h2 className="text-2xl font-semibold">Navegación rápida</h2>
          <div className="mt-5 flex flex-col gap-3">
            <Link href={`/${locale}/dashboard`} className="button-secondary">Ir a dashboard</Link>
            <Link href={`/${locale}/login`} className="button-secondary">Ver login</Link>
            <Link href={`/${locale}`} className="button-secondary">Volver a landing</Link>
          </div>
        </aside>
      </div>

      <section className="card p-8">
        <h2 className="text-2xl font-semibold">Mapa actual de módulos</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {platformModules.map((item) => (
            <Link
              key={item.slug}
              href={`/${locale}/${item.slug}`}
              className="rounded-3xl border border-white/10 bg-white/3 p-5 transition hover:-translate-y-0.5"
            >
              <p className="text-sm uppercase tracking-[0.2em] text-white/45">{item.domain}</p>
              <h3 className="mt-3 text-lg font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-white/65">{item.description}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

function InfoCard({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/3 p-5">
      <p className="text-sm text-white/50">{title}</p>
      <p className="mt-2 text-lg font-semibold capitalize">{value}</p>
    </div>
  )
}
