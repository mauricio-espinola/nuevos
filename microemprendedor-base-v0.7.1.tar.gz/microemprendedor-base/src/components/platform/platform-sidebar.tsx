import Link from 'next/link'
import { platformModules } from '@/config/modules'
import { getCurrentUser } from '@/core/auth/current-user'
import { LogoutButton } from '@/modules/auth/components/logout-button'

export async function PlatformSidebar({ locale }: { locale: string }) {
  const user = await getCurrentUser()
  const filteredModules = platformModules.filter((item) => item.access === 'authenticated' || ['ADMIN', 'SUPER_ADMIN'].includes(user?.role || 'USER'))

  return (
    <aside className="card h-fit p-5 lg:sticky lg:top-24">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-white/45">Platform map</p>
      <div className="mt-4 rounded-2xl border border-white/10 bg-white/4 p-4">
        <p className="text-sm font-medium text-white">{user?.name || user?.email || 'Usuario autenticado'}</p>
        <p className="mt-1 text-xs uppercase tracking-[0.2em] text-white/45">{user?.role || 'USER'}</p>
      </div>
      <nav className="mt-5 flex flex-col gap-2">
        {filteredModules.map((item) => (
          <Link
            key={item.slug}
            href={`/${locale}/${item.slug}`}
            className="rounded-2xl border border-transparent px-4 py-3 text-sm text-white/75 transition hover:border-white/10 hover:bg-white/4 hover:text-white"
          >
            {item.title}
          </Link>
        ))}
      </nav>
      <div className="mt-5">
        <LogoutButton locale={locale} />
      </div>
    </aside>
  )
}
