import Link from 'next/link'
import { platformModules } from '@/config/modules'

export function PlatformOverview({ locale }: { locale: string }) {
  const highPriority = platformModules.filter((item) => item.priority === 'high')
  const readySchemas = platformModules.filter((item) => item.schemaStatus === 'ready').length
  const adminModules = platformModules.filter((item) => item.access === 'admin').length

  return (
    <div className="space-y-8">
      <section className="card p-8">
        <span className="badge">Foundation v4</span>
        <h1 className="mt-5 text-4xl font-bold">Portal privado reconstruido como plataforma operable</h1>
        <p className="mt-4 max-w-3xl text-white/70">
          Esta base ya no representa solo rutas: incorpora proxy, núcleo de autenticación, esquema Prisma autorizado,
          releases de actualización, branding configurable y una primera ola de dominios lista para poblar.
        </p>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Metric label="Módulos representados" value={String(platformModules.length)} />
        <Metric label="Esquemas listos" value={String(readySchemas)} />
        <Metric label="Admin modules" value={String(adminModules)} />
        <Metric label="Runtime" value="single-instance" />
      </section>

      <section className="card p-8">
        <h2 className="text-2xl font-semibold">Primera ola de reconstrucción</h2>
        <p className="mt-2 text-white/70">Estos módulos ya tienen ruta, capa de acceso prevista y lugar definido dentro del esquema nuevo.</p>
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {highPriority.map((item) => (
            <Link key={item.slug} href={`/${locale}/${item.slug}`} className="rounded-3xl border border-white/10 bg-white/3 p-5 transition hover:-translate-y-0.5">
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm uppercase tracking-[0.2em] text-white/45">{item.domain}</p>
                <span className="text-[10px] uppercase tracking-[0.24em] text-emerald-300/80">{item.schemaStatus}</span>
              </div>
              <h3 className="mt-3 text-lg font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-white/65">{item.description}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-6">
      <p className="text-sm text-white/50">{label}</p>
      <p className="mt-2 text-2xl font-semibold">{value}</p>
    </div>
  )
}
