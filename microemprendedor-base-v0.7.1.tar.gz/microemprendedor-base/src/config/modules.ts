export type PlatformModule = {
  slug: string
  title: string
  description: string
  domain: string
  maturity: 'placeholder' | 'foundation'
  priority: 'high' | 'medium'
  access: 'authenticated' | 'admin'
  schemaStatus: 'ready' | 'planned'
}

export const platformModules: PlatformModule[] = [
  { slug: 'dashboard', title: 'Dashboard', description: 'Vista ejecutiva inicial con KPIs, actividad y alertas.', domain: 'core', maturity: 'foundation', priority: 'high', access: 'authenticated', schemaStatus: 'ready' },
  { slug: 'panel', title: 'Panel', description: 'Workspace privado y puerta de entrada a cada sección operativa.', domain: 'core', maturity: 'placeholder', priority: 'high', access: 'authenticated', schemaStatus: 'ready' },
  { slug: 'admin', title: 'Admin', description: 'Backoffice de configuración, seguridad, permisos, branding y releases.', domain: 'operations', maturity: 'foundation', priority: 'high', access: 'admin', schemaStatus: 'ready' },
  { slug: 'articles', title: 'Artículos', description: 'Gestión editorial con borradores, aprobación, publicación y taxonomías.', domain: 'content', maturity: 'foundation', priority: 'high', access: 'authenticated', schemaStatus: 'ready' },
  { slug: 'asistente', title: 'Asistente IA', description: 'Entrada del copiloto conversacional y automatizaciones guiadas.', domain: 'ai', maturity: 'placeholder', priority: 'high', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'conocimiento', title: 'Conocimiento', description: 'Repositorio y navegación del conocimiento estructurado de la plataforma.', domain: 'knowledge', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'capacitacion', title: 'Capacitación', description: 'Portal de cursos, rutas formativas y consumo educativo.', domain: 'learning', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'seminars', title: 'Seminars', description: 'Agenda y catálogo de seminarios o sesiones programadas.', domain: 'learning', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'recursos', title: 'Recursos', description: 'Biblioteca de recursos, categorías y favoritos.', domain: 'content', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'tips', title: 'Tips', description: 'Microcontenido, recomendaciones diarias y piezas cortas.', domain: 'content', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'links', title: 'Links', description: 'Gestión curada de enlaces, colecciones y favoritos compartidos.', domain: 'content', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'eventos', title: 'Eventos', description: 'Calendario de eventos, difusión y participación.', domain: 'community', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'foro', title: 'Foro', description: 'Espacio de discusión, temas y comentarios.', domain: 'community', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'network', title: 'Network', description: 'Mapa y conexión entre perfiles y relaciones.', domain: 'community', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'mentores', title: 'Mentores', description: 'Portal de mentors, matching y seguimiento de mentorías.', domain: 'community', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'marketplace', title: 'Marketplace', description: 'Espacio comercial de servicios o productos.', domain: 'business', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'finanzas', title: 'Finanzas', description: 'Módulo financiero, cálculos, suscripciones y cobros.', domain: 'business', maturity: 'placeholder', priority: 'high', access: 'admin', schemaStatus: 'planned' },
  { slug: 'ideas', title: 'Ideas', description: 'Embudo de propuestas, comentarios y evolución de iniciativas.', domain: 'innovation', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'diagnostic', title: 'Diagnostic', description: 'Diagnóstico guiado con categorías, resultados y respuestas.', domain: 'assessment', maturity: 'placeholder', priority: 'high', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'encuestas', title: 'Encuestas', description: 'Encuestas, polls y captura estructurada de feedback.', domain: 'assessment', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'gamificacion', title: 'Gamificación', description: 'Puntos, badges, leaderboard y desafíos de engagement.', domain: 'engagement', maturity: 'placeholder', priority: 'medium', access: 'authenticated', schemaStatus: 'planned' },
  { slug: 'myboard', title: 'MyBoard', description: 'Tablero analítico personal con datasets y visualizaciones.', domain: 'analytics', maturity: 'placeholder', priority: 'high', access: 'authenticated', schemaStatus: 'planned' },
]

export const platformModuleMap = Object.fromEntries(platformModules.map((item) => [item.slug, item]))
