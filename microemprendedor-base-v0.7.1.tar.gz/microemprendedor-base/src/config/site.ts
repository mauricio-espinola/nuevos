import { env } from '@/lib/env'

/**
 * Configuración de sitio (metadata SEO, título de pestañas, etc.)
 *
 * Los valores vienen del env validado. El nombre y URL se configuran por
 * instancia vía `NEXT_PUBLIC_APP_NAME` y `NEXT_PUBLIC_APP_URL` en `.env`,
 * lo que permite a cada cliente white-label tener su propio branding.
 *
 * El description queda centralizado aquí por ahora; cuando se implemente
 * `BrandingSettings` en DB, se puede migrar a allá.
 */
export const siteConfig = {
  name: env.NEXT_PUBLIC_APP_NAME,
  url: env.NEXT_PUBLIC_APP_URL,
  description:
    'Plataforma modular para microempresarios: finanzas, clientes, ventas y crecimiento en un solo lugar.',
} as const
