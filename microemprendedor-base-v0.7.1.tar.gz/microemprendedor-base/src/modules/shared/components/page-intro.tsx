type PageIntroProps = {
  eyebrow?: string;
  title: string;
  description: string;
};

export function PageIntro({ eyebrow, title, description }: PageIntroProps) {
  return (
    <header className="space-y-2 rounded-2xl border border-black/10 bg-white p-6 shadow-sm">
      {eyebrow ? <p className="text-xs font-semibold uppercase tracking-[0.24em] text-black/50">{eyebrow}</p> : null}
      <h1 className="text-3xl font-semibold">{title}</h1>
      <p className="max-w-2xl text-sm text-black/70">{description}</p>
    </header>
  );
}
