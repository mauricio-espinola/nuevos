type ModulePlaceholderProps = {
  title: string
  description: string
  schemaStatus: 'ready' | 'planned'
  access: 'authenticated' | 'admin'
  nextSteps: string[]
}

export function ModulePlaceholder({ title, description, schemaStatus, access, nextSteps }: ModulePlaceholderProps) {
  return (
    <section className="space-y-6">
      <header className="rounded-2xl border border-black/10 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.22em] text-black/45">
          <span>{access}</span>
          <span>•</span>
          <span>{schemaStatus}</span>
        </div>
        <h1 className="mt-3 text-3xl font-semibold">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-black/70">{description}</p>
      </header>
      <article className="rounded-2xl border border-dashed border-black/20 bg-white p-6">
        <h2 className="text-lg font-semibold">Siguientes pasos sugeridos</h2>
        <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm text-black/70">
          {nextSteps.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
      </article>
    </section>
  )
}
