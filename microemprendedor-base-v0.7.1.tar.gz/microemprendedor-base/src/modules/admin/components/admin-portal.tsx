import { ModulePlaceholder } from '@/modules/shared/components/module-placeholder'

export function AdminPortal() {
  return (
    <ModulePlaceholder
      title="Admin control plane"
      description="Backoffice inicial ya listo para gobernar auth, roles, feature flags, branding, releases y configuración operativa de la instalación."
      schemaStatus="ready"
      access="admin"
      nextSteps={[
        'Conectar users, roles, permissions, feature flags y audit log al panel administrativo.',
        'Agregar edición de AppSettings, BrandingSettings, NavSection y releases.',
        'Usar este backoffice como fuente de verdad para habilitar módulos sin tocar código.',
      ]}
    />
  )
}
