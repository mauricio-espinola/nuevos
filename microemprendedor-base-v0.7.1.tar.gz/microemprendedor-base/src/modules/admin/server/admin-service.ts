export async function getAdminOverview() {
  return {
    sections: ['users', 'roles', 'content', 'security', 'integrations', 'tenants'],
  };
}
