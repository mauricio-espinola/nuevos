import { prisma } from '@/server/db/prisma'

export async function getDashboardSummary() {
  const [activeUsers, openFlags, releases, articles] = await Promise.all([
    prisma.user.count({ where: { status: 'ACTIVE' } }),
    prisma.featureFlag.count({ where: { state: 'ENABLED' } }),
    prisma.appRelease.count({ where: { status: 'RELEASED' } }),
    prisma.article.count().catch(() => 0),
  ])

  return {
    activeUsers,
    completionRate: Math.min(100, openFlags * 4 + 20),
    openTasks: Math.max(0, 12 - releases),
    conversionRate: Math.min(100, 15 + articles),
  }
}
