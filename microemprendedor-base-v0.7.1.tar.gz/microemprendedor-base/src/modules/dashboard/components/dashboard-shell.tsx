type DashboardShellProps = {
  title: string
  description: string
  summary: {
    activeUsers: number
    completionRate: number
    openTasks: number
    conversionRate: number
  }
}

export function DashboardShell({ title, description, summary }: DashboardShellProps) {
  return (
    <section className="space-y-6">
      <header className="rounded-2xl border border-black/10 bg-white p-6 shadow-sm">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-black/45">Single-instance control center</p>
        <h1 className="mt-3 text-3xl font-semibold">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-black/70">{description}</p>
      </header>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[
          ['Usuarios activos', String(summary.activeUsers)],
          ['Cumplimiento', `${summary.completionRate}%`],
          ['Tareas abiertas', String(summary.openTasks)],
          ['Conversión', `${summary.conversionRate}%`],
        ].map(([label, value]) => (
          <article key={label} className="rounded-2xl border border-black/10 bg-white p-5 shadow-sm">
            <p className="text-sm text-black/60">{label}</p>
            <p className="mt-2 text-3xl font-semibold">{value}</p>
          </article>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <article className="rounded-2xl border border-dashed border-black/20 bg-white p-6">
          <h2 className="text-lg font-semibold">Operational timeline</h2>
          <p className="mt-2 text-sm text-black/70">
            Espacio reservado para releases, auditoría, actividades críticas y trazabilidad del negocio.
          </p>
        </article>
        <article className="rounded-2xl border border-dashed border-black/20 bg-white p-6">
          <h2 className="text-lg font-semibold">Module readiness</h2>
          <p className="mt-2 text-sm text-black/70">
            Espacio reservado para progreso por módulo, bloqueos de migración y riesgos de reconstrucción.
          </p>
        </article>
      </div>
    </section>
  )
}
