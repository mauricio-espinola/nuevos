export type DashboardSummary = {
  activeUsers: number;
  completionRate: number;
  openTasks: number;
  conversionRate: number;
};
