import bcrypt from 'bcryptjs'
import { cookies, headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { AccountStatus, SessionStatus, UserRole } from '@prisma/client'
import { prisma } from '@/server/db/prisma'
import { getSessionCookieOptions, hashSessionToken, issueSessionToken, authCookieName } from '@/core/auth/session'

export type AuthResult = {
  ok: boolean
  error?: string
  redirectTo?: string
}

function getClientMeta(headerStore: Headers) {
  const forwardedFor = headerStore.get('x-forwarded-for')
  return {
    ipAddress: forwardedFor?.split(',')[0]?.trim() || headerStore.get('x-real-ip') || undefined,
    userAgent: headerStore.get('user-agent') || undefined,
  }
}

function getRoleRedirect(role: string, locale = 'es') {
  return `/${locale}/${role === 'ADMIN' || role === 'SUPER_ADMIN' ? 'admin' : 'dashboard'}`
}

async function persistSession({ userId, email, role, displayName }: { userId: string; email: string; role: 'USER' | 'ADMIN' | 'SUPER_ADMIN'; displayName?: string | null }) {
  const token = await issueSessionToken({ sub: userId, email, role, displayName: displayName || undefined })
  const tokenHash = hashSessionToken(token)
  const headerStore = await headers()
  const meta = getClientMeta(headerStore)

  await prisma.session.create({
    data: {
      userId,
      tokenHash,
      ipAddress: meta.ipAddress,
      userAgent: meta.userAgent,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7),
      lastSeenAt: new Date(),
    }
  })

  const cookieStore = await cookies()
  cookieStore.set(authCookieName, token, getSessionCookieOptions())
}

export async function signInWithPassword(input: { email: string; password: string; locale?: string }): Promise<AuthResult> {
  const email = input.email.trim().toLowerCase()
  const user = await prisma.user.findUnique({ where: { email } })

  if (!user) return { ok: false, error: 'No encontramos una cuenta con ese correo.' }
  if (user.status === AccountStatus.FROZEN) return { ok: false, error: 'Tu cuenta está congelada. Contacta soporte.' }
  if (user.status === AccountStatus.SUSPENDED) return { ok: false, error: 'Tu cuenta está suspendida. Contacta soporte.' }

  const validPassword = await bcrypt.compare(input.password, user.password)
  if (!validPassword) return { ok: false, error: 'La contraseña no es correcta.' }

  await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })
  await prisma.activity.create({
    data: {
      type: 'LOGIN',
      userId: user.id,
      metadata: JSON.stringify({ provider: 'credentials', action: 'logged_in' })
    }
  }).catch(() => null)

  await persistSession({ userId: user.id, email: user.email, role: user.role, displayName: user.name })

  return { ok: true, redirectTo: getRoleRedirect(user.role, input.locale) }
}

export async function registerWithPassword(input: { email: string; password: string; name?: string; company?: string; position?: string; locale?: string }): Promise<AuthResult> {
  const email = input.email.trim().toLowerCase()
  const existingUser = await prisma.user.findUnique({ where: { email } })
  if (existingUser) return { ok: false, error: 'Ya existe un usuario con ese correo.' }

  const settings = await prisma.appSettings.findFirst()
  if (settings && !settings.allowSelfRegistration) {
    return { ok: false, error: 'El registro directo está deshabilitado en esta instalación.' }
  }

  const passwordHash = await bcrypt.hash(input.password, 12)
  const user = await prisma.user.create({
    data: {
      email,
      password: passwordHash,
      name: input.name?.trim() || null,
      company: input.company?.trim() || null,
      position: input.position?.trim() || null,
      role: UserRole.USER,
      status: AccountStatus.ACTIVE,
      authProvider: 'CREDENTIALS',
      roleAssignments: {
        create: {
          role: { connect: { code: UserRole.USER } },
          isPrimary: true,
        }
      }
    }
  })

  await prisma.activity.create({
    data: {
      type: 'LOGIN',
      userId: user.id,
      metadata: JSON.stringify({ action: 'registered' })
    }
  }).catch(() => null)

  await persistSession({ userId: user.id, email: user.email, role: user.role, displayName: user.name })

  return { ok: true, redirectTo: getRoleRedirect(user.role, input.locale) }
}

export async function signOutCurrentSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(authCookieName)?.value
  if (token) {
    await prisma.session.updateMany({
      where: { tokenHash: hashSessionToken(token), status: SessionStatus.ACTIVE },
      data: { status: SessionStatus.REVOKED, lastSeenAt: new Date() }
    })
  }
  cookieStore.set(authCookieName, '', { ...getSessionCookieOptions(), maxAge: 0 })
}

export async function requireAuthAction() {
  const cookieStore = await cookies()
  const token = cookieStore.get(authCookieName)?.value
  if (!token) redirect('/es/login')
  return token
}
