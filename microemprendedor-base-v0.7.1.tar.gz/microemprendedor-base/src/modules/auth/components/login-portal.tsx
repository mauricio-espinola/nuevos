import Link from 'next/link'
import { LoginForm } from '@/modules/auth/components/login-form'

export function LoginPortal({ locale, nextPath }: { locale: string; nextPath?: string }) {
  return (
    <div className="container section">
      <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        <section className="card p-8 md:p-10">
          <span className="badge">Auth · credentials</span>
          <h1 className="mt-5 text-4xl font-bold">Ingreso operativo sobre App Router</h1>
          <p className="mt-4 text-white/70">
            Primer ejemplo real reconstruido desde la SPA: login por credenciales, sesión segura con cookie HttpOnly,
            proxy por rol, persistencia en Prisma y redirección distinta para admin y usuario normal.
          </p>
          <div className="mt-8 space-y-3 text-sm text-white/65">
            <p>• Login con email y contraseña.</p>
            <p>• Sesión firmada + registro en tabla Session.</p>
            <p>• Actividad de acceso y base para auditoría.</p>
            <p>• Admin → /admin · User → /dashboard.</p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={`/${locale}/register`} className="button-secondary">Crear cuenta</Link>
            <Link href={`/${locale}`} className="button-secondary">Volver a landing</Link>
          </div>
        </section>
        <section className="card p-8 md:p-10">
          <h2 className="text-2xl font-semibold">Iniciar sesión</h2>
          <p className="mt-2 text-sm text-white/55">Usa el usuario semilla o una cuenta registrada desde esta misma base.</p>
          <div className="mt-6">
            <LoginForm locale={locale} nextPath={nextPath} />
          </div>
        </section>
      </div>
    </div>
  )
}
