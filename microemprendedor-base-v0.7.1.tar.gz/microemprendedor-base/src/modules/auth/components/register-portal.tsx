import Link from 'next/link'
import { RegisterForm } from '@/modules/auth/components/register-form'

export function RegisterPortal({ locale }: { locale: string }) {
  return (
    <div className="container section">
      <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        <section className="card p-8 md:p-10">
          <span className="badge">Auth · onboarding</span>
          <h1 className="mt-5 text-4xl font-bold">Registro básico alineado con el nuevo core</h1>
          <p className="mt-4 text-white/70">
            Esta base deja listo el punto de entrada para ampliar el onboarding después, pero ya crea usuario,
            asigna rol principal, abre sesión y entra al portal privado con la lógica nueva.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={`/${locale}/login`} className="button-secondary">Ya tengo cuenta</Link>
            <Link href={`/${locale}`} className="button-secondary">Volver a landing</Link>
          </div>
        </section>
        <section className="card p-8 md:p-10">
          <h2 className="text-2xl font-semibold">Crear cuenta</h2>
          <p className="mt-2 text-sm text-white/55">Esta acción respeta AppSettings.allowSelfRegistration.</p>
          <div className="mt-6">
            <RegisterForm locale={locale} />
          </div>
        </section>
      </div>
    </div>
  )
}
