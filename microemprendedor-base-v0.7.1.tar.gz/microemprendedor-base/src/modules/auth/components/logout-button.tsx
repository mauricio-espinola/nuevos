'use client'

import { useRouter } from 'next/navigation'

export function LogoutButton({ locale }: { locale: string }) {
  const router = useRouter()

  async function onLogout() {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push(`/${locale}/login`)
    router.refresh()
  }

  return (
    <button type="button" onClick={onLogout} className="rounded-2xl border border-white/10 px-4 py-2 text-sm text-white/75 transition hover:bg-white/6">
      Cerrar sesión
    </button>
  )
}
