'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export function LoginForm({ locale, nextPath }: { locale: string; nextPath?: string }) {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function onSubmit(formData: FormData) {
    setIsPending(true)
    setError(null)

    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: formData.get('email'),
        password: formData.get('password'),
        locale,
      }),
    })

    const payload = await response.json().catch(() => ({}))
    setIsPending(false)

    if (!response.ok) {
      setError(payload.error || 'No se pudo iniciar sesión.')
      return
    }

    router.push(nextPath || payload.redirectTo || `/${locale}/dashboard`)
    router.refresh()
  }

  return (
    <form action={onSubmit} className="space-y-4">
      <Field label="Email" name="email" type="email" placeholder="tu@empresa.com" required />
      <Field label="Contraseña" name="password" type="password" placeholder="••••••••" required />
      {error ? <p className="rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p> : null}
      <button disabled={isPending} className="button-primary w-full justify-center disabled:opacity-60" type="submit">
        {isPending ? 'Ingresando…' : 'Iniciar sesión'}
      </button>
    </form>
  )
}

function Field({ label, name, type, placeholder, required = false }: { label: string; name: string; type: string; placeholder: string; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-white/60">{label}</span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        className="w-full rounded-2xl border border-white/10 bg-white/4 px-4 py-3 text-white outline-none transition focus:border-white/30 focus:bg-white/6"
      />
    </label>
  )
}
