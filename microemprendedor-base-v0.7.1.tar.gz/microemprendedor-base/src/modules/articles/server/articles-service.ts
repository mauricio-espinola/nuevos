export async function getArticlesBootstrap() {
  return { status: 'ready-for-migration' } as const;
}
