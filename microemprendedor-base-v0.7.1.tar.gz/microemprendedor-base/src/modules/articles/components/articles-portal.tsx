import { ModulePlaceholder } from '@/modules/shared/components/module-placeholder'

export function ArticlesPortal() {
  return (
    <ModulePlaceholder
      title="Articles workspace"
      description="Base editorial con taxonomías, estados, aprobación, publicación y análisis de rendimiento."
      schemaStatus="ready"
      access="authenticated"
      nextSteps={[
        'Conectar Section, Tag, Article y ArticleBlock al listado inicial.',
        'Agregar permisos de escritura, revisión y publicación por rol.',
        'Montar el editor y la cola de aprobación sobre Server Actions.',
      ]}
    />
  )
}
