export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { registerMonitoring } = await import('./src/core/monitoring/instrumentation');
    registerMonitoring();
  }
}
