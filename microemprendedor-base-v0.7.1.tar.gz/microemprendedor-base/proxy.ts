import { NextRequest, NextResponse } from 'next/server'
import { defaultLocale, getPreferredLocale, hasLocalePrefix, locales } from '@/lib/i18n'
import { authCookieName, decodeSessionToken } from '@/core/auth/session'

const PUBLIC_PATHS = ['/login', '/register', '/pricing']
const ADMIN_PREFIX = '/admin'
const PLATFORM_PREFIXES = [
  '/dashboard',
  '/panel',
  '/admin',
  '/articles',
  '/asistente',
  '/capacitacion',
  '/conocimiento',
  '/diagnostic',
  '/encuestas',
  '/eventos',
  '/finanzas',
  '/foro',
  '/gamificacion',
  '/ideas',
  '/links',
  '/marketplace',
  '/mentores',
  '/myboard',
  '/network',
  '/recursos',
  '/seminars',
  '/tips'
]

function isStaticAsset(pathname: string) {
  return pathname.startsWith('/_next') || pathname.startsWith('/favicon') || pathname.includes('.')
}

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl

  if (isStaticAsset(pathname) || pathname.startsWith('/api')) {
    return NextResponse.next()
  }

  if (!hasLocalePrefix(pathname)) {
    const locale = getPreferredLocale(request, locales, defaultLocale)
    const url = request.nextUrl.clone()
    url.pathname = `/${locale}${pathname === '/' ? '' : pathname}`
    return NextResponse.redirect(url)
  }

  const [, locale, ...rest] = pathname.split('/')
  const internalPath = `/${rest.join('/')}`.replace(/\/$/, '') || '/'

  if (PUBLIC_PATHS.some((segment) => internalPath === segment || internalPath.startsWith(`${segment}/`))) {
    const token = request.cookies.get(authCookieName)?.value
    const session = token ? await decodeSessionToken(token) : null
    if (session?.sub && (internalPath === '/login' || internalPath === '/register')) {
      const nextUrl = request.nextUrl.clone()
      nextUrl.pathname = `/${locale}/${session.role === 'SUPER_ADMIN' || session.role === 'ADMIN' ? 'admin' : 'dashboard'}`
      return NextResponse.redirect(nextUrl)
    }
    return NextResponse.next()
  }

  const isProtectedArea = PLATFORM_PREFIXES.some((segment) => internalPath === segment || internalPath.startsWith(`${segment}/`))
  if (!isProtectedArea) {
    return NextResponse.next()
  }

  const token = request.cookies.get(authCookieName)?.value
  const session = token ? await decodeSessionToken(token) : null

  if (!session?.sub) {
    const loginUrl = request.nextUrl.clone()
    loginUrl.pathname = `/${locale}/login`
    loginUrl.searchParams.set('next', pathname)
    return NextResponse.redirect(loginUrl)
  }

  if (internalPath === '/' || internalPath === '/panel') {
    const nextUrl = request.nextUrl.clone()
    nextUrl.pathname = `/${locale}/${session.role === 'SUPER_ADMIN' || session.role === 'ADMIN' ? 'admin' : 'dashboard'}`
    return NextResponse.redirect(nextUrl)
  }

  if ((internalPath === ADMIN_PREFIX || internalPath.startsWith(`${ADMIN_PREFIX}/`)) && !['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    const denyUrl = request.nextUrl.clone()
    denyUrl.pathname = `/${locale}/dashboard`
    denyUrl.searchParams.set('denied', 'admin-only')
    return NextResponse.redirect(denyUrl)
  }

  const response = NextResponse.next()
  response.headers.set('x-app-role', session.role)
  response.headers.set('x-app-user-id', session.sub)
  return response
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\..*).*)']
}
