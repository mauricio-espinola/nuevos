# MicroEmprendedor — Base App Router (v0.7.1)

Base sólida para SaaS white-label sobre Next.js 16 + App Router + Prisma + Postgres.

**Estado actual:** Paso 0 + Paso 1 + Paso 1.5 (limpieza profunda) aplicados.

## Qué tiene aplicado esta versión

### Paso 0 — Limpieza de dependencias
- ✅ `package.json` limpio: sin `next-auth`, sin `next-themes`, con `pino` y `pino-pretty`

### Paso 1 — Validación de entorno
- ✅ Validación estricta con Zod (`src/lib/env.ts`)
- ✅ Schema Prisma preparado para Supabase (dual connection: `DATABASE_URL` + `DIRECT_URL`)
- ✅ Seed valida sus variables críticas antes de tocar la DB
- ✅ Todos los `process.env.X` migrados al objeto `env` validado
- ✅ `AppProviders` limpio (sin wrapper muerto de `next-themes`)

### Paso 1.5 — Limpieza profunda y fuente única de verdad
- ✅ Borrados 4 archivos fantasma no usados: `lib/auth/session.ts`, `core/tenancy/tenant.ts`, `core/runtime/instance.ts`, `core/config/app.ts`
- ✅ `site.ts` conectado al env validado (nombre y URL configurables por instancia)
- ✅ Header y footer usan `siteConfig.name` (ya no hardcoded)
- ✅ Schema, seed y configuración sin referencias a "Jotason"
- ✅ `authorization.ts` reescrito como **fuente única de verdad** de permisos y matriz de roles
- ✅ Seed importa `authorization.ts` — cero duplicación de permisos
- ✅ **ADMIN vs SUPER_ADMIN diferenciados** (Paso 9 adelantado): SUPER_ADMIN es el único que puede promover usuarios, gestionar feature flags y billing crítico

## Stack

- Next.js 16.1 (App Router, Turbopack, `typedRoutes`)
- React 19
- Prisma 6 + PostgreSQL (Supabase como proveedor)
- Zod 4 para validación de schemas y env
- Auth propio con `jose` (JWT firmado) + `bcryptjs` + tabla `Session` (revocación real)
- Tailwind CSS 4
- pino para logging estructurado

## Setup paso a paso

### 1. Instalar dependencias

```bash
npm install
```

### 2. Crear tu proyecto Supabase

1. Ir a https://supabase.com → New Project
2. Esperar que termine el provisioning
3. Ir a **Settings → Database → Connection string**
4. Copiar:
   - **Connection pooler** (puerto 6543) → será tu `DATABASE_URL`
   - **Direct connection** (puerto 5432) → será tu `DIRECT_URL`

### 3. Crear `.env`

```bash
cp .env.example .env
```

Abre `.env` y rellena:

- `DATABASE_URL` y `DIRECT_URL` con los valores de Supabase
- `AUTH_JWT_SECRET` con: `openssl rand -base64 32`
- `AUTH_SEED_ADMIN_EMAIL` con tu email real
- `AUTH_SEED_ADMIN_PASSWORD` con un password fuerte (≥ 12 caracteres)

### 4. Generar el cliente Prisma

```bash
npx prisma generate
```

### 5. Correr migraciones

```bash
npx prisma migrate dev --name foundation_auth
```

Esto crea todas las tablas en tu Supabase.

### 6. Poblar la DB con el seed

```bash
npm run db:seed
```

Esto crea:

- Los permisos base (platform.access, dashboard.read, etc.)
- Los 3 roles (USER, ADMIN, SUPER_ADMIN) con sus permisos
- El admin inicial (con las credenciales de tu `.env`)
- Feature flags iniciales
- Configuración por defecto

### 7. Arrancar en desarrollo

```bash
npm run dev
```

Abre http://localhost:3000 y haz login con las credenciales del admin.

## Checklist de verificación del Paso 1

Verifica que el hardening funciona:

### Check 1: La app falla si falta config

Temporalmente borra `AUTH_JWT_SECRET` de tu `.env` y corre:

```bash
npm run dev
```

Debe fallar con:

```
❌ Variables de entorno del servidor inválidas:
  - AUTH_JWT_SECRET: Required
```

**Vuelve a poner el secret** después de verificar.

### Check 2: La app falla si el secret es débil

Pon `AUTH_JWT_SECRET="corto"` (menos de 32 chars) en `.env` y corre:

```bash
npm run dev
```

Debe fallar con:

```
❌ Variables de entorno del servidor inválidas:
  - AUTH_JWT_SECRET: AUTH_JWT_SECRET debe tener al menos 32 caracteres...
```

**Vuelve a poner el secret correcto** después.

### Check 3: El seed falla si faltan credenciales de admin

Borra `AUTH_SEED_ADMIN_EMAIL` de `.env` y corre:

```bash
npm run db:seed
```

Debe fallar con error claro de variable faltante.

**Restaura** después.

### Check 4: Flujo funcional end-to-end

Con `.env` correcto:

1. `npm run dev`
2. Abrir http://localhost:3000
3. Ir a `/es/login`
4. Login con credenciales del admin (`AUTH_SEED_ADMIN_EMAIL` + `AUTH_SEED_ADMIN_PASSWORD`)
5. Debes ser redirigido a `/es/admin`
6. Logout → debes volver a `/es/login`

Si los 4 checks pasan, el Paso 1 está correctamente aplicado.

## Scripts disponibles

```bash
npm run dev            # Servidor de desarrollo con Turbopack
npm run build          # Build de producción
npm run start          # Arrancar build de producción
npm run lint           # ESLint
npm run typecheck      # TypeScript sin emitir archivos
npm run db:generate    # Generar cliente Prisma
npm run db:migrate     # Correr migraciones en dev
npm run db:deploy      # Correr migraciones en producción
npm run db:seed        # Poblar DB con datos iniciales
npm run db:studio      # Abrir Prisma Studio (explorador visual de DB)
```

## Estructura

```
src/
├── app/                  # App Router (pages, layouts, API)
│   ├── [locale]/         # Rutas con locale
│   │   ├── (auth)/       # Grupo: login, register
│   │   ├── (marketing)/  # Grupo: landing pública
│   │   └── (platform)/   # Grupo: dashboard, admin, módulos
│   └── api/              # Route handlers
├── components/           # Componentes compartidos (layout, providers, shell)
├── config/               # Config estática (site, modules)
├── core/                 # Primitivas transversales (auth, env, logger, etc.)
├── lib/                  # Utilidades (env validado, i18n, security, utils)
├── modules/              # Features de dominio (auth, articles, dashboard, etc.)
└── server/               # DAL, repos, services, db, audit

prisma/
├── schema.prisma         # Schema completo (111 modelos)
└── seed.ts               # Seed idempotente

proxy.ts                  # Proxy (antes middleware) para i18n + auth hints
next.config.ts            # Config Next.js + headers de seguridad
```

## Próximos pasos del hardening

Están pendientes los pasos 2-8 + 10 del plan acordado:

- Paso 2: anti-enumeration en login
- Paso 3: guards centralizados en layout (DRY)
- Paso 4: simplificar `proxy.ts`
- Paso 5: locale-aware redirects (seed + helpers)
- Paso 6: rate limiting en `/api/auth/login`
- Paso 7: logger pino estructurado activo
- Paso 8: `User.password` opcional + integrar AuditLog real
- ~~Paso 9: ADMIN vs SUPER_ADMIN diferenciados~~ ✅ **Adelantado en Paso 1.5**
- Paso 10: README + checklist de deploy

Cuando verifiques que esta versión arranca correctamente, seguimos con el Paso 2.
