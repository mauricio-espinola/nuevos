# Schema autorizado v2

Esta versión une dos fuentes:
- el **esquema funcional real** de la SPA original
- la **capa profesional nueva** para autorización, sesiones, auditoría, branding, feature flags y versionado

## Núcleo de acceso y operación
- User
- Role
- Permission
- RolePermission
- UserRoleAssignment
- Session
- AuditLog
- AppSettings
- BrandingSettings
- FeatureFlag
- SystemConfig
- NotificationTemplate
- StatisticsCache

## Estructura configurable de la aplicación
- NavSection
- LandingPageSection
- Section
- Tag

## Contenido y publicación
- Article
- ArticleTag
- ArticleBlock
- Comment
- Rating
- Postcard
- PostcardLike
- FeaturedVideo
- DailyTip
- Link
- PublicFeedback
- Study

## Ideas, canvas y conocimiento
- Idea
- CanvasSection
- NetworkNode
- IdeaRelation
- IdeaVote
- IdeaComment
- KnowledgeInsight
- InsightSource
- InsightComment

## Formación y evaluación
- Course
- CourseResource
- UserCourse
- UserProgress
- QuizQuestion
- QuizAttempt
- QuizAnswer

## Comunidad y colaboración
- ForumCategory
- ForumTopic
- ForumPost
- Poll
- PollOption
- PollVote
- PollResponse
- ChatRoom
- ChatParticipant
- ChatMessage
- Notification
- Activity
- AIConversation
- AIMessage

## Mentoría, servicios y marketplace
- Mentor
- Mentorship
- MentorshipSession
- MentorReview
- ServiceProvider
- ServiceReview
- ServiceQuote
- Purchase

## Recursos y biblioteca
- ResourceCategory
- Resource
- ResourceBlock
- ResourceDownload
- ResourceFavorite

## Finanzas y negocio
- FinancialCalculation
- Invoice
- BusinessModel
- BMCDimension
- BMCDimensionInteraction
- BusinessMistake
- MistakeReaction
- BusinessTemplate
- TemplateDownload

## Gamificación y engagement
- Badge
- UserBadge
- UserPoints
- PointTransaction
- Challenge
- ChallengeParticipation

## Eventos y seminarios
- Event
- EventBlock
- EventAttendance
- Seminar
- SeminarLike

## Diagnóstico
- DiagnosticCategory
- DiagnosticItem
- DiagnosticResult
- DiagnosticEvaluation

## MyBoard y analítica
- MBDataset
- MBDataColumn
- MBDataTransformation
- MBDataJoin
- MBVisualization
- MBDataShare
- MBVisualizationShare
- MBAnalysisTemplate

## Versionado y actualizaciones
- AppRelease
- AppReleaseNote
- AppUpdateRun
- SchemaVersion

## Criterio arquitectónico
- La SPA original sigue siendo la **fuente funcional de referencia**.
- Este schema pasa a ser la **fuente oficial autorizada** para la nueva base.
- Los nuevos módulos deben nacer aquí, no como agregados ad hoc al frontend.
- Las evoluciones futuras deben entrar por migraciones y documentación de versión.
