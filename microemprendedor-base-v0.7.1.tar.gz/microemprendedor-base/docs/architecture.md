# Architecture Foundation v6

## Qué quedó operativo primero

- App Router con route groups para marketing, auth y platform.
- `proxy.ts` como puerta de acceso por sesión y rol.
- Auth por credenciales con cookie HttpOnly firmada.
- Persistencia de sesiones en Prisma.
- Redirección por rol: admin/super admin a `/admin`, usuario a `/dashboard`.
- Seed con usuario inicial, roles, permisos y feature flags.

## Flujo de auth actual

1. El usuario hace login o registro vía `/api/auth/*`.
2. Se crea un JWT firmado para la cookie segura.
3. También se registra una fila en `Session`.
4. `proxy.ts` lee la cookie y deriva acceso general por rol.
5. Los guards del servidor validan acceso fino por ruta.

## Qué se dejó listo para la siguiente fase

- Panel admin para gobernar roles, flags, branding y releases.
- `FeatureFlag` ya poblado para controlar módulos sin tocar código.
- `Articles` como siguiente módulo real a conectar a DB.
