import bcrypt from 'bcryptjs'
import { PrismaClient, UserRole, FeatureFlagState, ReleaseStatus, AccountStatus } from '@prisma/client'
import { z } from 'zod'
import {
  permissionCatalog,
  roleMatrix,
  roleDisplayNames,
  type PermissionCode,
} from '../src/core/security/authorization'

/**
 * Validación de variables requeridas por el seed.
 *
 * El seed es un script independiente (corre con `tsx` fuera de Next.js),
 * por eso no puede importar `@/lib/env` y valida sus propias vars aquí.
 *
 * Si faltan o son inválidas, el seed falla ANTES de tocar la base de datos.
 */
const seedEnv = z
  .object({
    AUTH_SEED_ADMIN_EMAIL: z
      .string()
      .email('AUTH_SEED_ADMIN_EMAIL debe ser un email válido'),
    AUTH_SEED_ADMIN_PASSWORD: z
      .string()
      .min(
        12,
        'AUTH_SEED_ADMIN_PASSWORD debe tener al menos 12 caracteres'
      ),
  })
  .safeParse({
    AUTH_SEED_ADMIN_EMAIL: process.env.AUTH_SEED_ADMIN_EMAIL,
    AUTH_SEED_ADMIN_PASSWORD: process.env.AUTH_SEED_ADMIN_PASSWORD,
  })

if (!seedEnv.success) {
  console.error(
    '\n❌ Variables requeridas por el seed inválidas o faltantes:\n' +
      seedEnv.error.issues
        .map((i) => `  - ${i.path.join('.')}: ${i.message}`)
        .join('\n') +
      '\n\n→ Revisa tu .env y asegúrate de tener estas variables seteadas.\n'
  )
  process.exit(1)
}

const ADMIN_EMAIL = seedEnv.data.AUTH_SEED_ADMIN_EMAIL
const ADMIN_PASSWORD = seedEnv.data.AUTH_SEED_ADMIN_PASSWORD

const prisma = new PrismaClient()

const featureFlags = [
  ['core.auth', 'Autenticación', 'core', true],
  ['core.audit_logs', 'Auditoría', 'core', true],
  ['core.notifications', 'Notificaciones', 'core', true],
  ['core.activity_tracking', 'Actividad', 'core', true],
  ['core.app_settings', 'Ajustes de app', 'core', true],
  ['core.branding', 'Branding', 'core', true],
  ['core.navigation_config', 'Navegación configurable', 'core', true],
  ['core.system_config', 'Configuración de sistema', 'core', true],
  ['core.releases', 'Releases', 'core', true],
  ['core.schema_versioning', 'Versionado de esquema', 'core', true],
  ['module.dashboard', 'Dashboard', 'module', true],
  ['module.admin', 'Admin', 'module', true],
  ['module.articles', 'Artículos', 'module', true],
  ['module.links', 'Links', 'module', true],
  ['module.tips', 'Tips', 'module', true],
  ['module.capacitacion', 'Capacitación', 'module', false],
  ['module.conocimiento', 'Conocimiento', 'module', false],
  ['module.ideas', 'Ideas', 'module', false],
  ['module.recursos', 'Recursos', 'module', false],
  ['module.foro', 'Foro', 'module', false],
  ['module.encuestas', 'Encuestas', 'module', false],
  ['module.network', 'Network', 'module', false],
  ['module.eventos', 'Eventos', 'module', false],
  ['module.seminars', 'Seminars', 'module', false],
  ['module.marketplace', 'Marketplace', 'module', false],
  ['module.finanzas', 'Finanzas', 'module', false],
  ['module.mentores', 'Mentores', 'module', false],
  ['module.gamificacion', 'Gamificación', 'module', false],
  ['module.myboard', 'MyBoard', 'module', false],
  ['module.diagnostic', 'Diagnostic', 'module', false],
  ['capability.admin.user_management', 'Gestión de usuarios', 'capability', true],
  ['capability.admin.roles_permissions', 'Roles y permisos', 'capability', true],
  ['capability.admin.feature_flags', 'Feature flags', 'capability', true],
  ['capability.admin.system_settings', 'Configuración del sistema', 'capability', true],
  ['capability.admin.audit_view', 'Vista de auditoría', 'capability', true],
  ['capability.dashboard.activity_feed', 'Feed de actividad', 'capability', true],
  ['capability.articles.tags', 'Tags de artículos', 'capability', true],
  ['capability.articles.blocks', 'Bloques de artículos', 'capability', true],
  ['capability.articles.comments', 'Comentarios en artículos', 'capability', false],
  ['capability.marketplace.checkout', 'Checkout de marketplace', 'capability', false],
  ['experimental.ai_assistant_v2', 'Asistente v2', 'experimental', false],
]

async function upsertRole(code: UserRole, name: string, permissionCodes: string[]) {
  const role = await prisma.role.upsert({
    where: { code },
    update: { name },
    create: { code, name },
  })

  const permissions = await prisma.permission.findMany({ where: { code: { in: permissionCodes } } })
  for (const permission of permissions) {
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: role.id, permissionId: permission.id } },
      update: {},
      create: { roleId: role.id, permissionId: permission.id },
    })
  }
}

async function main() {
  // Poblar permisos desde el catálogo único
  for (const [code, name] of Object.entries(permissionCatalog)) {
    await prisma.permission.upsert({
      where: { code },
      update: { name },
      create: { code, name },
    })
  }

  // Poblar roles con sus permisos desde la matriz única
  for (const [roleCode, permissions] of Object.entries(roleMatrix) as [
    keyof typeof roleMatrix,
    PermissionCode[]
  ][]) {
    await upsertRole(
      roleCode as UserRole,
      roleDisplayNames[roleCode],
      permissions
    )
  }

  const appName = process.env.NEXT_PUBLIC_APP_NAME || 'MicroEmprendedor'

  await prisma.appSettings.upsert({
    where: { id: 'app-settings-default' },
    update: { appName, allowSelfRegistration: true },
    create: {
      id: 'app-settings-default',
      appName,
      defaultLocale: 'es',
      timezone: 'America/Santiago',
      allowSelfRegistration: true,
    },
  })

  await prisma.brandingSettings.upsert({
    where: { id: 'branding-default' },
    update: { companyName: appName, productName: appName },
    create: {
      id: 'branding-default',
      companyName: appName,
      productName: appName,
      marketingHeadline: 'Plataforma modular para microempresarios.',
    },
  })

  const nav = [
    ['dashboard', 'Dashboard', '/es/dashboard', false, 1],
    ['articles', 'Artículos', '/es/articles', false, 2],
    ['panel', 'Panel', '/es/panel', false, 3],
    ['admin', 'Admin', '/es/admin', true, 4],
  ] as const

  for (const [key, label, route, adminOnly, order] of nav) {
    await prisma.navSection.upsert({
      where: { key },
      update: { label, route, adminOnly, order },
      create: { key, label, route, adminOnly, order },
    })
  }

  for (const [key, name, category, enabled] of featureFlags) {
    await prisma.featureFlag.upsert({
      where: { key },
      update: { name, description: category, state: enabled ? FeatureFlagState.ENABLED : FeatureFlagState.DISABLED },
      create: { key, name, description: category, state: enabled ? FeatureFlagState.ENABLED : FeatureFlagState.DISABLED },
    })
  }

  await prisma.appRelease.upsert({
    where: { version: '0.6.0' },
    update: { title: 'Auth foundation on App Router', status: ReleaseStatus.RELEASED, releasedAt: new Date() },
    create: { version: '0.6.0', title: 'Auth foundation on App Router', status: ReleaseStatus.RELEASED, releasedAt: new Date() },
  })

  await prisma.schemaVersion.upsert({
    where: { version: 'v1-foundation-auth' },
    update: { description: 'Foundation schema with auth, roles, flags, content and releases' },
    create: {
      version: 'v1-foundation-auth',
      description: 'Foundation schema with auth, roles, flags, content and releases',
    },
  })

  const adminHash = await bcrypt.hash(ADMIN_PASSWORD, 12)

  const admin = await prisma.user.upsert({
    where: { email: ADMIN_EMAIL.toLowerCase() },
    update: {
      password: adminHash,
      name: 'Administrador inicial',
      role: UserRole.SUPER_ADMIN,
      status: AccountStatus.ACTIVE,
      authProvider: 'CREDENTIALS',
    },
    create: {
      email: ADMIN_EMAIL.toLowerCase(),
      password: adminHash,
      name: 'Administrador inicial',
      role: UserRole.SUPER_ADMIN,
      status: AccountStatus.ACTIVE,
      authProvider: 'CREDENTIALS',
    },
  })

  const superAdminRole = await prisma.role.findUnique({ where: { code: UserRole.SUPER_ADMIN } })
  if (superAdminRole) {
    await prisma.userRoleAssignment.upsert({
      where: { userId_roleId: { userId: admin.id, roleId: superAdminRole.id } },
      update: { isPrimary: true },
      create: { userId: admin.id, roleId: superAdminRole.id, isPrimary: true },
    })
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (error) => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
