import { create } from 'zustand';
import type { 
  UserProfile, BankAccount, Transaction, TopicProgress, 
  Achievement, Reward, ChatMessage, AppView, ScenarioRun 
} from '@/types/fini';

interface FiniState {
  currentView: AppView;
  selectedTopicId: string | null;
  previousView: AppView | null;
  user: UserProfile | null;
  bankAccount: BankAccount | null;
  transactions: Transaction[];
  topicProgress: TopicProgress[];
  activeScenario: ScenarioRun | null;
  achievements: Achievement[];
  rewards: Reward[];
  chatMessages: ChatMessage[];
  isDonBancoVisible: boolean;
  donBancoMessage: string;
  isLoading: boolean;
  toastMessage: string | null;

  navigate: (view: AppView) => void;
  goBack: () => void;
  setSelectedTopicId: (id: string | null) => void;
  setUser: (user: UserProfile) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  setBankAccount: (account: BankAccount) => void;
  setTransactions: (transactions: Transaction[]) => void;
  addTransaction: (transaction: Transaction) => void;
  setTopicProgress: (progress: TopicProgress[]) => void;
  updateTopicProgress: (topicId: string, updates: Partial<TopicProgress>) => void;
  setActiveScenario: (scenario: ScenarioRun | null) => void;
  setAchievements: (achievements: Achievement[]) => void;
  setRewards: (rewards: Reward[]) => void;
  setChatMessages: (messages: ChatMessage[]) => void;
  addChatMessage: (message: ChatMessage) => void;
  showDonBanco: (message: string) => void;
  hideDonBanco: () => void;
  setLoading: (loading: boolean) => void;
  showToast: (message: string) => void;
  hideToast: () => void;
}

export const useFiniStore = create<FiniState>((set, get) => ({
  currentView: 'onboarding',
  selectedTopicId: null,
  previousView: null,
  user: null,
  bankAccount: null,
  transactions: [],
  topicProgress: [],
  activeScenario: null,
  achievements: [],
  rewards: [],
  chatMessages: [],
  isDonBancoVisible: false,
  donBancoMessage: '',
  isLoading: false,
  toastMessage: null,

  navigate: (view) => set((state) => ({ 
    previousView: state.currentView, 
    currentView: view 
  })),
  goBack: () => set((state) => ({ 
    currentView: state.previousView || 'dashboard',
    previousView: null 
  })),
  setSelectedTopicId: (id) => set({ selectedTopicId: id }),
  setUser: (user) => set({ user, currentView: 'dashboard' }),
  updateUser: (updates) => set((state) => ({ 
    user: state.user ? { ...state.user, ...updates } : null 
  })),
  setBankAccount: (account) => set({ bankAccount: account }),
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (transaction) => set((state) => ({ 
    transactions: [transaction, ...state.transactions],
    bankAccount: state.bankAccount 
      ? { ...state.bankAccount, balance: transaction.balanceAfter }
      : null
  })),
  setTopicProgress: (topicProgress) => set({ topicProgress }),
  updateTopicProgress: (topicId, updates) => set((state) => ({
    topicProgress: state.topicProgress.map((tp) => 
      tp.topicId === topicId ? { ...tp, ...updates } : tp
    )
  })),
  setActiveScenario: (scenario) => set({ activeScenario: scenario }),
  setAchievements: (achievements) => set({ achievements }),
  setRewards: (rewards) => set({ rewards }),
  setChatMessages: (messages) => set({ chatMessages: messages }),
  addChatMessage: (message) => set((state) => ({ 
    chatMessages: [...state.chatMessages, message] 
  })),
  showDonBanco: (message) => set({ isDonBancoVisible: true, donBancoMessage: message }),
  hideDonBanco: () => set({ isDonBancoVisible: false, donBancoMessage: '' }),
  setLoading: (loading) => set({ isLoading: loading }),
  showToast: (message) => set({ toastMessage: message }),
  hideToast: () => set({ toastMessage: null }),
}));
