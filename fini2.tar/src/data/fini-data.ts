import type { Topic } from '@/types/fini';

export const TOPICS: Topic[] = [
  { id: 'interes-compuesto', title: 'Interés Compuesto', icon: '📈', description: 'Descubre cómo tu dinero puede crecer solo con el paso del tiempo.', order: 1 },
  { id: 'presupuesto', title: 'Presupuesto Personal', icon: '💰', description: 'Aprende a organizar tu plata para que no te falte a fin de mes.', order: 2 },
  { id: 'ahorro-vs-gasto', title: 'Ahorro vs Gasto', icon: '🏦', description: '¿Comprar ahora o guardar para después? Entiende el valor de la paciencia.', order: 3 },
  { id: 'deuda-buena-mala', title: 'Deuda Buena vs Mala', icon: '⚖️', description: 'No toda la deuda es igual. Aprende a distinguir cuándo conviene.', order: 4 },
  { id: 'tarjeta-debito-credito', title: 'Débito vs Crédito', icon: '💳', description: '¿Cuál es la diferencia real entre tu tarjeta de débito y una de crédito?', order: 5 },
  { id: 'linea-credito', title: 'Línea de Crédito', icon: '🔗', description: '¿Qué es exactamente una línea de crédito y por qué los bancos te la ofrecen?', order: 6 },
  { id: 'score-crediticio', title: 'Score Crediticio', icon: '⭐', description: 'Tu "notita" financiera: qué es, cómo se construye y por qué importa.', order: 7 },
  { id: 'inflacion', title: 'Inflación', icon: '🔥', description: '¿Por qué todo sube de precio? Entiende la inflación y cómo te afecta.', order: 8 },
  { id: 'inversion-basica', title: 'Inversión Básica', icon: '📊', description: 'Riesgo y retorno: los dos lados de la moneda en el mundo de las inversiones.', order: 9 },
];

export const COMMERCES = [
  { name: 'Farmacia La Tercera', category: 'salud', icon: '💊' },
  { name: 'Jumbo Express', category: 'comida', icon: '🛒' },
  { name: 'Tienda La Polar', category: 'ropa', icon: '👕' },
  { name: 'McDonald\'s', category: 'comida', icon: '🍔' },
  { name: 'Cinemark', category: 'ocio', icon: '🎬' },
  { name: 'Steam Store', category: 'ocio', icon: '🎮' },
  { name: 'Transantiago Bip!', category: 'transporte', icon: '🚌' },
  { name: 'Spotify Chile', category: 'ocio', icon: '🎵' },
  { name: 'Mall Plaza', category: 'ropa', icon: '🏬' },
  { name: 'Librería Antártica', category: 'educacion', icon: '📚' },
  { name: 'Subway', category: 'comida', icon: '🥪' },
  { name: 'Movistar', category: 'servicios', icon: '📱' },
  { name: 'Líder Express', category: 'comida', icon: '🛍️' },
  { name: 'Donde Rafa', category: 'comida', icon: '🌮' },
  { name: 'Zapatillería Fenis', category: 'ropa', icon: '👟' },
  { name: 'Convenience Store', category: 'comida', icon: '🏪' },
];

export const CATEGORY_COLORS: Record<string, string> = {
  comida: '#f97316',
  transporte: '#3b82f6',
  ocio: '#8b5cf6',
  ropa: '#ec4899',
  salud: '#10b981',
  educacion: '#6366f1',
  servicios: '#64748b',
  ahorro: '#22c55e',
  otro: '#94a3b8',
};

export const CATEGORY_ICONS: Record<string, string> = {
  comida: '🍔', transporte: '🚌', ocio: '🎮', ropa: '👕',
  salud: '💊', educacion: '📚', servicios: '📱', ahorro: '💰', otro: '📌',
};

export const ACHIEVEMENTS_DATA = [
  { id: 'first-budget', name: 'Primer Presupuesto', description: 'Creaste tu primer presupuesto mensual', icon: '📋', condition: 'create_budget', points: 50 },
  { id: 'mes-sin-sobregiro', name: 'Mes en Verde', description: 'Completaste un mes sin quedarte sin plata', icon: '💚', condition: 'month_positive', points: 100 },
  { id: 'modulo-compuesto', name: 'Maestro del Interés', description: 'Completaste el módulo de interés compuesto', icon: '📈', condition: 'complete_topic_interes-compuesto', points: 75 },
  { id: 'decisiones-ai', name: 'Sabio Consejero', description: 'Tomaste 10 decisiones recomendadas por FINI AI', icon: '🤖', condition: 'ai_recommendations_10', points: 150 },
  { id: 'ahorrador-nato', name: 'Ahorrador Nato', description: 'Ahorriste más del 30% de tu asignación 3 meses seguidos', icon: '🐷', condition: 'save_30_percent_3months', points: 200 },
  { id: 'racha-7', name: 'En Racha', description: 'Usaste FINI 7 días seguidos', icon: '🔥', condition: 'streak_7', points: 100 },
  { id: 'racha-30', name: 'Imparable', description: 'Usaste FINI 30 días seguidos', icon: '⚡', condition: 'streak_30', points: 300 },
  { id: 'guru-financiero', name: 'Gurú Financiero', icon: '🏆', description: 'Alcanzaste el nivel máximo', condition: 'level_max', points: 500 },
  { id: 'primer-gasto', name: 'Primera Compra', description: 'Hiciste tu primera compra con la tarjeta', icon: '🛒', condition: 'first_purchase', points: 25 },
  { id: 'quiz-perfecto', name: 'Nota Perfecta', description: 'Sacaste 100% en un quiz de la Academia', icon: '💯', condition: 'perfect_quiz', points: 100 },
];

export const REWARDS_DATA = [
  { id: 'r1', name: 'Skin Exclusiva para Tarjeta', description: 'Desbloquea un diseño especial para tu tarjeta virtual FINI', pointCost: 200, quantity: -1, sponsorName: 'FINI', available: true },
  { id: 'r2', name: 'Acceso a Módulo Premium', description: 'Desbloquea contenido avanzado de inversión', pointCost: 500, quantity: -1, sponsorName: 'FINI', available: true },
  { id: 'r3', name: 'Sticker Pack Digital', description: 'Pack de stickers FINI para tus redes sociales', pointCost: 100, quantity: -1, sponsorName: 'FINI', available: true },
  { id: 'r4', name: 'Cupon Descuento Falabella', description: '10% de descuento en Falabella por ser usuario FINI', pointCost: 800, quantity: 50, sponsorName: 'Falabella', available: true },
  { id: 'r5', name: '1 Mes Spotify Premium', description: 'Un mes gratis de Spotify Premium', pointCost: 1200, quantity: 20, sponsorName: 'Spotify Chile', available: true },
  { id: 'r6', name: 'Gift Card Jumbo $5.000', description: 'Gift card de $5.000 para compras en Jumbo', pointCost: 1500, quantity: 30, sponsorName: 'Cencosud', available: true },
];

export const SCENARIO_EVENTS = {
  sin_control: [
    { id: 'sc1', description: 'Te invitan a salir con amigos a comer pizza 🍕', amount: 8500, category: 'comida', isRecommended: false, commerce: 'Donde Rafa' },
    { id: 'sc2', description: 'Sale un videojuego que querías mucho en oferta 🎮', amount: 25000, category: 'ocio', isRecommended: false, commerce: 'Steam Store' },
    { id: 'sc3', description: 'Te ofrecen un par de zapatillas nuevas a buen precio 👟', amount: 35000, category: 'ropa', isRecommended: false, commerce: 'Zapatillería Fenis' },
    { id: 'sc4', description: 'Quieres invitar polola/o al cine 🎬', amount: 6500, category: 'ocio', isRecommended: false, commerce: 'Cinemark' },
    { id: 'sc5', description: 'Te piden recargar la bip para la semana 🚌', amount: 5000, category: 'transporte', isRecommended: true, commerce: 'Transantiago Bip!' },
    { id: 'sc6', description: 'Sale un concierto de tu artista favorito 🎵', amount: 20000, category: 'ocio', isRecommended: false, commerce: 'Spotify Chile' },
    { id: 'sc7', description: 'Tu amigo te ofrece prestarte $10.000 con 10% de interés', amount: 10000, category: 'otro', isRecommended: false, commerce: null },
    { id: 'sc8', description: 'Encuentras una oferta en ropa de invierno 🧥', amount: 15000, category: 'ropa', isRecommended: false, commerce: 'Tienda La Polar' },
    { id: 'sc9', description: 'Tienes que comprar útiles para el colegio 📚', amount: 8000, category: 'educacion', isRecommended: true, commerce: 'Librería Antártica' },
    { id: 'sc10', description: 'Te ofrecen un crédito en el mall para comprar lo que quieras', amount: 50000, category: 'otro', isRecommended: false, commerce: 'Mall Plaza' },
  ],
  controlado: [
    { id: 'co1', description: 'Comida de la semana en el supermercado 🛒', amount: 12000, category: 'comida', isRecommended: true, commerce: 'Jumbo Express' },
    { id: 'co2', description: 'Salida con amigos al cine 🎬', amount: 5000, category: 'ocio', isRecommended: true, commerce: 'Cinemark' },
    { id: 'co3', description: 'Carga Bip para transporte semanal 🚌', amount: 5000, category: 'transporte', isRecommended: true, commerce: 'Transantiago Bip!' },
    { id: 'co4', description: 'Un café con amigos ☕', amount: 3500, category: 'comida', isRecommended: true, commerce: 'Subway' },
    { id: 'co5', description: 'Quieres ahorrar una parte de tu asignación 💰', amount: 15000, category: 'ahorro', isRecommended: true, commerce: null },
    { id: 'co6', description: 'Encuentras una oferta de ropa 🧥', amount: 18000, category: 'ropa', isRecommended: false, commerce: 'Tienda La Polar' },
    { id: 'co7', description: 'Videojuego nuevo en oferta 🎮', amount: 22000, category: 'ocio', isRecommended: false, commerce: 'Steam Store' },
  ],
};

export const TOPIC_QUIZZES: Record<string, { question: string; options: string[]; correctIndex: number }[]> = {
  'interes-compuesto': [
    { question: '¿Qué es el interés compuesto?', options: ['Interés que se cobra solo una vez', 'Interés que se calcula sobre el capital acumulado', 'Interés que baja con el tiempo', 'Un tipo de impuesto'], correctIndex: 1 },
    { question: 'Si inviertes $100.000 al 10% anual con interés compuesto, ¿cuánto tendrás después de 2 años (aprox)?', options: ['$110.000', '$120.000', '$121.000', '$200.000'], correctIndex: 2 },
    { question: '¿Por qué el interés compuesto se llama "la octava maravilla del mundo"?', options: ['Porque es muy complicado', 'Porque hace que tu dinero crezca exponencialmente', 'Porque solo los ricos lo usan', 'Porque es un invento nuevo'], correctIndex: 1 },
  ],
  'presupuesto': [
    { question: '¿Qué es un presupuesto?', options: ['Una lista de deseos', 'Un plan de cómo gastar tu plata', 'Un préstamo del banco', 'El saldo de tu cuenta'], correctIndex: 1 },
    { question: '¿Cuál es la regla 50/30/20?', options: ['50% ropa, 30% comida, 20% ahorro', '50% necesidades, 30% gustos, 20% ahorro', '50% ahorro, 30% deuda, 20% comida', 'No es una regla real'], correctIndex: 1 },
    { question: '¿Qué deberías hacer primero al crear un presupuesto?', options: ['Gastar todo al inicio del mes', 'Identificar tus ingresos y gastos fijos', 'Pedir un préstamo', 'No hacer nada, ver qué pasa'], correctIndex: 1 },
  ],
  'ahorro-vs-gasto': [
    { question: '¿Qué es el ahorro?', options: ['Gastar menos de lo que ganas y guardar la diferencia', 'Comprar cosas baratas', 'No gastar nunca', 'Poner plata bajo el colchón'], correctIndex: 0 },
    { question: '¿Por qué es importante tener un fondo de emergencia?', options: ['Para comprar cosas caras', 'Para sorpresas como gastos médicos o reparaciones', 'Para mostrar que tienes plata', 'No es importante'], correctIndex: 1 },
    { question: '¿Qué es el "costo de oportunidad"?', options: ['Lo que pagas por algo', 'A lo que renuncias cuando eliges gastar en algo', 'El precio de un crédito', 'Una multa bancaria'], correctIndex: 1 },
  ],
  'deuda-buena-mala': [
    { question: '¿Qué es una deuda "buena"?', options: ['Cualquier deuda con interés bajo', 'Una que te ayuda a generar más valor en el futuro', 'Una deuda pequeña', 'Una que puedes pagar rápido'], correctIndex: 1 },
    { question: '¿Cuál es un ejemplo de deuda mala?', options: ['Un crédito para estudiar', 'Comprar ropa de marca con tarjeta de crédito al máximo', 'Un crédito hipotecario', 'Un préstamo para un negocio'], correctIndex: 1 },
    { question: '¿Qué es el CAE?', options: ['Costo Anual Equivalente: mide el costo real de un crédito', 'Un tipo de cuenta bancaria', 'Un impuesto', 'Una app de Finanzas'], correctIndex: 0 },
  ],
  'tarjeta-debito-credito': [
    { question: '¿De dónde sale la plata cuando pagas con tarjeta de débito?', options: ['El banco te la presta', 'De tu cuenta vista directamente', 'De una línea de crédito', 'Es plata gratis'], correctIndex: 1 },
    { question: '¿Qué pasa si no pagas el total de tu tarjeta de crédito a fin de mes?', options: ['Nada', 'Te cobran intereses sobre lo que quedaste debiendo', 'Te cierran la cuenta', 'Te regalan puntos'], correctIndex: 1 },
    { question: '¿Cuál es la ventaja principal de una tarjeta de crédito?', options: ['Es plata gratis', 'Puedes diferir pagos y construir historial crediticio', 'Siempre es mejor que débito', 'Te dan más plata'], correctIndex: 1 },
  ],
  'linea-credito': [
    { question: '¿Qué es una línea de crédito?', options: ['Un tipo de cuenta vista', 'Un monto máximo que el banco te presta cuando lo necesitas', 'Un seguro de vida', 'Una tarjeta de regalo'], correctIndex: 1 },
    { question: '¿Por qué un menor de edad NO puede tener línea de crédito en Chile?', options: ['Por capricho del banco', 'Porque legalmente no puede firmar contratos vinculantes', 'Porque es muy caro', 'Porque no tiene RUT'], correctIndex: 1 },
    { question: '¿Cuándo conviene usar una línea de crédito?', options: ['Siempre que quieras', 'Solo en emergencias reales o inversiones que generen más valor', 'Nunca conviene', 'Para comprar ropa'], correctIndex: 1 },
  ],
  'score-crediticio': [
    { question: '¿Qué es el score crediticio?', options: ['Una nota en el colegio', 'Un número que indica qué tan confiable eres pagando deudas', 'Tu saldo bancario', 'Los puntos FINI'], correctIndex: 1 },
    { question: '¿Qué actions mejoran tu score crediticio?', options: ['Pedir muchos créditos', 'Pagar tus deudas a tiempo', 'No tener cuenta bancaria', 'Gastar más'], correctIndex: 1 },
    { question: '¿Quién registra tu historial crediticio en Chile?', options: ['El gobierno', 'Entidades como Equifax o DICOM', 'Los colegios', 'Tu familia'], correctIndex: 1 },
  ],
  'inflacion': [
    { question: '¿Qué es la inflación?', options: ['Cuando la plata vale más', 'El aumento general de precios de bienes y servicios', 'Cuando todo está en oferta', 'Un tipo de interés'], correctIndex: 1 },
    { question: 'Si la inflación es 5% anual y tu plata en el banco gana 2%, ¿qué pasa?', options: ['Te haces más rico', 'Tu plata pierde poder de compra', 'Nada cambia', 'Ganas más intereses'], correctIndex: 1 },
    { question: '¿Qué es la UF?', options: ['Una moneda extranjera', 'Unidad de Fomento: se ajusta con la inflación', 'Un tipo de cuenta', 'Una app de finanzas'], correctIndex: 1 },
  ],
  'inversion-basica': [
    { question: '¿Qué significa que una inversión tiene "riesgo"?', options: ['Es segura', 'Puedes perder parte o todo tu dinero', 'Es gratis', 'Es para ricos'], correctIndex: 1 },
    { question: '¿Cuál es la relación entre riesgo y retorno?', options: ['No hay relación', 'Mayor riesgo puede significar mayor retorno, pero también mayor pérdida', 'Menor riesgo es mejor siempre', 'Solo importa el retorno'], correctIndex: 1 },
    { question: '¿Qué es la diversificación en inversiones?', options: ['Invertir todo en una cosa', 'Repartir tu dinero entre diferentes tipos de inversión', 'No invertir', 'Invertir solo en plata segura'], correctIndex: 1 },
  ],
};

export const TOPIC_EXPLANATIONS: Record<string, string> = {
  'interes-compuesto': 'El interés compuesto es como una bola de nieve que rueda por una colina: empieza pequeña pero crece cada vez más rápido. Funciona así: los intereses que ganas se suman a tu capital, y el próximo período calculas intereses sobre un monto más grande. Con el interés simple solo ganas sobre lo que pusiste al inicio. Con el compuesto, ganas sobre lo que pusiste MÁS los intereses anteriores. Por eso es "la octava maravilla del mundo": el tiempo es tu mejor amigo aquí.',
  'presupuesto': 'Un presupuesto no es una cárcel para tu plata, es un mapa que te dice a dónde va cada peso. La regla más útil es la 50/30/20: 50% para necesidades (comida, transporte, útiles), 30% para gustos (salida con amigos, ropa, hobbies) y 20% para ahorro. Así siempre sabes si estás bien o si te estás pasando. Lo clave es registrarte: anota cada gasto, por pequeño que sea.',
  'ahorro-vs-gasto': 'Ahorrar no es no gastar nunca, es decidir conscientemente que algo vale más mañana que hoy. Cada vez que compras algo, piensa en el costo de oportunidad: ¿qué más podrías hacer con esa plata? El fondo de emergencia es tu red de seguridad: equivale a 3-6 meses de gastos básicos. Si te pasa algo inesperado, no necesitas endeudarte.',
  'deuda-buena-mala': 'Una deuda buena es aquella que genera valor en el futuro: un crédito para estudiar, una hipoteca para tu casa. Una deuda mala es gastar en cosas que pierden valor al instante con plata prestada. El CAE (Costo Anual Equivalente) te muestra el costo REAL de un crédito incluyendo comisiones. Siempre compara CAE antes de pedir un crédito. Una diferencia de 1% puede significar miles de pesos extra.',
  'tarjeta-debito-credito': 'Con débito: la plata sale al toque de tu cuenta. Si no tienes, no puedes pagar. Con crédito: el banco te presta la plata y tienes hasta 30 días para pagarla sin interés. Si no pagas todo, te cobran intereses altísimos (pueden ser 30-40% anual). La clave: paga SIEMPRE el total. Si no puedes pagar el total, ya no deberías usar la tarjeta.',
  'linea-credito': 'Una línea de crédito es como tener un "plafón" de plata disponible del banco que puedes usar cuando quieras. Solo pagas intereses por lo que usas, no por todo el monto disponible. Los menores de edad no pueden tener una porque legalmente no pueden comprometerse con contratos financieros. Para obtener una cuando seas adulto, necesitas buenos ingresos y un buen historial crediticio.',
  'score-crediticio': 'Tu score crediticio es como una nota de 300 a 850 que dice qué tan buen pagador eres. Pagar a tiempo lo sube, atrasarte lo baja. En Chile, entidades como Equifax o el DICOM registran tu historial. Un buen score te permite mejores tasas de interés, más crédito y mejores condiciones. Un mal score puede impedirte alquilar un departamento o incluso conseguir trabajo. ¡Empieza a construirlo desde joven!',
  'inflacion': 'La inflación es el enemigo silencioso de tu plata. Cuando sube, los precios suben pero tu sueldo quizás no tanto al mismo ritmo. La UF (Unidad de Fomento) es una unidad que se ajusta con la inflación: hoy vale más que ayer y mañana valdrá más que hoy. Por eso, dejar tu plata debajo del colchón o en una cuenta que no gana intereses es perder dinero sin darse cuenta. Necesitas que tu plata crezca más rápido que la inflación.',
  'inversion-basica': 'Invertir es usar tu plata para generar más plata. Toda inversión tiene riesgo: la posibilidad de perder dinero. Pero también tiene retorno potencial: la posibilidad de ganar. La regla de oro es diversificar: no pongas todos los huevos en una canasta. Desde joven, tu mayor ventaja es el TIEMPO: tienes décadas para que el interés compuesto trabaje a tu favor. Incluso pequeñas cantidades invertidas temprano pueden crecer muchísimo.',
};
