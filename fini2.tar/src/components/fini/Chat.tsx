'use client';

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useFiniStore } from '@/store/fini';
import { Send, Bot, User, Sparkles, X } from 'lucide-react';

// ── Constants ──────────────────────────────────────────────────────────────

const GREETING_MESSAGE: Omit<ChatMessage, 'id' | 'createdAt'> = {
  role: 'assistant',
  content:
    '¡Hola! Soy FINI AI, tu asesor financiero personal. Pregúntame lo que quieras sobre plata, ahorro, inversiones o cualquier tema financiero. ¡Estoy para ayudarte! 💚',
};

// ── Helpers ────────────────────────────────────────────────────────────────

function generateId(): string {
  return `msg-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

interface InlineMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

/**
 * Simple markdown-to-JSX renderer.
 * Handles: **bold**, - bullet lists, ### headers, and newlines.
 */
function renderMarkdown(text: string) {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];
  let listKey = 0;

  const flushList = () => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={`list-${listKey++}`} className="list-disc list-inside space-y-1 ml-1">
          {listItems.map((item, i) => (
            <li
              key={`li-${listKey}-${i}`}
              className="leading-relaxed"
              dangerouslySetInnerHTML={{
                __html: renderInlineFormatting(item),
              }}
            />
          ))}
        </ul>,
      );
      listItems = [];
    }
  };

  lines.forEach((line, idx) => {
    const trimmed = line.trim();

    // Empty line
    if (trimmed === '') {
      flushList();
      return;
    }

    // Bullet list item
    if (trimmed.startsWith('- ') || trimmed.startsWith('• ') || trimmed.startsWith('* ')) {
      flushList();
      listItems.push(trimmed.replace(/^[-•*]\s+/, ''));
      return;
    }

    // Flush any pending list before non-list content
    flushList();

    // Header
    if (trimmed.startsWith('### ')) {
      elements.push(
        <p key={`h3-${idx}`} className="font-semibold mt-3 mb-1">
          {trimmed.slice(4)}
        </p>,
      );
      return;
    }
    if (trimmed.startsWith('## ')) {
      elements.push(
        <p key={`h2-${idx}`} className="font-bold text-lg mt-3 mb-1">
          {trimmed.slice(3)}
        </p>,
      );
      return;
    }
    if (trimmed.startsWith('# ')) {
      elements.push(
        <p key={`h1-${idx}`} className="font-bold text-xl mt-3 mb-1">
          {trimmed.slice(2)}
        </p>,
      );
      return;
    }

    // Regular paragraph
    elements.push(
      <p
        key={`p-${idx}`}
        className="leading-relaxed"
        dangerouslySetInnerHTML={{
          __html: renderInlineFormatting(trimmed),
        }}
      />,
    );
  });

  flushList();

  return elements;
}

/** Handles **bold** and `code` inline. */
function renderInlineFormatting(text: string): string {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.*?)`/g, '<code class="bg-muted px-1.5 py-0.5 rounded text-xs font-mono">$1</code>');
}

// ── Typing Indicator ───────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex items-center gap-3 px-4 py-2">
      {/* AI Avatar */}
      <div className="relative shrink-0">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center ring-2 ring-fini-green/20">
          <Bot className="w-4 h-4 text-white" />
        </div>
      </div>
      {/* Bouncing dots */}
      <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1.5">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="w-2 h-2 rounded-full bg-fini-green/60"
            animate={{ y: [0, -6, 0] }}
            transition={{
              duration: 0.6,
              repeat: Infinity,
              delay: i * 0.15,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>
    </div>
  );
}

// ── Message Bubble ─────────────────────────────────────────────────────────

function MessageBubble({
  message,
  isFirst,
}: {
  message: InlineMessage;
  isFirst: boolean;
}) {
  const isUser = message.role === 'user';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 24, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        type: 'spring',
        stiffness: 350,
        damping: 28,
      }}
      className={`flex gap-3 px-4 py-2 ${
        isUser ? 'flex-row-reverse' : 'flex-row'
      }`}
    >
      {/* Avatar */}
      {!isUser && (
        <div className="relative shrink-0 mt-0.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center ring-2 ring-fini-green/20">
            <Bot className="w-4 h-4 text-white" />
          </div>
          {/* Gradient ring glow */}
          <div className="absolute -inset-0.5 rounded-full bg-gradient-to-br from-fini-green/20 to-fini-teal/20 blur-sm -z-10" />
        </div>
      )}

      {/* Bubble */}
      <div
        className={`
          max-w-[80%] sm:max-w-[70%] rounded-2xl px-4 py-2.5
          ${
            isUser
              ? 'bg-fini-green text-white rounded-br-md'
              : 'bg-muted text-foreground rounded-bl-md'
          }
        `}
      >
        {isUser ? (
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {message.content}
          </p>
        ) : (
          <div className="text-sm space-y-0.5">{renderMarkdown(message.content)}</div>
        )}
      </div>

      {/* User Avatar */}
      {isUser && (
        <div className="shrink-0 mt-0.5">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="w-4 h-4 text-primary" />
          </div>
        </div>
      )}
    </motion.div>
  );
}

// ── Main Chat Component ────────────────────────────────────────────────────

export default function Chat() {
  const user = useFiniStore((s) => s.user);
  const bankAccount = useFiniStore((s) => s.bankAccount);
  const transactions = useFiniStore((s) => s.transactions);
  const chatMessages = useFiniStore((s) => s.chatMessages);
  const addChatMessage = useFiniStore((s) => s.addChatMessage);
  const setChatMessages = useFiniStore((s) => s.setChatMessages);
  const previousView = useFiniStore((s) => s.previousView);
  const navigate = useFiniStore((s) => s.navigate);

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // ── Initialize greeting ─────────────────────────────────────────────────

  useEffect(() => {
    if (chatMessages.length === 0) {
      setChatMessages([
        {
          id: generateId(),
          ...GREETING_MESSAGE,
          createdAt: new Date().toISOString(),
        },
      ]);
    }
  }, [chatMessages.length, setChatMessages]);

  // ── Auto-scroll to bottom ───────────────────────────────────────────────

  useEffect(() => {
    if (scrollRef.current) {
      const viewport = scrollRef.current.querySelector(
        '[data-radix-scroll-area-viewport]',
      );
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  }, [chatMessages, isTyping]);

  // ── Focus input on mount ────────────────────────────────────────────────

  useEffect(() => {
    // Small delay to allow animation to settle
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  // ── Build context for AI ────────────────────────────────────────────────

  const buildContext = useCallback(() => {
    if (!user) return {};

    const recentTx = transactions.slice(0, 5).map((tx) => ({
      tipo: tx.type,
      categoría: tx.category,
      descripción: tx.description,
      monto: tx.amount,
      fecha: tx.createdAt,
    }));

    return {
      userId: user.id,
      userName: user.name,
      userLevel: user.level,
      userLevelName: user.levelName,
      userPoints: user.points,
      userStreak: user.streak,
      accountBalance: bankAccount?.balance ?? 0,
      monthlyBudget: bankAccount?.monthlyBudget ?? 0,
      recentTransactions: recentTx,
    };
  }, [user, bankAccount, transactions]);

  // ── Send message ────────────────────────────────────────────────────────

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isTyping || !user) return;

    const userMessage: InlineMessage = {
      id: generateId(),
      role: 'user',
      content: trimmed,
      createdAt: new Date().toISOString(),
    };

    addChatMessage(userMessage);
    setInput('');
    setIsTyping(true);

    try {
      // Build history (last 10 messages)
      const history = [...chatMessages, userMessage]
        .slice(-10)
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          message: trimmed,
          history,
          context: buildContext(),
        }),
      });

      if (!res.ok) {
        throw new Error('Error al conectar con FINI AI');
      }

      const data = await res.json();

      const assistantMessage: InlineMessage = {
        id: generateId(),
        role: 'assistant',
        content:
          data.response ??
          data.message ??
          'Lo siento, no pude generar una respuesta. Intenta de nuevo.',
        createdAt: new Date().toISOString(),
      };

      addChatMessage(assistantMessage);
    } catch {
      addChatMessage({
        id: generateId(),
        role: 'assistant',
        content:
          '¡Ups! Hubo un problema de conexión. Revisa tu internet e intenta de nuevo. 🔄',
        createdAt: new Date().toISOString(),
      });
    } finally {
      setIsTyping(false);
      inputRef.current?.focus();
    }
  }, [input, isTyping, user, chatMessages, addChatMessage, buildContext]);

  // ── Keyboard handler ────────────────────────────────────────────────────

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend],
  );

  // ── Close chat ──────────────────────────────────────────────────────────

  const handleClose = useCallback(() => {
    navigate(previousView ?? 'dashboard');
  }, [navigate, previousView]);

  // ── Guard ───────────────────────────────────────────────────────────────

  if (!user) return null;

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 60 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed inset-0 z-[60] flex flex-col bg-background"
    >
      {/* ─── Header ─────────────────────────────────────────────────────── */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-border/60 bg-background/80 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3">
          {/* FINI AI avatar */}
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center shadow-md">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -inset-1 rounded-full bg-gradient-to-br from-fini-green/30 to-fini-teal/30 blur-md -z-10 animate-pulse" />
            {/* Online indicator */}
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 rounded-full border-2 border-background" />
          </div>
          <div>
            <h1 className="font-bold text-base flex items-center gap-1.5">
              FINI AI
              <Sparkles className="w-4 h-4 text-fini-gold" />
            </h1>
            <p className="text-[11px] text-muted-foreground">
              Tu asesor financiero personal
            </p>
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={handleClose}
          className="h-9 w-9 rounded-full hover:bg-muted"
          aria-label="Cerrar chat"
        >
          <X className="w-5 h-5" />
        </Button>
      </header>

      {/* ─── Messages Area ──────────────────────────────────────────────── */}
      <ScrollArea ref={scrollRef} className="flex-1 py-2">
        <AnimatePresence initial={false}>
          {chatMessages.map((msg, idx) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              isFirst={idx === 0}
            />
          ))}
        </AnimatePresence>

        {/* Typing indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <TypingIndicator />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom spacer for input */}
        <div className="h-4" />
      </ScrollArea>

      {/* ─── Quick Suggestions ──────────────────────────────────────────── */}
      {chatMessages.length <= 1 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, type: 'spring', stiffness: 300, damping: 28 }}
          className="px-4 pb-3 flex gap-2 overflow-x-auto fini-scroll"
        >
          {[
            '¿Cómo ahorro mejor?',
            '¿Qué es el CAE?',
            '¿Cómo hago un presupuesto?',
            '¿Qué es la inflación?',
          ].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => {
                setInput(suggestion);
                setTimeout(() => inputRef.current?.focus(), 50);
              }}
              className="
                shrink-0 px-3 py-2 rounded-full text-xs font-medium
                bg-muted/80 text-foreground border border-border/60
                hover:bg-fini-green/10 hover:border-fini-green/30 hover:text-fini-green
                transition-colors duration-200 whitespace-nowrap
              "
            >
              {suggestion}
            </button>
          ))}
        </motion.div>
      )}

      {/* ─── Input Area ────────────────────────────────────────────────── */}
      <div className="shrink-0 border-t border-border/60 bg-background/80 backdrop-blur-md px-4 py-3 pb-4">
        <div className="flex items-center gap-2 max-w-3xl mx-auto">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Escribe tu pregunta..."
            disabled={isTyping}
            className="
              flex-1 h-12 rounded-2xl border-border/60
              bg-muted/40 focus:bg-background
              text-sm pr-4
              placeholder:text-muted-foreground/60
            "
          />
          <Button
            size="icon"
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="
              h-12 w-12 rounded-2xl shrink-0
              bg-fini-green hover:bg-fini-green/90 text-white border-0
              disabled:opacity-40 disabled:cursor-not-allowed
              shadow-md hover:shadow-lg transition-all
              hover:scale-[1.02] active:scale-[0.98]
            "
            aria-label="Enviar mensaje"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
        <p className="text-[10px] text-center text-muted-foreground/60 mt-2">
          FINI AI puede cometer errores. Verifica la información importante.
        </p>
      </div>

      {/* iOS safe area */}
      <div className="h-[env(safe-area-inset-bottom)]" />
    </motion.div>
  );
}
