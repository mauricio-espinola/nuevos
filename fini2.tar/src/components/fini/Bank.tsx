'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  ArrowLeft,
  CreditCard,
  Eye,
  EyeOff,
  Send,
  Download,
  Sparkles,
  CheckCircle2,
  Loader2,
  Shield,
  Building2,
  Info,
  TrendingDown,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import { useFiniStore } from '@/store/fini';
import { COMMERCES, CATEGORY_COLORS, CATEGORY_ICONS } from '@/data/fini-data';
import type { Transaction, BankAccount } from '@/types/fini';

// ── Helpers ──────────────────────────────────────────────────────────────────

const moneyFormatter = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});

function formatMoney(amount: number): string {
  return moneyFormatter.format(amount);
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('es-CL', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

function maskCardNumber(cardNumber: string): string {
  const groups = cardNumber.match(/.{1,4}/g);
  if (!groups) return cardNumber;
  return groups.map((g, i) => (i < 2 ? g : '••••')).join('  ');
}

// ── Apply View ───────────────────────────────────────────────────────────────

function BankApplyView() {
  const user = useFiniStore((s) => s.user);
  const navigate = useFiniStore((s) => s.navigate);
  const setBankAccount = useFiniStore((s) => s.setBankAccount);
  const addTransaction = useFiniStore((s) => s.addTransaction);
  const showToast = useFiniStore((s) => s.showToast);

  const [step, setStep] = useState(1);
  const [evaluating, setEvaluating] = useState(false);
  const [evalDone, setEvalDone] = useState(false);

  // Form fields (pre-filled)
  const [name, setName] = useState(user?.name ?? '');
  const [rut, setRut] = useState(user?.rut ?? '');

  useEffect(() => {
    if (user) {
      setName(user.name);
      setRut(user.rut);
    }
  }, [user]);

  const handleStartEval = () => {
    setStep(2);
    setEvaluating(true);
    setEvalDone(false);
  };

  useEffect(() => {
    if (step === 2 && evaluating) {
      const timer = setTimeout(() => {
        setEvaluating(false);
        setEvalDone(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [step, evaluating]);

  const handleCreateAccount = useCallback(() => {
    const now = new Date().toISOString();
    const cardNum = '4051 8852 3374 ' + String(Math.floor(1000 + Math.random() * 9000));
    const expiry = `${String(Math.floor(1 + Math.random() * 12)).padStart(2, '0')}/${String(new Date().getFullYear() + 5).slice(-2)}`;
    const cvv = String(Math.floor(100 + Math.random() * 900));

    const account: BankAccount = {
      id: `bank-${Date.now()}`,
      accountNumber: String(Math.floor(10000000 + Math.random() * 90000000)),
      accountType: 'Cuenta Vista',
      balance: 0,
      monthlyBudget: 50000,
      cardNumber: cardNum,
      cardExpiry: expiry,
      cardCvv: cvv,
      isActive: true,
    };

    setBankAccount(account);
    setStep(3);
  }, [setBankAccount]);

  const handleGoToBank = () => {
    // Add initial welcome transaction (first allowance)
    const account = useFiniStore.getState().bankAccount;
    if (account) {
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        type: 'income',
        category: 'otro',
        description: 'Bienvenida FINI',
        amount: 50000,
        commerce: 'Banco FINI',
        balanceAfter: 50000,
        createdAt: new Date().toISOString(),
      };
      addTransaction(tx);
    }
    navigate('bank');
  };

  // ── Step indicators ──────────────────────────────────────────────────────
  const steps = [
    { num: 1, label: 'Solicitud' },
    { num: 2, label: 'Evaluación' },
    { num: 3, label: 'Cuenta' },
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 pb-24 space-y-6">
      {/* Back button */}
      <button
        onClick={() => navigate('dashboard')}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Volver al inicio
      </button>

      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
          <Building2 className="w-8 h-8 text-primary" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold">Banco FINI</h1>
        <p className="text-muted-foreground">
          Abre tu cuenta vista y empieza a manejar tu plata
        </p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center justify-center gap-2">
        {steps.map((s, i) => (
          <div key={s.num} className="flex items-center gap-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-colors ${
                step >= s.num
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              {step > s.num ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                s.num
              )}
            </div>
            <span
              className={`text-xs font-medium hidden sm:inline ${
                step >= s.num ? 'text-foreground' : 'text-muted-foreground'
              }`}
            >
              {s.label}
            </span>
            {i < steps.length - 1 && (
              <div
                className={`w-8 sm:w-12 h-0.5 rounded-full transition-colors ${
                  step > s.num ? 'bg-primary' : 'bg-muted'
                }`}
              />
            )}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* ── Step 1: Solicitud ────────────────────────────────────────────── */}
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <Card className="card-glow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-fini-gold" />
                  Paso 1 — Tu Solicitud
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-primary/5 border border-primary/10">
                  <Info className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    Como menor de edad, vamos a evaluar tu solicitud bajo
                    condiciones especiales.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="apply-name">Nombre completo</Label>
                    <Input
                      id="apply-name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="apply-rut">RUT</Label>
                    <Input
                      id="apply-rut"
                      value={rut}
                      onChange={(e) => setRut(e.target.value)}
                      placeholder="12.345.678-9"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleStartEval}
                  className="w-full"
                  size="lg"
                  disabled={!name.trim() || !rut.trim()}
                >
                  Enviar solicitud
                  <Send className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* ── Step 2: Evaluación ──────────────────────────────────────────── */}
        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <Card className="card-glow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-fini-teal" />
                  Paso 2 — Evaluación
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {evaluating && !evalDone ? (
                  /* Loading animation */
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center py-12 gap-4"
                  >
                    <div className="relative">
                      <div className="w-20 h-20 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Building2 className="w-8 h-8 text-primary" />
                      </div>
                    </div>
                    <div className="text-center space-y-1">
                      <p className="font-semibold">Don Banco evaluando tu solicitud...</p>
                      <p className="text-sm text-muted-foreground">
                        Revisando tu perfil como menor de edad
                      </p>
                    </div>
                  </motion.div>
                ) : (
                  /* Evaluation result */
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, ease: 'easeOut' }}
                    className="space-y-4"
                  >
                    {/* Success badge */}
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">
                        ¡Solicitud aprobada! Calificas para una Cuenta Vista.
                      </p>
                    </div>

                    <Separator />

                    {/* Comparison table */}
                    <div className="space-y-2">
                      <p className="text-sm font-semibold flex items-center gap-1.5">
                        <CreditCard className="w-4 h-4" />
                        ¿Qué obtienes vs. una cuenta de adulto?
                      </p>

                      <div className="rounded-xl border overflow-hidden">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-muted/60">
                              <th className="text-left py-2.5 px-3 font-semibold">
                                Característica
                              </th>
                              <th className="text-left py-2.5 px-3 font-semibold text-primary">
                                Cuenta Vista (TUYA)
                              </th>
                              <th className="text-left py-2.5 px-3 font-semibold text-muted-foreground">
                                Cuenta Corriente (Adultos)
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-border/60">
                            <tr>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Tipo de tarjeta
                              </td>
                              <td className="py-2.5 px-3 font-medium">
                                Solo débito
                              </td>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Débito + crédito
                              </td>
                            </tr>
                            <tr>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Línea de crédito
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-red-500 text-xs font-medium">
                                  ❌ No disponible
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-emerald-600 text-xs font-medium">
                                  ✅ Disponible
                                </span>
                              </td>
                            </tr>
                            <tr>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Cheques
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-red-500 text-xs font-medium">
                                  ❌ No
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-emerald-600 text-xs font-medium">
                                  ✅ Sí
                                </span>
                              </td>
                            </tr>
                            <tr>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Requisitos
                              </td>
                              <td className="py-2.5 px-3 font-medium text-primary">
                                Ser mayor de 13 años
                              </td>
                              <td className="py-2.5 px-3 text-muted-foreground">
                                Ser mayor de 18 + ingresos
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <Separator />

                    {/* Educational explanation */}
                    <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800">
                      <Info className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                      <div className="text-sm text-amber-800 dark:text-amber-300 space-y-1.5">
                        <p className="font-semibold">¿Por qué no crédito?</p>
                        <p className="text-amber-700 dark:text-amber-400 leading-relaxed">
                          En Chile, los menores de edad no pueden contratar
                          productos de crédito porque legalmente no tienen
                          capacidad para comprometerse financieramente. Tu
                          cuenta vista te permite gastar solo la plata que
                          tienes, ¡lo cual es una excelente forma de aprender
                          a administrar!
                        </p>
                      </div>
                    </div>

                    <Button
                      onClick={handleCreateAccount}
                      className="w-full"
                      size="lg"
                    >
                      <Sparkles className="w-4 h-4 mr-2" />
                      Crear mi cuenta
                    </Button>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* ── Step 3: Cuenta Creada ──────────────────────────────────────── */}
        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="space-y-4"
          >
            {/* Celebration */}
            <Card className="card-glow overflow-hidden">
              <CardContent className="py-10 flex flex-col items-center text-center gap-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{
                    type: 'spring',
                    stiffness: 200,
                    damping: 12,
                    delay: 0.2,
                  }}
                  className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center"
                >
                  <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="space-y-2"
                >
                  <h2 className="text-2xl font-bold">¡Cuenta Creada!</h2>
                  <p className="text-muted-foreground">
                    Tu Cuenta Vista FINI está lista para usar
                  </p>
                </motion.div>
              </CardContent>
            </Card>

            {/* Card preview */}
            <Card className="card-glow">
              <CardHeader>
                <CardTitle className="text-base font-semibold">
                  Tu tarjeta virtual
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="rounded-2xl p-6 card-gradient text-white space-y-6 shadow-xl relative overflow-hidden">
                  {/* Decorative circles */}
                  <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/5" />
                  <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-white/5" />

                  <div className="relative flex items-center justify-between">
                    <div className="text-lg font-bold tracking-wide">FINI</div>
                    <CreditCard className="w-8 h-8 text-white/80" />
                  </div>

                  <div className="relative">
                    <p className="font-mono text-lg tracking-widest">
                      •••• •••• •••• ••••
                    </p>
                  </div>

                  <div className="relative flex items-end justify-between">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-white/60 mb-1">
                        Titular
                      </p>
                      <p className="text-sm font-semibold uppercase">
                        {name || 'NOMBRE APELLIDO'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] uppercase tracking-wider text-white/60 mb-1">
                        Vence
                      </p>
                      <p className="text-sm font-semibold">
                        {useFiniStore.getState().bankAccount?.cardExpiry ?? '12/30'}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleGoToBank}
              className="w-full"
              size="lg"
            >
              <Wallet className="w-4 h-4 mr-2" />
              Acceder a mi banco
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Bank Portal View ────────────────────────────────────────────────────────

function BankPortalView() {
  const user = useFiniStore((s) => s.user);
  const bankAccount = useFiniStore((s) => s.bankAccount);
  const transactions = useFiniStore((s) => s.transactions);
  const navigate = useFiniStore((s) => s.navigate);
  const addTransaction = useFiniStore((s) => s.addTransaction);
  const showToast = useFiniStore((s) => s.showToast);
  const showDonBanco = useFiniStore((s) => s.showDonBanco);

  const [showCvv, setShowCvv] = useState(false);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);
  const [selectedCommerce, setSelectedCommerce] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');

  if (!bankAccount || !user) return null;

  const holderName = user.name.toUpperCase();

  // ── Handle expense ──────────────────────────────────────────────────────
  const handleExpense = () => {
    const amount = parseInt(expenseAmount, 10);
    const commerce = COMMERCES.find((c) => c.name === selectedCommerce);

    if (!amount || amount <= 0 || !commerce) return;
    if (amount > bankAccount.balance) {
      showToast('¡No tienes suficiente saldo para este gasto!');
      showDonBanco(
        '¡Ojo! Estás intentando gastar más de lo que tienes. Revisa tu saldo y planifica mejor tus compras. 💡',
      );
      return;
    }

    const tx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'expense',
      category: commerce.category,
      description: `Compra en ${commerce.name}`,
      amount,
      commerce: commerce.name,
      balanceAfter: bankAccount.balance - amount,
      createdAt: new Date().toISOString(),
    };

    addTransaction(tx);
    setExpenseDialogOpen(false);
    setSelectedCommerce('');
    setExpenseAmount('');
    showToast(`Gasto de ${formatMoney(amount)} realizado en ${commerce.name}`);

    // Don Banco tip after expense
    const tips = [
      '¡Gasto registrado! Recuerda anotar todos tus gastos para llevar un buen control. 📝',
      'Cada gasto cuenta. ¿Este era realmente necesario o fue un impulso? 🤔',
      `Gastaste ${formatMoney(amount)} en ${commerce.category}. ¿Está dentro de tu presupuesto mensual?`,
    ];
    showDonBanco(tips[Math.floor(Math.random() * tips.length)]);
  };

  // ── Handle income (asignación) ─────────────────────────────────────────
  const handleAllowance = () => {
    const amount = 50000;
    const tx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'income',
      category: 'otro',
      description: 'Asignación semanal',
      amount,
      commerce: 'Papá/Mamá',
      balanceAfter: bankAccount.balance + amount,
      createdAt: new Date().toISOString(),
    };

    addTransaction(tx);
    showToast(`¡Recibiste ${formatMoney(amount)} de asignación!`);
    showDonBanco(
      '¡Llegó tu asignación! Recuerda: 50% necesidades, 30% gustos, 20% ahorro. 💪',
    );
  };

  // ── Don Banco tip ──────────────────────────────────────────────────────
  const bankTips = [
    '💡 Una Cuenta Vista solo te permite gastar la plata que tienes. ¡No te puedes endeudar!',
    '💡 Anota todos tus gastos, por chicos que sean. Así sabes exactamente a dónde va tu plata.',
    '💡 Antes de comprar algo, pregúntate: ¿lo necesito o lo quiero? Espera 24 horas antes de compras impulsivas.',
    '💡 Guarda al menos el 20% de tu asignación. Tu yo del futuro te lo agradecerá.',
    '💡 Comparar precios antes de comprar puede ahorrarte mucha plata. ¡Usa las ofertas a tu favor!',
  ];

  const randomTip = bankTips[Math.floor(Math.random() * bankTips.length)];

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 pb-24 space-y-6">
      {/* Back button */}
      <button
        onClick={() => navigate('dashboard')}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Volver al inicio
      </button>

      {/* ── Virtual Card ─────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="rounded-2xl p-6 card-gradient text-white shadow-2xl relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/5" />
          <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-white/5" />
          <div className="absolute top-1/2 right-1/4 w-20 h-20 rounded-full bg-white/[0.03]" />

          {/* Bank name + CVV toggle */}
          <div className="relative flex items-center justify-between">
            <div className="text-lg font-bold tracking-wide">FINI</div>
            <button
              onClick={() => setShowCvv(!showCvv)}
              className="flex items-center gap-1.5 text-xs text-white/70 hover:text-white transition-colors"
              aria-label={showCvv ? 'Ocultar CVV' : 'Mostrar CVV'}
            >
              {showCvv ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
              CVV
            </button>
          </div>

          {/* Chip + Contactless */}
          <div className="relative flex items-center gap-3 my-5">
            <div className="w-12 h-9 rounded-md bg-gradient-to-br from-amber-300 to-amber-500 shadow-inner" />
            <div className="flex flex-col gap-0.5">
              <div className="w-6 h-6 rounded-full border-2 border-white/30" />
              <div className="w-8 h-8 rounded-full border-2 border-white/20 -mt-4 ml-1" />
            </div>
          </div>

          {/* Card number */}
          <div className="relative mb-5">
            <p className="font-mono text-lg tracking-widest">
              {maskCardNumber(bankAccount.cardNumber)}
            </p>
          </div>

          {/* Holder + Expiry + CVV */}
          <div className="relative flex items-end justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-white/60 mb-1">
                Titular
              </p>
              <p className="text-sm font-semibold truncate">{holderName}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-white/60 mb-1">
                Vence
              </p>
              <p className="text-sm font-semibold">
                {bankAccount.cardExpiry}
              </p>
            </div>
            <div className="text-right ml-4">
              <p className="text-[10px] uppercase tracking-wider text-white/60 mb-1">
                CVV
              </p>
              <p className="text-sm font-semibold">
                {showCvv ? bankAccount.cardCvv : '•••'}
              </p>
            </div>
          </div>

          {/* Account type badge */}
          <div className="relative mt-4">
            <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/30 text-[10px] px-2 py-0.5">
              CUENTA VISTA
            </Badge>
          </div>
        </div>
      </motion.div>

      {/* ── Balance Display ───────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        <Card className="card-glow">
          <CardContent className="py-6 text-center">
            <p className="text-sm text-muted-foreground font-medium mb-1">
              Saldo disponible
            </p>
            <p className="text-3xl md:text-4xl font-bold">
              {formatMoney(bankAccount.balance)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Presupuesto mensual: {formatMoney(bankAccount.monthlyBudget)}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* ── Quick Actions ─────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="grid grid-cols-2 gap-3"
      >
        {/* Hacer un gasto */}
        <Dialog open={expenseDialogOpen} onOpenChange={setExpenseDialogOpen}>
          <DialogTrigger asChild>
            <Card className="card-glow cursor-pointer group hover:border-red-300 dark:hover:border-red-800 transition-colors">
              <CardContent className="flex flex-col items-center gap-3 py-5">
                <div className="w-12 h-12 rounded-xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Send className="w-6 h-6 text-red-500" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">Hacer un gasto</p>
                  <p className="text-xs text-muted-foreground">Simular compra</p>
                </div>
              </CardContent>
            </Card>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Send className="w-5 h-5 text-red-500" />
                Hacer un gasto
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label>¿Dónde vas a comprar?</Label>
                <Select value={selectedCommerce} onValueChange={setSelectedCommerce}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un comercio" />
                  </SelectTrigger>
                  <SelectContent className="max-h-64 overflow-y-auto">
                    {COMMERCES.map((c) => (
                      <SelectItem key={c.name} value={c.name}>
                        <span className="flex items-center gap-2">
                          <span>{c.icon}</span>
                          <span>{c.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedCommerce && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-muted/50 text-sm">
                    <span>
                      {COMMERCES.find((c) => c.name === selectedCommerce)?.icon}
                    </span>
                    <span className="text-muted-foreground">
                      Categoría:{' '}
                      <span className="font-medium capitalize text-foreground">
                        {COMMERCES.find((c) => c.name === selectedCommerce)?.category}
                      </span>
                    </span>
                  </div>
                </motion.div>
              )}

              <div className="space-y-1.5">
                <Label>Monto</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                    $
                  </span>
                  <Input
                    type="number"
                    min="1"
                    placeholder="0"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    className="pl-7"
                  />
                </div>
              </div>

              {expenseAmount && parseInt(expenseAmount, 10) > bankAccount.balance && (
                <p className="text-sm text-red-500 flex items-center gap-1">
                  <TrendingDown className="w-4 h-4" />
                  Saldo insuficiente. Tu saldo es {formatMoney(bankAccount.balance)}.
                </p>
              )}

              <Button
                onClick={handleExpense}
                className="w-full"
                disabled={
                  !selectedCommerce ||
                  !expenseAmount ||
                  parseInt(expenseAmount, 10) <= 0
                }
              >
                <Send className="w-4 h-4 mr-2" />
                Pagar{' '}
                {expenseAmount && parseInt(expenseAmount, 10) > 0
                  ? formatMoney(parseInt(expenseAmount, 10))
                  : ''}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Recibir asignación */}
        <Card
          className="card-glow cursor-pointer group hover:border-emerald-300 dark:hover:border-emerald-800 transition-colors"
          onClick={handleAllowance}
        >
          <CardContent className="flex flex-col items-center gap-3 py-5">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Download className="w-6 h-6 text-emerald-500" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-sm">Recibir asignación</p>
              <p className="text-xs text-emerald-600 font-medium">+${(50000).toLocaleString('es-CL')}</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* ── Transaction History ──────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
      >
        <Card className="card-glow">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Wallet className="w-5 h-5" />
              Historial de transacciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Wallet className="w-10 h-10 mx-auto mb-2 opacity-40" />
                <p className="text-sm">Aún no tienes transacciones</p>
                <p className="text-xs mt-1">
                  ¡Recibe tu primera asignación para empezar!
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border/60 max-h-96 overflow-y-auto fini-scroll">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center gap-3 py-3 first:pt-0 last:pb-0"
                  >
                    {/* Category icon */}
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
                      style={{
                        backgroundColor: `${CATEGORY_COLORS[tx.category] ?? '#94a3b8'}15`,
                      }}
                    >
                      {CATEGORY_ICONS[tx.category] ?? '📌'}
                    </div>
                    {/* Description & date */}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {tx.description}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(tx.createdAt)}
                      </p>
                    </div>
                    {/* Amount */}
                    <div className="text-right shrink-0">
                      <p
                        className={`text-sm font-semibold flex items-center gap-0.5 justify-end ${
                          tx.type === 'expense'
                            ? 'text-red-500'
                            : 'text-emerald-600'
                        }`}
                      >
                        {tx.type === 'expense' ? (
                          <TrendingDown className="w-3.5 h-3.5" />
                        ) : (
                          <TrendingUp className="w-3.5 h-3.5" />
                        )}
                        {tx.type === 'expense' ? '-' : '+'}
                        {formatMoney(tx.amount)}
                      </p>
                      {tx.commerce && (
                        <p className="text-[11px] text-muted-foreground truncate max-w-[120px]">
                          {tx.commerce}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* ── Don Banco Tip ────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <Card className="card-glow border-primary/20 bg-primary/[0.02]">
          <CardContent className="py-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 text-lg">
                🏦
              </div>
              <div>
                <p className="text-sm font-semibold mb-1">Tip de Don Banco</p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {randomTip}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

// ── Main Export ──────────────────────────────────────────────────────────────

export default function Bank() {
  const currentView = useFiniStore((s) => s.currentView);

  if (currentView === 'bank-apply') {
    return <BankApplyView />;
  }

  return <BankPortalView />;
}
