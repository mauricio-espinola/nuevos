'use client';

import { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  BookOpen,
  Gamepad2,
  Gift,
  ArrowRight,
  Star,
  Zap,
} from 'lucide-react';
import { useFiniStore } from '@/store/fini';
import { CATEGORY_COLORS, CATEGORY_ICONS } from '@/data/fini-data';
import { LEVEL_THRESHOLDS } from '@/types/fini';

// ── Helpers ──────────────────────────────────────────────────────────────────

const moneyFormatter = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});

function formatMoney(amount: number): string {
  return moneyFormatter.format(amount);
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('es-CL', { day: 'numeric', month: 'short' });
}

// ── Component ────────────────────────────────────────────────────────────────

export default function Dashboard() {
  const user = useFiniStore((s) => s.user);
  const bankAccount = useFiniStore((s) => s.bankAccount);
  const transactions = useFiniStore((s) => s.transactions);
  const topicProgress = useFiniStore((s) => s.topicProgress);
  const navigate = useFiniStore((s) => s.navigate);

  // ── Derived data ───────────────────────────────────────────────────────────

  const completedTopics = useMemo(
    () => topicProgress.filter((tp) => tp.status === 'completed').length,
    [topicProgress],
  );

  const levelProgress = useMemo(() => {
    if (!user) return 0;
    const currentThreshold = LEVEL_THRESHOLDS[user.level - 1] ?? 0;
    const nextThreshold = LEVEL_THRESHOLDS[user.level] ?? LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1];
    if (nextThreshold <= currentThreshold) return 100;
    const range = nextThreshold - currentThreshold;
    const progress = user.points - currentThreshold;
    return Math.min(100, Math.round((progress / range) * 100));
  }, [user]);

  // Chart data: last 7 transactions as cumulative balance points
  const chartData = useMemo(() => {
    if (transactions.length === 0) return [];
    const recent = transactions.slice(0, 7).reverse();
    return recent.map((tx) => ({
      label: formatDate(tx.createdAt),
      balance: tx.balanceAfter,
    }));
  }, [transactions]);

  // Spending by category (expenses only)
  const spendingByCategory = useMemo(() => {
    const categoryTotals: Record<string, number> = {};
    for (const tx of transactions) {
      if (tx.type === 'expense') {
        categoryTotals[tx.category] = (categoryTotals[tx.category] || 0) + tx.amount;
      }
    }
    return Object.entries(categoryTotals)
      .map(([category, total]) => ({ category, total }))
      .sort((a, b) => b.total - a.total);
  }, [transactions]);

  // Recent transactions (last 5)
  const recentTransactions = useMemo(
    () => transactions.slice(0, 5),
    [transactions],
  );

  // ── No account CTA ─────────────────────────────────────────────────────────

  if (!bankAccount) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6 pb-24 space-y-6">
        {/* Header */}
        {user && (
          <div className="space-y-1">
            <h1 className="text-2xl md:text-3xl font-bold">
              ¡Hola, {user.name}! 👋
            </h1>
            <p className="text-muted-foreground">
              Nivel {user.level}: {user.levelName}
            </p>
          </div>
        )}

        {/* CTA Card */}
        <Card className="card-glow overflow-hidden border-2 border-dashed border-primary/40">
          <CardContent className="py-12 flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Wallet className="w-8 h-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold">¡Abre tu cuenta bancaria!</h2>
              <p className="text-muted-foreground max-w-sm">
                Empieza tu viaje financiero abriendo tu cuenta virtual FINI.
                Es gratis, segura y necesaria para desbloquear todas las
                funcionalidades.
              </p>
            </div>
            <button
              onClick={() => navigate('bank-apply')}
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-semibold hover:bg-primary/90 transition-all shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
            >
              Abrir mi cuenta
              <ArrowRight className="w-4 h-4" />
            </button>
          </CardContent>
        </Card>

        {/* Quick actions without bank */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card
            className="card-glow cursor-pointer group"
            onClick={() => navigate('academy')}
          >
            <CardContent className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-fini-teal/10 flex items-center justify-center shrink-0">
                <BookOpen className="w-6 h-6 text-fini-teal" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold">Academia FINI</p>
                <p className="text-sm text-muted-foreground truncate">
                  Aprende sobre finanzas personales
                </p>
              </div>
              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all" />
            </CardContent>
          </Card>

          <Card
            className="card-glow cursor-pointer group"
            onClick={() => navigate('scenarios')}
          >
            <CardContent className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-fini-coral/10 flex items-center justify-center shrink-0">
                <Gamepad2 className="w-6 h-6 text-fini-coral" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold">Escenarios</p>
                <p className="text-sm text-muted-foreground truncate">
                  Pon a prueba tus habilidades
                </p>
              </div>
              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // ── Full dashboard ─────────────────────────────────────────────────────────

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 pb-24 space-y-6">
      {/* ─── 1. Header greeting ───────────────────────────────────────────── */}
      {user && (
        <div className="space-y-2">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl md:text-3xl font-bold">
              ¡Hola, {user.name}! 👋
            </h1>
            <Badge className="bg-fini-gold/15 text-fini-gold border-fini-gold/30 font-semibold px-3 py-1">
              Nivel {user.level}: {user.levelName}
            </Badge>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Zap className="w-4 h-4 text-fini-gold" />
              <span>
                {user.streak} {user.streak === 1 ? 'día de racha' : 'días de racha'}
              </span>
            </div>
            <div className="flex-1 min-w-[140px] max-w-[240px]">
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                <span>Progreso al Nivel {user.level + 1}</span>
                <span className="font-medium text-foreground">{levelProgress}%</span>
              </div>
              <Progress value={levelProgress} className="h-2" />
            </div>
          </div>
        </div>
      )}

      {/* ─── 2. Quick stats (2x2 grid) ───────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-3 md:gap-4">
        {/* Balance */}
        <Card className="card-glow py-4">
          <CardContent className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Saldo actual
              </p>
              <p className="text-lg md:text-xl font-bold truncate">
                {formatMoney(bankAccount.balance)}
              </p>
              {transactions.length > 0 &&
                transactions[0]?.type === 'income' && (
                  <p className="text-xs text-emerald-600 flex items-center gap-0.5 mt-0.5">
                    <TrendingUp className="w-3 h-3" />
                    +{formatMoney(transactions[0].amount)}
                  </p>
                )}
            </div>
          </CardContent>
        </Card>

        {/* Points */}
        <Card className="card-glow py-4">
          <CardContent className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-fini-gold/10 flex items-center justify-center shrink-0">
              <Star className="w-5 h-5 text-fini-gold" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Puntos FINI
              </p>
              <p className="text-lg md:text-xl font-bold gradient-text-gold">
                {user?.points.toLocaleString('es-CL') ?? 0}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                ¡Sigue aprendiendo!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Streak */}
        <Card className="card-glow py-4">
          <CardContent className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-fini-coral/10 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-fini-coral" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Rachas
              </p>
              <p className="text-lg md:text-xl font-bold">
                {user?.streak ?? 0}{' '}
                <span className="text-sm font-normal text-muted-foreground">
                  días
                </span>
              </p>
              {(user?.streak ?? 0) >= 7 && (
                <p className="text-xs text-fini-gold font-medium mt-0.5">
                  🔥 ¡Estás en racha!
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Completed Topics */}
        <Card className="card-glow py-4">
          <CardContent className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-fini-teal/10 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5 text-fini-teal" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Temas completados
              </p>
              <p className="text-lg md:text-xl font-bold">
                {completedTopics}{' '}
                <span className="text-sm font-normal text-muted-foreground">
                  / {topicProgress.length}
                </span>
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {completedTopics === 0
                  ? '¡Empieza tu primer tema!'
                  : completedTopics === topicProgress.length
                    ? '🏆 ¡Todos completados!'
                    : `Faltan ${topicProgress.length - completedTopics}`}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ─── 3. Balance evolution chart ───────────────────────────────────── */}
      {chartData.length > 1 && (
        <Card className="card-glow">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold">
                Evolución del saldo
              </CardTitle>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <TrendingUp className="w-3.5 h-3.5 text-primary" />
                Últimas transacciones
              </div>
            </div>
          </CardHeader>
          <CardContent className="h-[220px] md:h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-chart-1)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="var(--color-chart-1)" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(val: number) =>
                    `$${(val / 1000).toFixed(0)}k`
                  }
                  width={50}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid var(--color-border)',
                    boxShadow: '0 8px 25px rgba(0,0,0,0.1)',
                    fontSize: '13px',
                  }}
                  formatter={(value: number) => [formatMoney(value), 'Saldo']}
                  labelStyle={{ fontWeight: 600, marginBottom: 4 }}
                />
                <Area
                  type="monotone"
                  dataKey="balance"
                  stroke="var(--color-chart-1)"
                  strokeWidth={2.5}
                  fill="url(#balanceGradient)"
                  dot={{ r: 4, fill: 'var(--color-chart-1)', strokeWidth: 0 }}
                  activeDot={{ r: 6, strokeWidth: 2, stroke: 'var(--color-background)' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* ─── 4 & 5. Spending + Quick actions (side by side on desktop) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Spending by category */}
        {spendingByCategory.length > 0 && (
          <Card className="card-glow">
            <CardHeader>
              <CardTitle className="text-base font-semibold">
                Gastos por categoría
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Pie chart */}
              <div className="h-[160px] md:h-[180px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={spendingByCategory}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="total"
                      nameKey="category"
                    >
                      {spendingByCategory.map((entry) => (
                        <Cell
                          key={entry.category}
                          fill={CATEGORY_COLORS[entry.category] ?? '#94a3b8'}
                          strokeWidth={0}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => formatMoney(value)}
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid var(--color-border)',
                        fontSize: '12px',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              {/* Category legend */}
              <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                {spendingByCategory.map((item) => (
                  <div
                    key={item.category}
                    className="flex items-center gap-2 text-sm"
                  >
                    <span className="text-base">
                      {CATEGORY_ICONS[item.category] ?? '📌'}
                    </span>
                    <span className="flex-1 truncate text-muted-foreground capitalize">
                      {item.category}
                    </span>
                    <div
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{
                        backgroundColor:
                          CATEGORY_COLORS[item.category] ?? '#94a3b8',
                      }}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick actions */}
        <div className="space-y-4">
          <p className="text-sm font-semibold text-muted-foreground px-1">
            Acciones rápidas
          </p>
          <div className="space-y-3">
            {/* Academia */}
            <Card
              className="card-glow cursor-pointer group overflow-hidden"
              onClick={() => navigate('academy')}
            >
              <CardContent className="flex items-center gap-4 py-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-fini-teal/20 to-fini-teal/5 flex items-center justify-center shrink-0">
                  <BookOpen className="w-7 h-7 text-fini-teal" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">Academia FINI</p>
                  <p className="text-sm text-muted-foreground truncate">
                    Aprende sobre finanzas de forma divertida
                  </p>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-fini-teal group-hover:translate-x-1 transition-all shrink-0" />
              </CardContent>
            </Card>

            {/* Escenarios */}
            <Card
              className="card-glow cursor-pointer group overflow-hidden"
              onClick={() => navigate('scenarios')}
            >
              <CardContent className="flex items-center gap-4 py-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-fini-coral/20 to-fini-coral/5 flex items-center justify-center shrink-0">
                  <Gamepad2 className="w-7 h-7 text-fini-coral" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">Escenarios</p>
                  <p className="text-sm text-muted-foreground truncate">
                    Toma decisiones financieras en situaciones reales
                  </p>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-fini-coral group-hover:translate-x-1 transition-all shrink-0" />
              </CardContent>
            </Card>

            {/* Banco */}
            <Card
              className="card-glow cursor-pointer group overflow-hidden"
              onClick={() => navigate('bank')}
            >
              <CardContent className="flex items-center gap-4 py-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center shrink-0">
                  <Wallet className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">Mi Banco</p>
                  <p className="text-sm text-muted-foreground truncate">
                    Administra tu cuenta y tarjeta virtual
                  </p>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* ─── 6. Recent transactions ───────────────────────────────────────── */}
      <Card className="card-glow">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold">
              Transacciones recientes
            </CardTitle>
            <button
              onClick={() => navigate('bank')}
              className="text-xs text-primary font-medium hover:underline flex items-center gap-1"
            >
              Ver todas
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          {recentTransactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Wallet className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">Aún no tienes transacciones</p>
            </div>
          ) : (
            <div className="divide-y divide-border/60 max-h-96 overflow-y-auto fini-scroll">
              {recentTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center gap-3 py-3 first:pt-0 last:pb-0"
                >
                  {/* Category icon */}
                  <div className="w-10 h-10 rounded-xl bg-muted/60 flex items-center justify-center text-lg shrink-0">
                    {CATEGORY_ICONS[tx.category] ?? '📌'}
                  </div>
                  {/* Description & date */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {tx.description}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(tx.createdAt)}
                    </p>
                  </div>
                  {/* Amount */}
                  <div className="text-right shrink-0">
                    <p
                      className={`text-sm font-semibold ${
                        tx.type === 'expense'
                          ? 'text-red-500'
                          : 'text-emerald-600'
                      }`}
                    >
                      {tx.type === 'expense' ? '-' : '+'}
                      {formatMoney(tx.amount)}
                    </p>
                    {tx.commerce && (
                      <p className="text-[11px] text-muted-foreground truncate max-w-[120px]">
                        {tx.commerce}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
