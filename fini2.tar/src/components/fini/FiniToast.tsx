'use client';

import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { useFiniStore } from '@/store/fini';

export default function FiniToast() {
  const toastMessage = useFiniStore((s) => s.toastMessage);
  const hideToast = useFiniStore((s) => s.hideToast);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      hideToast();
    }, 3000);
    return () => clearTimeout(timer);
  }, [toastMessage, hideToast]);

  if (!toastMessage) return null;

  return (
    <AnimatePresence>
      {toastMessage && (
        <motion.div
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] w-auto max-w-xs"
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -40, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        >
          <div className="flex items-center gap-2.5 rounded-xl border border-green-400 dark:border-green-500 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl px-4 py-3 shadow-lg">
            <CheckCircle className="size-5 shrink-0 text-green-500 dark:text-green-400" />
            <p className="text-sm font-medium text-foreground leading-snug">
              {toastMessage}
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
