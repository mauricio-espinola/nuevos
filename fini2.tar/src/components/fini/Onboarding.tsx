'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { useFiniStore } from '@/store/fini';
import { LEVEL_NAMES } from '@/types/fini';
import {
  ArrowLeft,
  ArrowRight,
  Sparkles,
  PiggyBank,
  TrendingUp,
  Wallet,
  CreditCard,
  Landmark,
  CheckCircle2,
  Shield,
} from 'lucide-react';

const TOTAL_STEPS = 4;

const FINANCIAL_GOALS = [
  { id: 'ahorro', label: 'Ahorro', icon: PiggyBank, emoji: '🐷' },
  { id: 'inversion', label: 'Inversión', icon: TrendingUp, emoji: '📈' },
  { id: 'presupuesto', label: 'Presupuesto', icon: Wallet, emoji: '📋' },
  { id: 'tarjetas', label: 'Tarjetas', icon: CreditCard, emoji: '💳' },
  { id: 'credito', label: 'Crédito', icon: Landmark, emoji: '🏦' },
];

// ─── RUT formatting ────────────────────────────────────────────
function formatRUT(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 9);
  if (digits.length <= 1) return digits;
  const body = digits.slice(0, -1);
  const verifier = digits.slice(-1);
  const formatted = body.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${formatted}-${verifier}`;
}

function isValidRUT(rut: string): boolean {
  const clean = rut.replace(/\D/g, '');
  if (clean.length < 8 || clean.length > 9) return false;
  const body = clean.slice(0, -1);
  const verifier = clean.slice(-1).toUpperCase();
  let sum = 0;
  let multiplier = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += parseInt(body[i]) * multiplier;
    multiplier = multiplier === 7 ? 2 : multiplier + 1;
  }
  const expected = 11 - (sum % 11);
  const expectedChar =
    expected === 11 ? '0' : expected === 10 ? 'K' : expected.toString();
  return verifier === expectedChar;
}

// ─── Validation helpers ────────────────────────────────────────
function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateAge(age: number): boolean {
  return age >= 13 && age <= 18;
}

// ─── Animation variants ────────────────────────────────────────
const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction < 0 ? 300 : -300,
    opacity: 0,
  }),
};

const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 24 } },
};

// ─── Confetti particle data ────────────────────────────────────
const CONFETTI_COLORS = ['#22c55e', '#eab308', '#f97316', '#14b8a6', '#a855f7', '#ec4899'];
const CONFETTI = Array.from({ length: 40 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,
  delay: Math.random() * 0.8,
  duration: 1.2 + Math.random() * 1.5,
  color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
  size: 4 + Math.random() * 6,
  rotation: Math.random() * 360,
}));

// ─── Component ─────────────────────────────────────────────────
export default function Onboarding() {
  const { setUser, showToast } = useFiniStore();

  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [age, setAge] = useState('');
  const [rut, setRut] = useState('');
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);

  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  const progressValue = ((step + 1) / TOTAL_STEPS) * 100;

  const goNext = useCallback(() => setDirection(1), []);
  const goBack = useCallback(() => {
    setDirection(-1);
    setStep((s) => Math.max(0, s - 1));
  }, []);

  // ── Personal Info Validation ─────────────────────────────────
  const validatePersonalInfo = useCallback((): boolean => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) newErrors.name = 'Ingresa tu nombre';
    else if (name.trim().length < 2) newErrors.name = 'El nombre debe tener al menos 2 caracteres';

    if (!email.trim()) newErrors.email = 'Ingresa tu correo';
    else if (!validateEmail(email)) newErrors.email = 'Correo no válido';

    const ageNum = parseInt(age);
    if (!age) newErrors.age = 'Ingresa tu edad';
    else if (isNaN(ageNum)) newErrors.age = 'Ingresa un número válido';
    else if (!validateAge(ageNum)) newErrors.age = 'Debes tener entre 13 y 18 años';

    if (!rut.trim()) newErrors.rut = 'Ingresa tu RUT';
    else if (!isValidRUT(rut)) newErrors.rut = 'RUT no válido';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [name, email, age, rut]);

  // ── Handle personal info next ────────────────────────────────
  const handlePersonalNext = useCallback(() => {
    if (validatePersonalInfo()) {
      goNext();
      setStep(1);
    }
  }, [validatePersonalInfo, goNext]);

  // ── Handle goals next ────────────────────────────────────────
  const handleGoalsNext = useCallback(() => {
    if (selectedGoals.length === 0) {
      setErrors({ goals: 'Selecciona al menos un interés' });
      return;
    }
    setErrors({});
    goNext();
    setStep(2);
  }, [selectedGoals, goNext]);

  // ── Toggle goal selection ────────────────────────────────────
  const toggleGoal = useCallback((goalId: string) => {
    setSelectedGoals((prev) =>
      prev.includes(goalId) ? prev.filter((g) => g !== goalId) : [...prev, goalId]
    );
    setErrors((prev) => ({ ...prev, goals: '' }));
  }, []);

  // ── Submit onboarding ────────────────────────────────────────
  const handleComplete = useCallback(async () => {
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          age: parseInt(age),
          rut: rut.trim(),
          goals: selectedGoals,
        }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'Error al crear tu cuenta');
      }

      const user = await response.json();
      setUser(user);
      showToast('¡Bienvenido/a a FINI! 🎉');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Error inesperado');
      setIsSubmitting(false);
    }
  }, [name, email, age, rut, selectedGoals, setUser, showToast]);

  // ── RUT input handler ────────────────────────────────────────
  const handleRutChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatRUT(e.target.value);
    setRut(formatted);
    setErrors((prev) => ({ ...prev, rut: '' }));
  }, []);

  // ── Age input handler (numeric only) ─────────────────────────
  const handleAgeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 2);
    setAge(val);
    setErrors((prev) => ({ ...prev, age: '' }));
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute -top-32 -right-32 w-64 h-64 rounded-full bg-fini-green/10 blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 6, repeat: Infinity }}
        />
        <motion.div
          className="absolute -bottom-32 -left-32 w-72 h-72 rounded-full bg-fini-gold/10 blur-3xl"
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 7, repeat: Infinity }}
        />
        <motion.div
          className="absolute top-1/3 left-1/4 w-48 h-48 rounded-full bg-fini-coral/8 blur-3xl"
          animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 5, repeat: Infinity, delay: 1 }}
        />
      </div>

      {/* Content container */}
      <div className="w-full max-w-md relative z-10">
        {/* Progress bar */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Paso {step + 1} de {TOTAL_STEPS}
            </span>
            <span className="text-sm font-semibold gradient-text-gold">
              {Math.round(progressValue)}%
            </span>
          </div>
          <Progress value={progressValue} className="h-2.5" />
        </motion.div>

        {/* Step container */}
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={step}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          >
            {/* ─── Step 0: Welcome ─────────────────────────── */}
            {step === 0 && (
              <Card className="border-none shadow-xl bg-gradient-to-br from-white via-fini-green-light/20 to-fini-gold-light/20">
                <CardContent className="flex flex-col items-center justify-center p-8 sm:p-12 text-center">
                  <motion.div
                    variants={staggerContainer}
                    initial="hidden"
                    animate="show"
                    className="flex flex-col items-center gap-6"
                  >
                    {/* Logo icon */}
                    <motion.div variants={staggerItem} className="relative">
                      <motion.div
                        className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center shadow-lg"
                        animate={{ rotate: [0, 3, -3, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        <Shield className="w-12 h-12 sm:w-14 sm:h-14 text-white" />
                      </motion.div>
                      <motion.div
                        className="absolute -top-1 -right-1 w-8 h-8 rounded-full bg-fini-gold flex items-center justify-center shadow-md"
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <Sparkles className="w-4 h-4 text-white" />
                      </motion.div>
                    </motion.div>

                    {/* Title */}
                    <motion.div variants={staggerItem} className="space-y-2">
                      <h1 className="text-5xl sm:text-6xl font-black tracking-tight gradient-text leading-none">
                        FINI
                      </h1>
                      <p className="text-sm font-semibold uppercase tracking-widest text-fini-green/70">
                        Tu finanzas, tu futuro
                      </p>
                    </motion.div>

                    {/* Description */}
                    <motion.div variants={staggerItem} className="space-y-3 max-w-sm">
                      <p className="text-base sm:text-lg text-foreground/80 leading-relaxed">
                        Aprende a manejar tu plata como un pro 💸
                      </p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        Descubre cómo ahorrar, invertir y tomar buenas decisiones con tu dinero.
                        Todo de forma fácil, divertida y pensada para ti.
                      </p>
                    </motion.div>

                    {/* Feature pills */}
                    <motion.div
                      variants={staggerItem}
                      className="flex flex-wrap justify-center gap-2"
                    >
                      {['Ahorro inteligente', 'Simulaciones', 'Misiones', 'Premios'].map(
                        (tag) => (
                          <span
                            key={tag}
                            className="px-3 py-1 rounded-full text-xs font-medium bg-fini-green/10 text-fini-green border border-fini-green/20"
                          >
                            {tag}
                          </span>
                        )
                      )}
                    </motion.div>

                    {/* CTA Button */}
                    <motion.div variants={staggerItem} className="w-full pt-2">
                      <Button
                        size="lg"
                        className="w-full h-13 text-base font-bold rounded-2xl bg-gradient-to-r from-fini-green to-fini-teal hover:opacity-90 shadow-lg shadow-fini-green/25 cursor-pointer"
                        onClick={() => {
                          goNext();
                          setStep(1);
                        }}
                      >
                        ¡Vamos!
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </Button>
                    </motion.div>
                  </motion.div>
                </CardContent>
              </Card>
            )}

            {/* ─── Step 1: Personal Info ───────────────────── */}
            {step === 1 && (
              <Card className="border-none shadow-xl">
                <CardContent className="p-6 sm:p-8">
                  <motion.div
                    variants={staggerContainer}
                    initial="hidden"
                    animate="show"
                    className="space-y-6"
                  >
                    {/* Header */}
                    <motion.div variants={staggerItem} className="text-center space-y-1.5">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-fini-gold/15 mb-2">
                        <span className="text-2xl">🧑‍💻</span>
                      </div>
                      <h2 className="text-2xl font-bold text-foreground">
                        Cuéntanos sobre ti
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        Necesitamos algunos datos para personalizar tu experiencia
                      </p>
                    </motion.div>

                    {/* Name */}
                    <motion.div variants={staggerItem} className="space-y-2">
                      <Label htmlFor="name" className="text-sm font-medium">
                        Nombre completo <span className="text-fini-coral">*</span>
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Ej: María González"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          setErrors((prev) => ({ ...prev, name: '' }));
                        }}
                        className={`h-11 rounded-xl ${errors.name ? 'border-fini-coral focus-visible:ring-fini-coral' : ''}`}
                      />
                      {errors.name && (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-xs text-fini-coral"
                        >
                          {errors.name}
                        </motion.p>
                      )}
                    </motion.div>

                    {/* Email */}
                    <motion.div variants={staggerItem} className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-medium">
                        Correo electrónico <span className="text-fini-coral">*</span>
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="tucorreo@ejemplo.cl"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          setErrors((prev) => ({ ...prev, email: '' }));
                        }}
                        className={`h-11 rounded-xl ${errors.email ? 'border-fini-coral focus-visible:ring-fini-coral' : ''}`}
                      />
                      {errors.email && (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-xs text-fini-coral"
                        >
                          {errors.email}
                        </motion.p>
                      )}
                    </motion.div>

                    {/* Age & RUT row */}
                    <div className="grid grid-cols-2 gap-4">
                      <motion.div variants={staggerItem} className="space-y-2">
                        <Label htmlFor="age" className="text-sm font-medium">
                          Edad <span className="text-fini-coral">*</span>
                        </Label>
                        <Input
                          id="age"
                          type="text"
                          inputMode="numeric"
                          placeholder="13-18"
                          value={age}
                          onChange={handleAgeChange}
                          maxLength={2}
                          className={`h-11 rounded-xl ${errors.age ? 'border-fini-coral focus-visible:ring-fini-coral' : ''}`}
                        />
                        {errors.age && (
                          <motion.p
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-xs text-fini-coral"
                          >
                            {errors.age}
                          </motion.p>
                        )}
                      </motion.div>

                      <motion.div variants={staggerItem} className="space-y-2">
                        <Label htmlFor="rut" className="text-sm font-medium">
                          RUT <span className="text-fini-coral">*</span>
                        </Label>
                        <Input
                          id="rut"
                          type="text"
                          placeholder="12.345.678-9"
                          value={rut}
                          onChange={handleRutChange}
                          maxLength={12}
                          className={`h-11 rounded-xl text-sm ${errors.rut ? 'border-fini-coral focus-visible:ring-fini-coral' : ''}`}
                        />
                        {errors.rut && (
                          <motion.p
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-xs text-fini-coral"
                          >
                            {errors.rut}
                          </motion.p>
                        )}
                      </motion.div>
                    </div>

                    {/* Privacy note */}
                    <motion.p variants={staggerItem} className="text-xs text-muted-foreground text-center">
                      🔒 Tus datos están seguros. Solo los usamos para personalizar tu experiencia.
                    </motion.p>

                    {/* Buttons */}
                    <motion.div variants={staggerItem} className="flex gap-3 pt-2">
                      <Button
                        variant="outline"
                        size="lg"
                        className="flex-1 h-12 rounded-xl"
                        onClick={goBack}
                      >
                        <ArrowLeft className="mr-2 w-4 h-4" />
                        Atrás
                      </Button>
                      <Button
                        size="lg"
                        className="flex-[2] h-12 rounded-xl bg-gradient-to-r from-fini-green to-fini-teal hover:opacity-90 font-semibold cursor-pointer"
                        onClick={handlePersonalNext}
                      >
                        Siguiente
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </motion.div>
                  </motion.div>
                </CardContent>
              </Card>
            )}

            {/* ─── Step 2: Financial Goals ─────────────────── */}
            {step === 2 && (
              <Card className="border-none shadow-xl">
                <CardContent className="p-6 sm:p-8">
                  <motion.div
                    variants={staggerContainer}
                    initial="hidden"
                    animate="show"
                    className="space-y-6"
                  >
                    {/* Header */}
                    <motion.div variants={staggerItem} className="text-center space-y-1.5">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-fini-coral/15 mb-2">
                        <span className="text-2xl">🎯</span>
                      </div>
                      <h2 className="text-2xl font-bold text-foreground">
                        ¿Qué te interesa aprender?
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        Elige los temas que más te llamen la atención. Puedes cambiarlos después.
                      </p>
                    </motion.div>

                    {/* Goal chips */}
                    <motion.div variants={staggerItem} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {FINANCIAL_GOALS.map((goal) => {
                        const isSelected = selectedGoals.includes(goal.id);
                        const Icon = goal.icon;
                        return (
                          <motion.button
                            key={goal.id}
                            type="button"
                            onClick={() => toggleGoal(goal.id)}
                            className={`
                              relative flex flex-col items-center gap-2 p-4 rounded-2xl border-2 cursor-pointer
                              transition-all duration-200 ease-out
                              ${
                                isSelected
                                  ? 'border-fini-green bg-fini-green/10 shadow-md shadow-fini-green/10'
                                  : 'border-border bg-card hover:border-fini-green/40 hover:bg-fini-green/5'
                              }
                            `}
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                          >
                            {/* Selection indicator */}
                            {isSelected && (
                              <motion.div
                                layoutId="goal-check"
                                className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-fini-green flex items-center justify-center"
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                              >
                                <CheckCircle2 className="w-5 h-5 text-white" />
                              </motion.div>
                            )}
                            <span className="text-2xl">{goal.emoji}</span>
                            <Icon className={`w-5 h-5 ${isSelected ? 'text-fini-green' : 'text-muted-foreground'}`} />
                            <span
                              className={`text-sm font-semibold ${
                                isSelected ? 'text-fini-green' : 'text-foreground/70'
                              }`}
                            >
                              {goal.label}
                            </span>
                          </motion.button>
                        );
                      })}
                    </motion.div>

                    {/* Error */}
                    {errors.goals && (
                      <motion.p
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-fini-coral text-center"
                      >
                        {errors.goals}
                      </motion.p>
                    )}

                    {/* Selected count */}
                    {selectedGoals.length > 0 && (
                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-xs text-fini-green text-center font-medium"
                      >
                        {selectedGoals.length} tema{selectedGoals.length > 1 ? 's' : ''} seleccionado
                        {selectedGoals.length > 1 ? 's' : ''}
                      </motion.p>
                    )}

                    {/* Buttons */}
                    <motion.div variants={staggerItem} className="flex gap-3 pt-2">
                      <Button
                        variant="outline"
                        size="lg"
                        className="flex-1 h-12 rounded-xl"
                        onClick={goBack}
                      >
                        <ArrowLeft className="mr-2 w-4 h-4" />
                        Atrás
                      </Button>
                      <Button
                        size="lg"
                        className="flex-[2] h-12 rounded-xl bg-gradient-to-r from-fini-green to-fini-teal hover:opacity-90 font-semibold cursor-pointer"
                        onClick={handleGoalsNext}
                      >
                        Siguiente
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </motion.div>
                  </motion.div>
                </CardContent>
              </Card>
            )}

            {/* ─── Step 3: Completion ──────────────────────── */}
            {step === 3 && (
              <Card className="border-none shadow-xl overflow-hidden">
                {/* Confetti overlay */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  {CONFETTI.map((c) => (
                    <motion.div
                      key={c.id}
                      className="absolute rounded-sm"
                      style={{
                        width: c.size,
                        height: c.size,
                        backgroundColor: c.color,
                        left: `${c.x}%`,
                        top: -10,
                        rotate: c.rotation,
                      }}
                      initial={{ y: -10, opacity: 1 }}
                      animate={{ y: 500, opacity: 0, rotate: c.rotation + 720 }}
                      transition={{
                        duration: c.duration,
                        delay: c.delay,
                        ease: 'easeOut',
                      }}
                    />
                  ))}
                </div>

                <CardContent className="relative p-8 sm:p-12 text-center">
                  <motion.div
                    variants={staggerContainer}
                    initial="hidden"
                    animate="show"
                    className="flex flex-col items-center gap-5"
                  >
                    {/* Success icon */}
                    <motion.div variants={staggerItem}>
                      <motion.div
                        className="w-20 h-20 rounded-full bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center shadow-lg shadow-fini-green/25"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{
                          type: 'spring',
                          stiffness: 260,
                          damping: 20,
                          delay: 0.3,
                        }}
                      >
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.6, type: 'spring', stiffness: 200 }}
                        >
                          <CheckCircle2 className="w-10 h-10 text-white" />
                        </motion.div>
                      </motion.div>
                    </motion.div>

                    {/* Heading */}
                    <motion.div variants={staggerItem} className="space-y-2">
                      <h2 className="text-3xl font-black gradient-text">
                        ¡Todo listo!
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        Tu cuenta está creada y lista para usar
                      </p>
                    </motion.div>

                    {/* Level badge */}
                    <motion.div
                      variants={staggerItem}
                      className="w-full"
                    >
                      <motion.div
                        className="relative mx-auto max-w-xs rounded-2xl bg-gradient-to-br from-fini-gold/15 via-fini-gold/5 to-fini-gold-light/15 border border-fini-gold/25 p-5 text-center"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.5 }}
                      >
                        <div className="text-xs font-semibold uppercase tracking-wider text-fini-gold/70 mb-2">
                          Nivel Inicial
                        </div>
                        <div className="flex items-center justify-center gap-2 mb-1">
                          <span className="text-2xl">🏅</span>
                          <h3 className="text-xl font-black text-fini-gold">
                            {LEVEL_NAMES[0]}
                          </h3>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Completa lecciones y misiones para subir de nivel
                        </p>
                      </motion.div>
                    </motion.div>

                    {/* Name greeting */}
                    <motion.div
                      variants={staggerItem}
                      className="text-sm text-foreground/70"
                    >
                      <span className="font-semibold text-foreground">
                        ¡Bienvenido/a, {name.trim()}!
                      </span>
                      {' '}Estás a punto de comenzar una aventura increíble 🚀
                    </motion.div>

                    {/* Summary chips */}
                    <motion.div
                      variants={staggerItem}
                      className="flex flex-wrap justify-center gap-2"
                    >
                      {selectedGoals.map((goalId) => {
                        const goal = FINANCIAL_GOALS.find((g) => g.id === goalId);
                        if (!goal) return null;
                        return (
                          <span
                            key={goalId}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-fini-green/10 text-fini-green border border-fini-green/20"
                          >
                            {goal.emoji} {goal.label}
                          </span>
                        );
                      })}
                    </motion.div>

                    {/* Dashboard button */}
                    <motion.div variants={staggerItem} className="w-full pt-1">
                      <Button
                        size="lg"
                        className="w-full h-13 text-base font-bold rounded-2xl bg-gradient-to-r from-fini-green to-fini-teal hover:opacity-90 shadow-lg shadow-fini-green/25 cursor-pointer"
                        onClick={handleComplete}
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <motion.div
                            className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
                          />
                        ) : (
                          <>
                            Ir al Dashboard
                            <ArrowRight className="ml-2 w-5 h-5" />
                          </>
                        )}
                      </Button>
                    </motion.div>
                  </motion.div>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
