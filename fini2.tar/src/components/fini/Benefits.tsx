'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useFiniStore } from '@/store/fini';
import { ACHIEVEMENTS_DATA, REWARDS_DATA } from '@/data/fini-data';
import { LEVEL_NAMES, LEVEL_THRESHOLDS } from '@/types/fini';
import {
  Check,
  Lock,
  Star,
  Trophy,
  Zap,
  BookOpen,
  Gift,
  Award,
  Shield,
  Crown,
  TrendingUp,
  Flame,
  Coins,
  ShoppingBag,
} from 'lucide-react';
import { toast } from 'sonner';

// ── Constants ──────────────────────────────────────────────────────────────

const LEVEL_ICONS: React.ComponentType<{ className?: string }>[] = [
  Star,
  Shield,
  Award,
  Trophy,
  Crown,
];

const LEVEL_GRADIENT_CLASSES = [
  'from-slate-400 to-slate-500',
  'from-emerald-400 to-emerald-600',
  'from-fini-teal to-fini-green',
  'from-amber-400 to-orange-500',
  'from-fini-coral to-rose-500',
];

const LEVEL_EMOJI = ['🌱', '💰', '📊', '🏆', '👑'];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 300, damping: 24 },
  },
};

// ── Helpers ────────────────────────────────────────────────────────────────

function getInitials(nameOrSeed: string): string {
  return nameOrSeed
    .split(/[\s._-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}

function formatPoints(pts: number): string {
  return pts.toLocaleString('es-CL');
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('es-CL', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

// ── Component ──────────────────────────────────────────────────────────────

export default function Benefits() {
  const user = useFiniStore((s) => s.user);
  const achievements = useFiniStore((s) => s.achievements);
  const topicProgress = useFiniStore((s) => s.topicProgress);
  const updateUser = useFiniStore((s) => s.updateUser);

  // Rewards local state
  const [redeemedIds, setRedeemedIds] = useState<Set<string>>(new Set());
  const [redeemingReward, setRedeemingReward] = useState<string | null>(null);
  const [rewardFilter, setRewardFilter] = useState<
    'todos' | 'disponibles' | 'canjeados'
  >('todos');
  const [isRedeeming, setIsRedeeming] = useState(false);

  // ── Derived: level progress ──────────────────────────────────────────────

  const levelProgress = useMemo(() => {
    if (!user) return { percent: 0, current: 0, next: 0, isMax: false };
    const currentThreshold =
      LEVEL_THRESHOLDS[user.level - 1] ?? LEVEL_THRESHOLDS[0];
    const nextThreshold =
      LEVEL_THRESHOLDS[user.level] ?? LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1];

    if (user.level >= LEVEL_NAMES.length) {
      return {
        percent: 100,
        current: user.points,
        next: user.points,
        isMax: true,
      };
    }

    const range = nextThreshold - currentThreshold;
    const progress = user.points - currentThreshold;
    const percent = Math.min(100, Math.round((progress / range) * 100));

    return { percent, current: user.points, next: nextThreshold, isMax: false };
  }, [user]);

  // ── Derived: completed topics ────────────────────────────────────────────

  const completedTopics = useMemo(
    () => topicProgress.filter((tp) => tp.status === 'completed').length,
    [topicProgress],
  );

  // ── Derived: merged achievements ─────────────────────────────────────────

  const mergedAchievements = useMemo(() => {
    return ACHIEVEMENTS_DATA.map((a) => {
      const earned = achievements.find((ea) => ea.id === a.id);
      return {
        ...a,
        earned: earned?.earned ?? false,
        earnedAt: earned?.earnedAt,
      };
    });
  }, [achievements]);

  // ── Derived: filtered rewards ────────────────────────────────────────────

  const filteredRewards = useMemo(() => {
    return REWARDS_DATA.filter((r) => {
      if (rewardFilter === 'disponibles') {
        const isRedeemed =
          redeemedIds.has(r.id) || !r.available;
        if (isRedeemed) return false;
        if (user && r.pointCost > user.points) return false;
        return true;
      }
      if (rewardFilter === 'canjeados') {
        return redeemedIds.has(r.id);
      }
      return true;
    });
  }, [rewardFilter, redeemedIds, user]);

  // ── Redeem handler ───────────────────────────────────────────────────────

  const handleRedeem = useCallback(async () => {
    if (!redeemingReward || !user) return;

    const reward = REWARDS_DATA.find((r) => r.id === redeemingReward);
    if (!reward) return;

    setIsRedeeming(true);

    try {
      const res = await fetch('/api/benefits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rewardId: reward.id,
          userId: user.id,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message ?? 'Error al canjear el premio');
      }

      // Deduct points
      updateUser({ points: user.points - reward.pointCost });

      // Mark as redeemed
      setRedeemedIds((prev) => new Set(prev).add(reward.id));

      // Update quantity locally
      if (reward.quantity > 0) {
        reward.quantity -= 1;
      }

      toast.success('¡Premio canjeado! 🎉', {
        description: `Canjeaste "${reward.name}" por ${formatPoints(reward.pointCost)} puntos.`,
      });

      setRedeemingReward(null);
    } catch (err) {
      toast.error('No se pudo canjear', {
        description:
          err instanceof Error ? err.message : 'Intenta de nuevo más tarde.',
      });
    } finally {
      setIsRedeeming(false);
    }
  }, [redeemingReward, user, updateUser]);

  // ── Guard ────────────────────────────────────────────────────────────────

  if (!user) return null;

  const initials = getInitials(user.avatarSeed || user.name);

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-28">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Beneficios</h1>
        <p className="text-muted-foreground mt-1">
          Revisa tu perfil, logros y premios disponibles
        </p>
      </div>

      <Tabs defaultValue="perfil" className="w-full">
        <TabsList className="w-full grid grid-cols-3 h-auto p-1 mb-6">
          <TabsTrigger
            value="perfil"
            className="py-2.5 text-sm font-medium data-[state=active]:bg-fini-green data-[state=active]:text-white"
          >
            Mi Perfil
          </TabsTrigger>
          <TabsTrigger
            value="logros"
            className="py-2.5 text-sm font-medium data-[state=active]:bg-fini-green data-[state=active]:text-white"
          >
            Logros
          </TabsTrigger>
          <TabsTrigger
            value="premios"
            className="py-2.5 text-sm font-medium data-[state=active]:bg-fini-green data-[state=active]:text-white"
          >
            Premios
          </TabsTrigger>
        </TabsList>

        {/* ═══════════════════════════════════════════════════════════════════ */}
        {/* TAB 1 — MI PERFIL                                                   */}
        {/* ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="perfil">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-6"
          >
            {/* ── Profile Card ──────────────────────────────────────────── */}
            <motion.div variants={itemVariants}>
              <Card className="card-glow overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                    {/* Avatar + Level Badge */}
                    <div className="relative shrink-0">
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-fini-green to-fini-teal flex items-center justify-center ring-4 ring-fini-green/20">
                        <span className="text-3xl font-bold text-white">
                          {initials}
                        </span>
                      </div>
                      <Badge className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-gradient-to-r from-fini-gold to-amber-500 text-white border-0 text-xs font-bold px-2.5 py-0.5 shadow-md">
                        Nv. {user.level}
                      </Badge>
                    </div>

                    {/* Info */}
                    <div className="flex-1 text-center sm:text-left space-y-2">
                      <div>
                        <h2 className="text-xl font-bold">{user.name}</h2>
                        <p className="text-sm text-muted-foreground">
                          {user.email}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className="border-fini-green/40 text-fini-green bg-fini-green/5 font-semibold"
                      >
                        {LEVEL_NAMES[user.level - 1] ?? 'Aprendiz'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ── Level Progress ─────────────────────────────────────────── */}
            <motion.div variants={itemVariants}>
              <Card className="card-glow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-fini-green" />
                    Progreso de Nivel
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">
                      {LEVEL_NAMES[user.level - 1] ?? 'Aprendiz'}
                    </span>
                    {levelProgress.isMax ? (
                      <span className="gradient-text-gold font-bold">
                        ¡Nivel máximo! 🎉
                      </span>
                    ) : (
                      <span className="text-muted-foreground">
                        {formatPoints(user.points)} /{' '}
                        {formatPoints(levelProgress.next)} pts
                      </span>
                    )}
                  </div>
                  <Progress
                    value={levelProgress.percent}
                    className="h-3 progress-animate"
                  />
                  {!levelProgress.isMax && (
                    <p className="text-xs text-muted-foreground text-right">
                      {formatPoints(levelProgress.next - user.points)} puntos
                      para{' '}
                      {LEVEL_NAMES[user.level] ?? 'siguiente nivel'}
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* ── Stats Grid ─────────────────────────────────────────────── */}
            <motion.div
              variants={itemVariants}
              className="grid grid-cols-3 gap-3"
            >
              <Card className="card-glow py-4">
                <CardContent className="flex flex-col items-center text-center gap-1.5 px-3">
                  <div className="w-10 h-10 rounded-xl bg-fini-gold/10 flex items-center justify-center">
                    <Coins className="w-5 h-5 text-fini-gold" />
                  </div>
                  <p className="text-lg md:text-xl font-bold gradient-text-gold">
                    {formatPoints(user.points)}
                  </p>
                  <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">
                    Puntos
                  </p>
                </CardContent>
              </Card>

              <Card className="card-glow py-4">
                <CardContent className="flex flex-col items-center text-center gap-1.5 px-3">
                  <div className="w-10 h-10 rounded-xl bg-fini-coral/10 flex items-center justify-center">
                    <Flame className="w-5 h-5 text-fini-coral" />
                  </div>
                  <p className="text-lg md:text-xl font-bold">
                    {user.streak}
                  </p>
                  <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">
                    Racha
                  </p>
                </CardContent>
              </Card>

              <Card className="card-glow py-4">
                <CardContent className="flex flex-col items-center text-center gap-1.5 px-3">
                  <div className="w-10 h-10 rounded-xl bg-fini-teal/10 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-fini-teal" />
                  </div>
                  <p className="text-lg md:text-xl font-bold">
                    {completedTopics}
                  </p>
                  <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">
                    Temas
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <Separator />

            {/* ── Level Evolution ────────────────────────────────────────── */}
            <motion.div variants={itemVariants}>
              <Card className="card-glow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <Star className="w-5 h-5 text-fini-gold" />
                    Evolución de Nivel
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between gap-2 sm:gap-4">
                    {LEVEL_NAMES.map((name, i) => {
                      const isCurrent = user.level === i + 1;
                      const isUnlocked = user.level >= i + 1;
                      const Icon = LEVEL_ICONS[i];

                      return (
                        <div
                          key={name}
                          className="flex flex-col items-center gap-2 flex-1"
                        >
                          {/* Badge */}
                          <motion.div
                            whileHover={{ scale: 1.08 }}
                            className={`
                              relative w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center
                              transition-all duration-300
                              ${
                                isCurrent
                                  ? `bg-gradient-to-br ${LEVEL_GRADIENT_CLASSES[i]} shadow-lg ring-2 ring-fini-green/30`
                                  : isUnlocked
                                    ? 'bg-gradient-to-br from-fini-green/20 to-fini-teal/20 ring-1 ring-fini-green/20'
                                    : 'bg-muted/60 opacity-50'
                              }
                            `}
                          >
                            {isUnlocked ? (
                              <Icon className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                            ) : (
                              <Lock className="w-5 h-5 text-muted-foreground" />
                            )}

                            {/* Pulse for current level */}
                            {isCurrent && (
                              <span className="absolute -inset-1 rounded-2xl bg-fini-green/20 animate-ping pointer-events-none" />
                            )}

                            {/* Emoji above */}
                            <span className="absolute -top-3 text-lg">
                              {LEVEL_EMOJI[i]}
                            </span>
                          </motion.div>

                          {/* Label */}
                          <div className="text-center">
                            <p
                              className={`text-[10px] sm:text-xs font-semibold leading-tight ${
                                isCurrent
                                  ? 'text-fini-green'
                                  : isUnlocked
                                    ? 'text-foreground'
                                    : 'text-muted-foreground'
                              }`}
                            >
                              {name}
                            </p>
                            <p className="text-[9px] text-muted-foreground">
                              {i > 0
                                ? `${formatPoints(LEVEL_THRESHOLDS[i])} pts`
                                : 'Inicio'}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </TabsContent>

        {/* ═══════════════════════════════════════════════════════════════════ */}
        {/* TAB 2 — LOGROS                                                      */}
        {/* ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="logros">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {mergedAchievements.map((achievement) => {
              const isEarned = achievement.earned;

              return (
                <motion.div key={achievement.id} variants={itemVariants}>
                  <Card
                    className={`
                      card-glow overflow-hidden transition-all duration-300
                      ${
                        isEarned
                          ? 'border-fini-green/30 bg-fini-green/[0.02]'
                          : 'border-border/40 opacity-70 grayscale-[30%]'
                      }
                    `}
                  >
                    <CardContent className="p-4 sm:p-5">
                      <div className="flex items-start gap-4">
                        {/* Icon */}
                        <div
                          className={`
                            w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0
                            ${
                              isEarned
                                ? 'bg-fini-gold/10'
                                : 'bg-muted/60'
                            }
                          `}
                        >
                          {isEarned ? (
                            <span>{achievement.icon}</span>
                          ) : (
                            <Lock className="w-5 h-5 text-muted-foreground" />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-sm truncate">
                              {achievement.name}
                            </h3>
                            {isEarned && (
                              <Check className="w-4 h-4 text-fini-green shrink-0" />
                            )}
                          </div>
                          <p
                            className={`text-xs leading-relaxed ${
                              isEarned
                                ? 'text-foreground/80'
                                : 'text-muted-foreground'
                            }`}
                          >
                            {achievement.description}
                          </p>

                          <div className="flex items-center justify-between mt-3">
                            <Badge
                              variant="secondary"
                              className={`text-[11px] font-medium px-2 py-0 ${
                                isEarned
                                  ? 'bg-fini-gold/10 text-fini-gold border-fini-gold/20'
                                  : 'bg-muted/60 text-muted-foreground'
                              }`}
                            >
                              <Star className="w-3 h-3 mr-1" />
                              {formatPoints(achievement.points)} pts
                            </Badge>

                            {isEarned && achievement.earnedAt && (
                              <span className="text-[10px] text-muted-foreground">
                                {formatDate(achievement.earnedAt)}
                              </span>
                            )}

                            {!isEarned && (
                              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                <Lock className="w-3 h-3" />
                                Bloqueado
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Empty state */}
          {mergedAchievements.filter((a) => a.earned).length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <div className="w-16 h-16 rounded-2xl bg-muted/60 flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground font-medium">
                ¡Aún no tienes logros!
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Sigue aprendiendo en la Academia para desbloquearlos.
              </p>
            </motion.div>
          )}
        </TabsContent>

        {/* ═══════════════════════════════════════════════════════════════════ */}
        {/* TAB 3 — PREMIOS                                                     */}
        {/* ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="premios">
          <div className="space-y-5">
            {/* Filter Buttons */}
            <div className="flex items-center gap-2">
              {(
                [
                  { key: 'todos', label: 'Todos' },
                  { key: 'disponibles', label: 'Disponibles' },
                  { key: 'canjeados', label: 'Canjeados' },
                ] as const
              ).map((filter) => (
                <Button
                  key={filter.key}
                  variant={rewardFilter === filter.key ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setRewardFilter(filter.key)}
                  className={
                    rewardFilter === filter.key
                      ? 'bg-fini-green hover:bg-fini-green/90 text-white border-0'
                      : ''
                  }
                >
                  {filter.label}
                </Button>
              ))}

              {/* Points balance */}
              <div className="ml-auto flex items-center gap-1.5 text-sm text-muted-foreground">
                <Coins className="w-4 h-4 text-fini-gold" />
                <span className="font-semibold gradient-text-gold">
                  {formatPoints(user.points)}
                </span>
                <span>puntos</span>
              </div>
            </div>

            {/* Reward Cards */}
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              key={rewardFilter}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              {filteredRewards.length === 0 ? (
                <motion.div
                  variants={itemVariants}
                  className="col-span-full text-center py-16"
                >
                  <div className="w-16 h-16 rounded-2xl bg-muted/60 flex items-center justify-center mx-auto mb-4">
                    <Gift className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground font-medium">
                    {rewardFilter === 'canjeados'
                      ? 'Aún no has canjeado premios'
                      : rewardFilter === 'disponibles'
                        ? 'No tienes suficientes puntos aún'
                        : 'No hay premios disponibles'}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {rewardFilter === 'todos' &&
                      '¡Sigue completando desafíos para ganar más puntos!'}
                  </p>
                </motion.div>
              ) : (
                filteredRewards.map((reward) => {
                  const isRedeemed = redeemedIds.has(reward.id);
                  const canAfford = user.points >= reward.pointCost;
                  const isAvailable =
                    reward.available &&
                    (reward.quantity === -1 || reward.quantity > 0);

                  return (
                    <motion.div key={reward.id} variants={itemVariants}>
                      <Card
                        className={`
                          card-glow overflow-hidden transition-all duration-300
                          ${
                            isRedeemed
                              ? 'border-fini-green/30 bg-fini-green/[0.02]'
                              : ''
                          }
                          ${!isAvailable ? 'opacity-50' : ''}
                        `}
                      >
                        <CardContent className="p-4 sm:p-5">
                          <div className="space-y-3">
                            {/* Header: name + sponsor */}
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2 min-w-0">
                                <div className="w-10 h-10 rounded-xl bg-fini-coral/10 flex items-center justify-center shrink-0">
                                  <ShoppingBag className="w-5 h-5 text-fini-coral" />
                                </div>
                                <div className="min-w-0">
                                  <h3 className="font-semibold text-sm truncate">
                                    {reward.name}
                                  </h3>
                                  {reward.sponsorName && (
                                    <Badge
                                      variant="secondary"
                                      className="text-[10px] px-1.5 py-0 mt-0.5"
                                    >
                                      {reward.sponsorName}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Description */}
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              {reward.description}
                            </p>

                            {/* Cost + Quantity */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <Coins className="w-4 h-4 text-fini-gold" />
                                <span
                                  className={`font-bold text-sm ${
                                    canAfford
                                      ? 'gradient-text-gold'
                                      : 'text-muted-foreground'
                                  }`}
                                >
                                  {formatPoints(reward.pointCost)} pts
                                </span>
                              </div>

                              {/* Quantity indicator */}
                              {reward.quantity > 0 && (
                                <span
                                  className={`text-[11px] font-medium ${
                                    reward.quantity <= 5
                                      ? 'text-fini-coral'
                                      : 'text-muted-foreground'
                                  }`}
                                >
                                  {isRedeemed
                                    ? '✓ Canjeado'
                                    : `Quedan ${reward.quantity}`}
                                </span>
                              )}
                              {reward.quantity === -1 && !isRedeemed && (
                                <span className="text-[11px] text-muted-foreground">
                                  ∞ Disponible
                                </span>
                              )}
                            </div>

                            <Separator />

                            {/* Action */}
                            <div className="flex items-center justify-between">
                              {isRedeemed ? (
                                <div className="flex items-center gap-1.5 text-fini-green text-sm font-medium">
                                  <Check className="w-4 h-4" />
                                  ¡Canjeado!
                                </div>
                              ) : !isAvailable ? (
                                <span className="text-sm text-muted-foreground">
                                  Agotado
                                </span>
                              ) : (
                                <Dialog
                                  open={redeemingReward === reward.id}
                                  onOpenChange={(open) => {
                                    if (!open) setRedeemingReward(null);
                                    else setRedeemingReward(reward.id);
                                  }}
                                >
                                  <DialogTrigger asChild>
                                    <Button
                                      size="sm"
                                      disabled={!canAfford || !isAvailable}
                                      className={`${
                                        canAfford
                                          ? 'bg-fini-green hover:bg-fini-green/90 text-white border-0'
                                          : ''
                                      }`}
                                    >
                                      <Gift className="w-4 h-4 mr-1.5" />
                                      Canjear
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-md">
                                    <DialogHeader>
                                      <DialogTitle className="flex items-center gap-2">
                                        <Gift className="w-5 h-5 text-fini-coral" />
                                        Confirmar Canje
                                      </DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4 pt-2">
                                      <div className="rounded-xl bg-muted/50 p-4 space-y-3">
                                        <div>
                                          <p className="font-semibold">
                                            {reward.name}
                                          </p>
                                          <p className="text-sm text-muted-foreground mt-1">
                                            {reward.description}
                                          </p>
                                        </div>
                                        <Separator />
                                        <div className="flex items-center justify-between text-sm">
                                          <span className="text-muted-foreground">
                                            Costo
                                          </span>
                                          <span className="font-bold gradient-text-gold">
                                            {formatPoints(reward.pointCost)}{' '}
                                            puntos
                                          </span>
                                        </div>
                                        <div className="flex items-center justify-between text-sm">
                                          <span className="text-muted-foreground">
                                            Tu saldo
                                          </span>
                                          <span className="font-semibold">
                                            {formatPoints(user.points)} puntos
                                          </span>
                                        </div>
                                        <div className="flex items-center justify-between text-sm">
                                          <span className="text-muted-foreground">
                                            Saldo después
                                          </span>
                                          <span
                                            className={`font-semibold ${
                                              user.points -
                                                reward.pointCost <
                                              0
                                                ? 'text-red-500'
                                                : 'text-fini-green'
                                            }`}
                                          >
                                            {formatPoints(
                                              Math.max(
                                                0,
                                                user.points -
                                                  reward.pointCost,
                                              ),
                                            )}{' '}
                                            puntos
                                          </span>
                                        </div>
                                        {reward.sponsorName && (
                                          <div className="flex items-center justify-between text-sm">
                                            <span className="text-muted-foreground">
                                              Patrocinador
                                            </span>
                                            <Badge
                                              variant="secondary"
                                              className="text-xs"
                                            >
                                              {reward.sponsorName}
                                            </Badge>
                                          </div>
                                        )}
                                      </div>

                                      <div className="flex gap-3">
                                        <Button
                                          variant="outline"
                                          className="flex-1"
                                          onClick={() =>
                                            setRedeemingReward(null)
                                          }
                                        >
                                          Cancelar
                                        </Button>
                                        <Button
                                          className="flex-1 bg-fini-green hover:bg-fini-green/90 text-white border-0"
                                          onClick={handleRedeem}
                                          disabled={isRedeeming}
                                        >
                                          {isRedeeming ? (
                                            <span className="flex items-center gap-2">
                                              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                              Canjeando...
                                            </span>
                                          ) : (
                                            'Confirmar'
                                          )}
                                        </Button>
                                      </div>
                                    </div>
                                  </DialogContent>
                                </Dialog>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })
              )}
            </motion.div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
