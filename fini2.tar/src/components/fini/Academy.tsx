'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useFiniStore } from '@/store/fini';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { motion, AnimatePresence } from 'framer-motion';
import { TOPICS, TOPIC_QUIZZES, TOPIC_EXPLANATIONS } from '@/data/fini-data';
import { LEVEL_NAMES } from '@/types/fini';
import type { TopicProgress } from '@/types/fini';
import ReactMarkdown from 'react-markdown';
import { Lock, ArrowLeft, Trophy, PartyPopper, ChevronRight, CheckCircle2, XCircle, RotateCcw, Sparkles } from 'lucide-react';

/* ──────────────── helpers ──────────────── */

const fmt = (n: number) =>
  new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0,
  }).format(n);

const fmtShort = (n: number) => {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString('es-CL')}`;
};

/* ──────────────── Topic List View ──────────────── */

function TopicListView() {
  const {
    topicProgress,
    setTopicProgress,
    setSelectedTopicId,
    updateTopicProgress,
  } = useFiniStore();

  // Initialise progress on first load
  useEffect(() => {
    if (topicProgress.length === 0) {
      const initial: TopicProgress[] = TOPICS.map((t, i) => ({
        topicId: t.id,
        status: i === 0 ? 'available' : 'locked',
        quizAttempts: 0,
      }));
      setTopicProgress(initial);
    }
  }, [topicProgress.length, setTopicProgress]);

  const sorted = [...TOPICS].sort((a, b) => a.order - b.order);

  const getProgress = (topicId: string): TopicProgress | undefined =>
    topicProgress.find((p) => p.topicId === topicId);

  const handleStart = (topicId: string) => {
    updateTopicProgress(topicId, { status: 'in_progress' });
    setSelectedTopicId(topicId);
  };

  const handleReview = (topicId: string) => {
    setSelectedTopicId(topicId);
  };

  const statusConfig = {
    locked: {
      badge: null,
      cardClass: 'opacity-60 grayscale',
      action: null,
    },
    available: {
      badge: (
        <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-200 text-xs">
          <Sparkles className="size-3 mr-0.5" /> Nuevo
        </Badge>
      ),
      cardClass: 'border-2 border-emerald-400 shadow-emerald-100 shadow-md',
      action: (id: string) => (
        <Button
          size="sm"
          className="bg-emerald-500 hover:bg-emerald-600 text-white w-full mt-3"
          onClick={() => handleStart(id)}
        >
          Comenzar <ChevronRight className="size-4 ml-1" />
        </Button>
      ),
    },
    in_progress: {
      badge: (
        <Badge className="bg-amber-500/15 text-amber-600 border-amber-200 text-xs">
          En progreso
        </Badge>
      ),
      cardClass: 'border-2 border-amber-300 shadow-amber-100 shadow-md',
      action: (id: string) => (
        <Button
          size="sm"
          className="bg-amber-500 hover:bg-amber-600 text-white w-full mt-3"
          onClick={() => setSelectedTopicId(id)}
        >
          Continuar <ChevronRight className="size-4 ml-1" />
        </Button>
      ),
    },
    completed: {
      badge: (
        <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-200 text-xs">
          Completado ✓
        </Badge>
      ),
      cardClass: 'border border-emerald-200 bg-emerald-50/30',
      action: (id: string) => (
        <Button
          size="sm"
          variant="outline"
          className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 w-full mt-3"
          onClick={() => handleReview(id)}
        >
          Repasar
        </Button>
      ),
    },
  } as const;

  return (
    <div className="space-y-6">
      <div className="text-center space-y-1">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
          <span className="mr-2">🎓</span>Academia FINI
        </h1>
        <p className="text-sm text-muted-foreground">
          Aprende finanzas de forma divertida — gana puntos y desbloquea niveles
        </p>
      </div>

      {/* Progress overview */}
      <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-emerald-800">
              Progreso general
            </span>
            <span className="text-sm font-bold text-emerald-700">
              {topicProgress.filter((p) => p.status === 'completed').length}/
              {TOPICS.length}
            </span>
          </div>
          <Progress
            value={
              (topicProgress.filter((p) => p.status === 'completed').length /
                TOPICS.length) *
              100
            }
            className="h-2.5"
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sorted.map((topic, idx) => {
          const progress = getProgress(topic.id);
          const status = progress?.status ?? 'locked';
          const cfg = statusConfig[status];

          return (
            <motion.div
              key={topic.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06, duration: 0.35 }}
            >
              <Card
                className={`relative overflow-hidden transition-all hover:shadow-lg ${cfg.cardClass}`}
              >
                {status === 'locked' && (
                  <div className="absolute inset-0 z-10 flex items-center justify-center bg-background/60 backdrop-blur-[1px]">
                    <Lock className="size-8 text-muted-foreground/60" />
                  </div>
                )}
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{topic.icon}</span>
                      <h3 className="font-semibold text-sm leading-tight">
                        {topic.title}
                      </h3>
                    </div>
                    {cfg.badge}
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-1">
                    {topic.description}
                  </p>
                  {progress?.quizScore != null && status === 'completed' && (
                    <p className="text-xs text-emerald-600 font-medium">
                      Quiz: {progress.quizScore}/{TOPIC_QUIZZES[topic.id]?.length ?? 0}
                    </p>
                  )}
                  {cfg.action?.(topic.id)}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/* ──────────────── Simulators ──────────────── */

function InteresCompuestoSimulator() {
  const [capital, setCapital] = useState(500_000);
  const [tasa, setTasa] = useState(8);
  const [anios, setAnios] = useState(10);

  const data = useMemo(() => {
    const rows: { year: number; simple: number; compuesto: number }[] = [];
    for (let y = 0; y <= anios; y++) {
      const simple = capital * (1 + (tasa / 100) * y);
      const compuesto = capital * Math.pow(1 + tasa / 100, y);
      rows.push({ year: y, simple: Math.round(simple), compuesto: Math.round(compuesto) });
    }
    return rows;
  }, [capital, tasa, anios]);

  const finalSimple = data[data.length - 1].simple;
  const finalCompuesto = data[data.length - 1].compuesto;
  const diff = finalCompuesto - finalSimple;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Capital inicial
          </label>
          <Slider
            value={[capital]}
            onValueChange={([v]) => setCapital(v)}
            min={0}
            max={1_000_000}
            step={50_000}
          />
          <p className="text-sm font-bold text-center">{fmt(capital)}</p>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Tasa interés anual
          </label>
          <Slider
            value={[tasa]}
            onValueChange={([v]) => setTasa(v)}
            min={1}
            max={20}
            step={0.5}
          />
          <p className="text-sm font-bold text-center">{tasa}%</p>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Años
          </label>
          <Slider
            value={[anios]}
            onValueChange={([v]) => setAnios(v)}
            min={1}
            max={30}
          />
          <p className="text-sm font-bold text-center">{anios} años</p>
        </div>
      </div>

      <Card className="p-3">
        <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
          <span className="flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full bg-sky-500" /> Simple: <b>{fmtShort(finalSimple)}</b>
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full bg-emerald-500" /> Compuesto: <b>{fmtShort(finalCompuesto)}</b>
          </span>
          <span className="font-semibold text-emerald-700">
            ¡Ganas {fmtShort(diff)} extra!
          </span>
        </div>
      </Card>

      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
          <XAxis dataKey="year" tick={{ fontSize: 11 }} />
          <YAxis tickFormatter={(v: number) => fmtShort(v)} tick={{ fontSize: 11 }} width={60} />
          <Tooltip formatter={(v: number) => fmt(v)} labelFormatter={(l: string) => `Año ${l}`} />
          <Line type="monotone" dataKey="simple" stroke="#0ea5e9" strokeWidth={2} dot={false} name="Interés Simple" />
          <Line type="monotone" dataKey="compuesto" stroke="#22c55e" strokeWidth={2.5} dot={false} name="Interés Compuesto" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function PresupuestoSimulator() {
  const [ingreso, setIngreso] = useState(150_000);
  const [necesidades, setNecesidades] = useState(50);
  const [gustos, setGustos] = useState(30);
  const [ahorro, setAhorro] = useState(20);

  const totalPct = necesidades + gustos + ahorro;
  const sobre100 = totalPct > 100;

  const categories = [
    { name: 'Necesidades', pct: necesidades, color: '#f97316', icon: '🏠', amount: Math.round(ingreso * necesidades / 100) },
    { name: 'Gustos', pct: gustos, color: '#8b5cf6', icon: '🎮', amount: Math.round(ingreso * gustos / 100) },
    { name: 'Ahorro', pct: ahorro, color: '#22c55e', icon: '🐷', amount: Math.round(ingreso * ahorro / 100) },
  ];

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <label className="text-xs font-medium text-muted-foreground">
          Ingreso mensual
        </label>
        <Slider
          value={[ingreso]}
          onValueChange={([v]) => setIngreso(v)}
          min={50_000}
          max={200_000}
          step={5_000}
        />
        <p className="text-sm font-bold text-center">{fmt(ingreso)}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {categories.map((cat) => (
          <Card key={cat.name} className="p-3" style={{ borderLeft: `4px solid ${cat.color}` }}>
            <p className="text-xs text-muted-foreground mb-1">
              {cat.icon} {cat.name}
            </p>
            <Slider
              value={[cat.pct]}
              onValueChange={([v]) => {
                if (cat.name === 'Necesidades') setNecesidades(v);
                if (cat.name === 'Gustos') setGustos(v);
                if (cat.name === 'Ahorro') setAhorro(v);
              }}
              min={0}
              max={100}
              step={1}
            />
            <div className="flex justify-between text-xs mt-1">
              <span className="font-bold">{cat.pct}%</span>
              <span className="font-medium text-muted-foreground">{fmt(cat.amount)}</span>
            </div>
          </Card>
        ))}
      </div>

      {sobre100 && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3 text-center font-medium"
        >
          ⚠️ ¡Te pasaste del 100%! Estás gastando más de lo que ganas. Ajusta tus categorías.
        </motion.div>
      )}

      <Card className="p-3">
        <p className="text-xs text-muted-foreground mb-3 text-center font-medium">
          Distribución de tu sueldo
        </p>
        <div className="flex h-8 rounded-full overflow-hidden">
          {categories.map((cat) => (
            <div
              key={cat.name}
              className="flex items-center justify-center text-[10px] font-bold text-white transition-all"
              style={{
                width: `${cat.pct}%`,
                backgroundColor: cat.color,
              }}
            >
              {cat.pct >= 15 ? `${cat.pct}%` : ''}
            </div>
          ))}
        </div>
        <div className="flex flex-wrap justify-center gap-3 mt-3">
          {categories.map((cat) => (
            <span key={cat.name} className="flex items-center gap-1 text-xs">
              <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
              {cat.name}: {fmt(cat.amount)}
            </span>
          ))}
        </div>
      </Card>
    </div>
  );
}

function AhorroVsGastoSimulator() {
  const [ahorroMensual, setAhorroMensual] = useState(15_000);

  const data = useMemo(() => {
    const rows: { mes: string; ahorrando: number; gastando: number }[] = [];
    for (let m = 1; m <= 12; m++) {
      rows.push({
        mes: `Mes ${m}`,
        ahorrando: ahorroMensual * m,
        gastando: 0,
      });
    }
    return rows;
  }, [ahorroMensual]);

  const totalAhorrado = ahorroMensual * 12;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="p-4 border-2 border-emerald-300 bg-emerald-50/30">
          <p className="text-xs font-medium text-emerald-700 mb-1">💰 Ahorrando cada mes</p>
          <p className="text-2xl font-bold text-emerald-700">{fmt(totalAhorrado)}</p>
          <p className="text-xs text-emerald-600">en 12 meses</p>
        </Card>
        <Card className="p-4 border-2 border-red-200 bg-red-50/30">
          <p className="text-xs font-medium text-red-700 mb-1">💸 Gastando todo</p>
          <p className="text-2xl font-bold text-red-600">$0</p>
          <p className="text-xs text-red-500">en 12 meses</p>
        </Card>
      </div>

      <div className="space-y-1">
        <label className="text-xs font-medium text-muted-foreground">
          Ahorro mensual
        </label>
        <Slider
          value={[ahorroMensual]}
          onValueChange={([v]) => setAhorroMensual(v)}
          min={0}
          max={50_000}
          step={1_000}
        />
        <p className="text-sm font-bold text-center">{fmt(ahorroMensual)}/mes</p>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
          <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
          <YAxis tickFormatter={(v: number) => fmtShort(v)} tick={{ fontSize: 11 }} width={55} />
          <Tooltip formatter={(v: number) => fmt(v)} />
          <Area
            type="monotone"
            dataKey="ahorrando"
            stroke="#22c55e"
            fill="#22c55e"
            fillOpacity={0.15}
            strokeWidth={2.5}
            name="Ahorro acumulado"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function DeudaBuenaMalaSimulator() {
  const monto = 2_000_000;
  const caeBuena = 5;
  const caeMala = 40;
  const plazoAnios = 5;

  const costoBuena = Math.round(monto * (caeBuena / 100) * plazoAnios);
  const costoMala = Math.round(monto * (caeMala / 100) * plazoAnios);
  const totalBuena = monto + costoBuena;
  const totalMala = monto + costoMala;
  const diff = totalMala - totalBuena;
  const cuotaBuena = Math.round(totalBuena / (plazoAnios * 12));
  const cuotaMala = Math.round(totalMala / (plazoAnios * 12));

  const data = useMemo(() => {
    const rows: { mes: number; buena: number; mala: number }[] = [];
    for (let m = 0; m <= plazoAnios * 12; m++) {
      rows.push({
        mes: m,
        buena: Math.round(monto + (costoBuena * m) / (plazoAnios * 12)),
        mala: Math.round(monto + (costoMala * m) / (plazoAnios * 12)),
      });
    }
    return rows;
  }, [costoBuena, costoMala]);

  return (
    <div className="space-y-5">
      <Card className="p-3 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <p className="text-xs text-emerald-600 font-medium mb-2">📊 Escenario: Crédito de ${fmt(monto)} a {plazoAnios} años</p>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="p-4 border-2 border-emerald-300">
          <p className="font-semibold text-emerald-700 mb-3">✅ Deuda Buena</p>
          <p className="text-xs text-muted-foreground">Crédito de estudio — CAE 5%</p>
          <div className="mt-2 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Intereses:</span><span className="font-medium">{fmt(costoBuena)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Total a pagar:</span><span className="font-bold text-emerald-700">{fmt(totalBuena)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Cuota mensual:</span><span className="font-medium">{fmt(cuotaBuena)}</span></div>
          </div>
        </Card>
        <Card className="p-4 border-2 border-red-300">
          <p className="font-semibold text-red-600 mb-3">❌ Deuda Mala</p>
          <p className="text-xs text-muted-foreground">Tarjeta de crédito — CAE 40%</p>
          <div className="mt-2 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Intereses:</span><span className="font-medium">{fmt(costoMala)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Total a pagar:</span><span className="font-bold text-red-600">{fmt(totalMala)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Cuota mensual:</span><span className="font-medium">{fmt(cuotaMala)}</span></div>
          </div>
        </Card>
      </div>

      <Card className="p-3 text-center">
        <p className="text-sm font-semibold text-red-600">
          💸 La deuda mala te cuesta <span className="text-lg">{fmt(diff)}</span> más
        </p>
      </Card>

      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
          <XAxis dataKey="mes" tick={{ fontSize: 10 }} label={{ value: 'Meses', position: 'insideBottom', offset: -2, fontSize: 11 }} />
          <YAxis tickFormatter={(v: number) => fmtShort(v)} tick={{ fontSize: 11 }} width={60} />
          <Tooltip formatter={(v: number) => fmt(v)} labelFormatter={(l: string) => `Mes ${l}`} />
          <Line type="monotone" dataKey="buena" stroke="#22c55e" strokeWidth={2.5} dot={false} name="Crédito Estudio" />
          <Line type="monotone" dataKey="mala" stroke="#ef4444" strokeWidth={2.5} dot={false} name="Tarjeta Crédito" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function TarjetaDebitoCreditoSimulator() {
  const [monto, setMonto] = useState(25_000);

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <label className="text-xs font-medium text-muted-foreground">
          Monto de compra
        </label>
        <Slider
          value={[monto]}
          onValueChange={([v]) => setMonto(v)}
          min={1_000}
          max={100_000}
          step={1_000}
        />
        <p className="text-sm font-bold text-center">{fmt(monto)}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="p-4 border-2 border-sky-300 bg-sky-50/30">
          <p className="font-semibold text-sky-700 mb-3">💳 Tarjeta de Débito</p>
          <div className="flex items-center justify-center gap-3 py-4">
            <div className="bg-sky-100 rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🏦</p>
              <p className="text-xs font-medium">Tu Cuenta</p>
              <p className="text-sm font-bold text-sky-700">-{fmt(monto)}</p>
            </div>
            <div className="text-2xl text-sky-400">→</div>
            <div className="bg-sky-100 rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🏪</p>
              <p className="text-xs font-medium">Comercio</p>
              <p className="text-sm font-bold text-sky-700">+{fmt(monto)}</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-2">
            La plata sale <b>al instante</b> de tu cuenta vista.
          </p>
        </Card>
        <Card className="p-4 border-2 border-violet-300 bg-violet-50/30">
          <p className="font-semibold text-violet-700 mb-3">💳 Tarjeta de Crédito</p>
          <div className="flex items-center justify-center gap-2 py-4 flex-wrap">
            <div className="bg-violet-100 rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🏦</p>
              <p className="text-xs font-medium">Banco</p>
              <p className="text-sm font-bold text-violet-700">-{fmt(monto)}</p>
            </div>
            <div className="text-xl text-violet-400">→</div>
            <div className="bg-violet-100 rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🏪</p>
              <p className="text-xs font-medium">Comercio</p>
              <p className="text-sm font-bold text-violet-700">+{fmt(monto)}</p>
            </div>
            <div className="text-xl text-violet-400">→</div>
            <div className="bg-red-100 rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🫵</p>
              <p className="text-xs font-medium">Tú le debes</p>
              <p className="text-sm font-bold text-red-600">{fmt(monto)}</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-2">
            El banco te <b>presta</b> la plata. Tienes hasta 30 días para pagar sin interés.
          </p>
        </Card>
      </div>
    </div>
  );
}

function LineaCreditoSimulator() {
  const [lineaTotal] = useState(5_000_000);
  const [usado, setUsado] = useState(1_500_000);
  const tasaMensual = 1.5; // % mensual típico

  const interesMensual = Math.round(usado * (tasaMensual / 100));
  const interesAnual = Math.round(interesMensual * 12);
  const pctUsado = Math.round((usado / lineaTotal) * 100);

  const getColor = () => {
    if (pctUsado < 30) return '#22c55e';
    if (pctUsado < 70) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <div className="space-y-5">
      <Card className="p-3 bg-gradient-to-r from-violet-50 to-purple-50 border-violet-200">
        <p className="text-xs text-violet-600 font-medium">
          🔗 Tu línea de crédito disponible: <b>{fmt(lineaTotal)}</b>
        </p>
      </Card>

      <div className="space-y-1">
        <label className="text-xs font-medium text-muted-foreground">
          Monto usado: {fmt(usado)} ({pctUsado}%)
        </label>
        <Slider
          value={[usado]}
          onValueChange={([v]) => setUsado(v)}
          min={0}
          max={lineaTotal}
          step={100_000}
        />
        <div className="flex h-4 rounded-full overflow-hidden bg-muted">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${pctUsado}%`, backgroundColor: getColor() }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="p-3 text-center">
          <p className="text-xs text-muted-foreground">Disponible</p>
          <p className="text-lg font-bold text-emerald-600">{fmt(lineaTotal - usado)}</p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-xs text-muted-foreground">Interés mensual ({tasaMensual}%)</p>
          <p className="text-lg font-bold text-amber-600">{fmt(interesMensual)}</p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-xs text-muted-foreground">Interés anual estimado</p>
          <p className="text-lg font-bold text-red-600">{fmt(interesAnual)}</p>
        </Card>
      </div>

      {pctUsado >= 70 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-amber-50 border border-amber-200 text-amber-700 text-sm rounded-lg p-3 text-center font-medium"
        >
          ⚠️ Estás usando más del 70% de tu línea. Los intereses se acumulan rápido.
        </motion.div>
      )}
    </div>
  );
}

function ScoreCrediticioSimulator() {
  const [score, setScore] = useState(600);

  const getScoreInfo = (s: number) => {
    if (s < 580) return { label: 'Malo', color: '#ef4444', emoji: '😱', desc: 'Difícil obtener créditos. Debes mejorar tus hábitos de pago.' };
    if (s < 670) return { label: 'Regular', color: '#f59e0b', emoji: '😐', desc: 'Puedes conseguir créditos pero con tasas altas.' };
    if (s < 740) return { label: 'Bueno', color: '#22c55e', emoji: '😊', desc: 'Buenas condiciones de crédito disponibles.' };
    if (s < 800) return { label: 'Muy Bueno', color: '#10b981', emoji: '🤩', desc: 'Excelentes tasas y condiciones. ¡Sigue así!' };
    return { label: 'Excelente', color: '#059669', emoji: '🏆', desc: 'Las mejores condiciones del mercado. Eres un cliente premium.' };
  };

  const info = getScoreInfo(score);

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>300</span>
          <span>850</span>
        </div>
        <Slider
          value={[score]}
          onValueChange={([v]) => setScore(v)}
          min={300}
          max={850}
          step={1}
        />
        <div className="text-center">
          <p className="text-4xl font-black" style={{ color: info.color }}>
            {score}
          </p>
          <p className="text-sm font-semibold mt-1" style={{ color: info.color }}>
            {info.emoji} {info.label}
          </p>
        </div>
      </div>

      <div
        className="h-3 rounded-full overflow-hidden"
        style={{
          background: `linear-gradient(to right, #ef4444 0%, #f59e0b 34%, #22c55e 56%, #059669 100%)`,
        }}
      >
        <div
          className="relative h-full flex items-center justify-end"
          style={{ width: `${((score - 300) / 550) * 100}%` }}
        >
          <div
            className="absolute -right-2 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full border-2 border-white shadow-md"
            style={{ backgroundColor: info.color }}
          />
        </div>
      </div>

      <Card className="p-4" style={{ borderLeft: `4px solid ${info.color}` }}>
        <p className="text-sm font-medium mb-2">¿Qué puedes conseguir con este score?</p>
        <p className="text-sm text-muted-foreground leading-relaxed">{info.desc}</p>
      </Card>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { s: 450, label: '450' },
          { s: 600, label: '600' },
          { s: 750, label: '750' },
          { s: 850, label: '850' },
        ].map(({ s, label }) => (
          <button
            key={s}
            onClick={() => setScore(s)}
            className={`text-xs py-2 px-3 rounded-lg border transition-all ${
              score === s
                ? 'border-primary bg-primary/10 font-bold'
                : 'border-border hover:bg-muted'
            }`}
          >
            Ver {label}
          </button>
        ))}
      </div>
    </div>
  );
}

function InflacionSimulator() {
  const [inflacionPct, setInflacionPct] = useState(4);
  const [monto, setMonto] = useState(100_000);
  const [anios, setAnios] = useState(10);

  const poderActual = monto;
  const poderFuturo = Math.round(monto / Math.pow(1 + inflacionPct / 100, anios));
  const perdida = monto - poderFuturo;
  const perdidaPct = ((perdida / monto) * 100).toFixed(1);

  const data = useMemo(() => {
    const rows: { anio: number; poder: number }[] = [];
    for (let y = 0; y <= anios; y++) {
      rows.push({
        anio: y,
        poder: Math.round(monto / Math.pow(1 + inflacionPct / 100, y)),
      });
    }
    return rows;
  }, [inflacionPct, monto, anios]);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Inflación anual
          </label>
          <Slider
            value={[inflacionPct]}
            onValueChange={([v]) => setInflacionPct(v)}
            min={1}
            max={15}
            step={0.5}
          />
          <p className="text-sm font-bold text-center">{inflacionPct}%</p>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Monto
          </label>
          <Slider
            value={[monto]}
            onValueChange={([v]) => setMonto(v)}
            min={10_000}
            max={1_000_000}
            step={10_000}
          />
          <p className="text-sm font-bold text-center">{fmt(monto)}</p>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-medium text-muted-foreground">
            Años
          </label>
          <Slider
            value={[anios]}
            onValueChange={([v]) => setAnios(v)}
            min={1}
            max={30}
          />
          <p className="text-sm font-bold text-center">{anios} años</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="p-3 text-center border-2 border-sky-300 bg-sky-50/30">
          <p className="text-xs text-muted-foreground">Hoy puedes comprar</p>
          <p className="text-lg font-bold text-sky-700">{fmt(poderActual)}</p>
        </Card>
        <Card className="p-3 text-center border-2 border-red-300 bg-red-50/30">
          <p className="text-xs text-muted-foreground">En {anios} años puedes comprar</p>
          <p className="text-lg font-bold text-red-600">{fmt(poderFuturo)}</p>
        </Card>
        <Card className="p-3 text-center border-2 border-amber-300 bg-amber-50/30">
          <p className="text-xs text-muted-foreground">Perdiste poder de compra</p>
          <p className="text-lg font-bold text-amber-600">{fmt(perdida)} ({perdidaPct}%)</p>
        </Card>
      </div>

      <ResponsiveContainer width="100%" height={250}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
          <XAxis dataKey="anio" tick={{ fontSize: 11 }} label={{ value: 'Años', position: 'insideBottom', offset: -2, fontSize: 11 }} />
          <YAxis tickFormatter={(v: number) => fmtShort(v)} tick={{ fontSize: 11 }} width={55} />
          <Tooltip formatter={(v: number) => fmt(v)} labelFormatter={(l: string) => `Año ${l}`} />
          <Area type="monotone" dataKey="poder" stroke="#f97316" fill="#f97316" fillOpacity={0.15} strokeWidth={2.5} name="Poder de compra" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function InversionBasicaSimulator() {
  const [toleranciaRiesgo, setToleranciaRiesgo] = useState(50);

  const portfolios = [
    { name: 'Depósito Plazo', riesgo: 5, retorno: 3, color: '#22c55e' },
    { name: 'Fondo Mutuo Conservador', riesgo: 20, retorno: 6, color: '#3b82f6' },
    { name: 'Fondo Mutuo Moderado', riesgo: 40, retorno: 10, color: '#8b5cf6' },
    { name: 'Acciones Individuales', riesgo: 65, retorno: 16, color: '#f97316' },
    { name: 'Crypto / Startups', riesgo: 90, retorno: 30, color: '#ef4444' },
  ];

  const scatterData = portfolios.map((p) => ({
    name: p.name,
    riesgo: p.riesgo,
    retorno: p.retorno,
    color: p.color,
  }));

  const getRecommendation = () => {
    if (toleranciaRiesgo < 20) return { text: 'Depósito a plazo o cuenta de ahorro.', emoji: '🏦', color: '#22c55e' };
    if (toleranciaRiesgo < 40) return { text: 'Fondo mutuo conservador. Bajo riesgo, retorno estable.', emoji: '📊', color: '#3b82f6' };
    if (toleranciaRiesgo < 60) return { text: 'Fondo mutuo moderado. Buen balance riesgo/retorno.', emoji: '⚖️', color: '#8b5cf6' };
    if (toleranciaRiesgo < 80) return { text: 'Mix de fondos moderados + algunas acciones.', emoji: '📈', color: '#f97316' };
    return { text: 'Cartera agresiva con acciones y alternativas. ¡Alto riesgo!', emoji: '🚀', color: '#ef4444' };
  };

  const rec = getRecommendation();

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <label className="text-xs font-medium text-muted-foreground">
          ¿Cuánto riesgo estás dispuesto a tomar? ({toleranciaRiesgo}%)
        </label>
        <Slider
          value={[toleranciaRiesgo]}
          onValueChange={([v]) => setToleranciaRiesgo(v)}
          min={0}
          max={100}
          step={1}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>🛡️ Muy conservador</span>
          <span>🔥 Muy agresivo</span>
        </div>
      </div>

      <Card className="p-4" style={{ borderLeft: `4px solid ${rec.color}` }}>
        <p className="text-sm font-medium mb-1">
          {rec.emoji} Recomendación para ti
        </p>
        <p className="text-sm text-muted-foreground">{rec.text}</p>
      </Card>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart
          data={scatterData}
          margin={{ top: 20, right: 20, bottom: 20, left: 10 }}
        >
          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
          <XAxis
            type="number"
            dataKey="riesgo"
            domain={[0, 100]}
            tick={{ fontSize: 11 }}
            label={{ value: 'Riesgo →', position: 'insideBottom', offset: -5, fontSize: 11 }}
          />
          <YAxis
            type="number"
            dataKey="retorno"
            domain={[0, 35]}
            tick={{ fontSize: 11 }}
            label={{ value: 'Retorno anual % ↑', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }}
          />
          <Tooltip
            formatter={(v: number, name: string) => [`${v}%`, name === 'riesgo' ? 'Riesgo' : 'Retorno']}
            content={({ payload }) => {
              if (!payload?.length) return null;
              const d = payload[0].payload as { name: string; riesgo: number; retorno: number; color: string };
              return (
                <div className="bg-background border rounded-lg p-2 shadow-lg text-xs">
                  <p className="font-bold">{d.name}</p>
                  <p>Riesgo: {d.riesgo}%</p>
                  <p>Retorno: {d.retorno}%</p>
                </div>
              );
            }}
          />
          <Line
            type="linear"
            dataKey="retorno"
            stroke="none"
            dot={(props: Record<string, unknown>) => {
              const { cx, cy, payload } = props as { cx: number; cy: number; payload: { color: string } };
              return (
                <g key={`dot-${payload.color}`}>
                  <circle cx={cx} cy={cy} r={10} fill={payload.color} fillOpacity={0.2} />
                  <circle cx={cx} cy={cy} r={6} fill={payload.color} stroke="white" strokeWidth={2} />
                </g>
              );
            }}
            activeDot={false}
          />
        </LineChart>
      </ResponsiveContainer>

      <div className="flex flex-wrap gap-2 justify-center">
        {portfolios.map((p) => (
          <span key={p.name} className="flex items-center gap-1 text-xs">
            <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
            {p.name}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ──────────────── Simulator Router ──────────────── */

function SimulatorTab({ topicId }: { topicId: string }) {
  const simulators: Record<string, React.ReactNode> = {
    'interes-compuesto': <InteresCompuestoSimulator />,
    'presupuesto': <PresupuestoSimulator />,
    'ahorro-vs-gasto': <AhorroVsGastoSimulator />,
    'deuda-buena-mala': <DeudaBuenaMalaSimulator />,
    'tarjeta-debito-credito': <TarjetaDebitoCreditoSimulator />,
    'linea-credito': <LineaCreditoSimulator />,
    'score-crediticio': <ScoreCrediticioSimulator />,
    'inflacion': <InflacionSimulator />,
    'inversion-basica': <InversionBasicaSimulator />,
  };

  return (
    <div>
      {simulators[topicId] ?? (
        <p className="text-muted-foreground text-center py-8">
          Simulador no disponible aún para este tema.
        </p>
      )}
    </div>
  );
}

/* ──────────────── Learn Tab ──────────────── */

function LearnTab({ topicId }: { topicId: string }) {
  const text = TOPIC_EXPLANATIONS[topicId];
  const topic = TOPICS.find((t) => t.id === topicId);

  if (!text) {
    return (
      <p className="text-muted-foreground text-center py-8">
        Contenido no disponible aún.
      </p>
    );
  }

  return (
    <Card className="p-6 space-y-4">
      {topic && (
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">{topic.icon}</span>
          <h3 className="text-lg font-bold">{topic.title}</h3>
        </div>
      )}
      <div className="prose prose-sm max-w-none text-muted-foreground leading-relaxed">
        <ReactMarkdown>{text}</ReactMarkdown>
      </div>
    </Card>
  );
}

/* ──────────────── Quiz Tab ──────────────── */

function QuizTab({ topicId }: { topicId: string }) {
  const questions = TOPIC_QUIZZES[topicId];
  const { updateTopicProgress, user, updateUser, showToast } = useFiniStore();

  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [quizDone, setQuizDone] = useState(false);
  const [passed, setPassed] = useState(false);

  const q = questions?.[currentQ];

  const total = questions?.length ?? 0;
  const passingThreshold = Math.ceil(total * (2 / 3));
  const progressPct = total > 0 ? ((currentQ + 1) / total) * 100 : 0;

  const handleSelect = useCallback(
    (idx: number) => {
      if (isRevealed) return;
      setSelected(idx);
      setIsRevealed(true);
      if (idx === q?.correctIndex) {
        setCorrectCount((c) => c + 1);
      }
    },
    [isRevealed, q]
  );

  const handleNext = useCallback(() => {
    if (currentQ + 1 >= total) {
      // Quiz finished
      const finalCorrect = selected === q?.correctIndex ? correctCount : correctCount;
      const isPassed = finalCorrect >= passingThreshold;
      setPassed(isPassed);
      setQuizDone(true);

      if (isPassed) {
        updateTopicProgress(topicId, {
          status: 'completed',
          quizScore: finalCorrect,
          quizAttempts: (useFiniStore.getState().topicProgress.find((p) => p.topicId === topicId)?.quizAttempts ?? 0) + 1,
        });

        // Add 50 points
        if (user) {
          const newPoints = (user.points ?? 0) + 50;
          const newLevel = LEVEL_NAMES.reduce((lvl, name, i) => {
            // simple level calculation
            const thresholds = [0, 500, 1500, 3500, 7000];
            return newPoints >= (thresholds[i] ?? Infinity) ? i + 1 : lvl;
          }, 0);
          updateUser({ points: newPoints, levelName: LEVEL_NAMES[Math.min(newLevel, LEVEL_NAMES.length - 1)] });
        }

        showToast('🎉 ¡Tema completado! +50 puntos');

        // Unlock next topic
        const currentIndex = TOPICS.findIndex((t) => t.id === topicId);
        if (currentIndex >= 0 && currentIndex < TOPICS.length - 1) {
          const nextTopic = TOPICS[currentIndex + 1];
          const nextProgress = useFiniStore.getState().topicProgress.find((p) => p.topicId === nextTopic.id);
          if (nextProgress?.status === 'locked') {
            updateTopicProgress(nextTopic.id, { status: 'available' });
          }
        }
      }
    } else {
      setCurrentQ((c) => c + 1);
      setSelected(null);
      setIsRevealed(false);
    }
  }, [currentQ, total, correctCount, passingThreshold, selected, q, topicId, updateTopicProgress, user, updateUser, showToast]);

  const handleRetry = useCallback(() => {
    setCurrentQ(0);
    setSelected(null);
    setIsRevealed(false);
    setCorrectCount(0);
    setQuizDone(false);
    setPassed(false);
  }, []);

  if (!q && !quizDone) {
    return (
      <p className="text-muted-foreground text-center py-8">
        Quiz no disponible aún.
      </p>
    );
  }

  // Result screen
  if (quizDone) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-6 py-8"
      >
        {passed ? (
          <>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
            >
              <PartyPopper className="size-16 mx-auto text-amber-500" />
            </motion.div>
            <h2 className="text-2xl font-bold text-emerald-700">
              ¡Excelente! 🎉
            </h2>
            <p className="text-muted-foreground">
              Obtuviste <b className="text-emerald-700">{correctCount}/{total}</b> respuestas correctas.
            </p>
            <p className="text-sm text-amber-600 font-medium">
              +50 puntos ganados
            </p>

            {/* Next topic button */}
            {(() => {
              const currentIndex = TOPICS.findIndex((t) => t.id === topicId);
              const nextTopic = TOPICS[currentIndex + 1];
              if (nextTopic) {
                return (
                  <Button
                    onClick={() => {
                      useFiniStore.getState().setSelectedTopicId(nextTopic.id);
                    }}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white"
                  >
                    Siguiente tema: {nextTopic.icon} {nextTopic.title}
                    <ChevronRight className="size-4 ml-1" />
                  </Button>
                );
              }
              return (
                <Button
                  onClick={() => useFiniStore.getState().setSelectedTopicId(null)}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white"
                >
                  Volver a la Academia
                </Button>
              );
            })()}
          </>
        ) : (
          <>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
            >
              <Trophy className="size-16 mx-auto text-amber-400" />
            </motion.div>
            <h2 className="text-2xl font-bold">¡Casi lo logras!</h2>
            <p className="text-muted-foreground">
              Obtuviste <b>{correctCount}/{total}</b>. Necesitas al menos{' '}
              <b>{passingThreshold}</b> para pasar.
            </p>
            <Button onClick={handleRetry} variant="outline">
              <RotateCcw className="size-4 mr-1" /> Intentar de nuevo
            </Button>
          </>
        )}
      </motion.div>
    );
  }

  // Question screen
  return (
    <div className="space-y-6">
      {/* Progress bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Pregunta {currentQ + 1} de {total}</span>
          <span>✓ {correctCount}</span>
        </div>
        <Progress value={progressPct} className="h-2" />
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQ}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.25 }}
        >
          <Card className="p-5 mb-4">
            <p className="text-base font-semibold leading-relaxed">{q.question}</p>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {q.options.map((opt, idx) => {
              const isCorrect = idx === q.correctIndex;
              const isSelected = idx === selected;

              let cardStyle = 'border-border hover:border-primary/40 hover:bg-muted/30 cursor-pointer transition-all';
              if (isRevealed) {
                if (isCorrect) cardStyle = 'border-emerald-400 bg-emerald-50 shadow-emerald-100 shadow-sm';
                else if (isSelected && !isCorrect) cardStyle = 'border-red-400 bg-red-50 shadow-red-100 shadow-sm';
                else cardStyle = 'opacity-50';
              }

              return (
                <motion.div
                  key={idx}
                  whileHover={!isRevealed ? { scale: 1.02 } : {}}
                  whileTap={!isRevealed ? { scale: 0.98 } : {}}
                  onClick={() => handleSelect(idx)}
                >
                  <Card className={`p-4 ${cardStyle}`}>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center size-7 rounded-full bg-muted text-xs font-bold shrink-0">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="text-sm">{opt}</span>
                      {isRevealed && isCorrect && (
                        <CheckCircle2 className="size-5 text-emerald-500 ml-auto shrink-0" />
                      )}
                      {isRevealed && isSelected && !isCorrect && (
                        <XCircle className="size-5 text-red-500 ml-auto shrink-0" />
                      )}
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Next button */}
      {isRevealed && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center"
        >
          <Button onClick={handleNext}>
            {currentQ + 1 >= total ? 'Ver resultado' : 'Siguiente'}{' '}
            <ChevronRight className="size-4 ml-1" />
          </Button>
        </motion.div>
      )}
    </div>
  );
}

/* ──────────────── Topic Detail View ──────────────── */

function TopicDetailView() {
  const { selectedTopicId, setSelectedTopicId, updateTopicProgress } = useFiniStore();

  const topic = TOPICS.find((t) => t.id === selectedTopicId);
  if (!topic || !selectedTopicId) return null;

  const handleBack = () => {
    const progress = useFiniStore.getState().topicProgress.find(
      (p) => p.topicId === selectedTopicId
    );
    if (progress?.status === 'in_progress') {
      updateTopicProgress(selectedTopicId, { status: 'in_progress' });
    }
    setSelectedTopicId(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="shrink-0"
        >
          <ArrowLeft className="size-5" />
        </Button>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xl">{topic.icon}</span>
            <h2 className="text-lg font-bold truncate">{topic.title}</h2>
          </div>
          <p className="text-xs text-muted-foreground truncate">
            {topic.description}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="simulador" className="w-full">
        <TabsList className="w-full">
          <TabsTrigger value="simulador" className="flex-1">
            🧪 Simulador
          </TabsTrigger>
          <TabsTrigger value="aprende" className="flex-1">
            📖 Aprende
          </TabsTrigger>
          <TabsTrigger value="quiz" className="flex-1">
            🧠 Quiz
          </TabsTrigger>
        </TabsList>

        <TabsContent value="simulador">
          <SimulatorTab topicId={selectedTopicId} />
        </TabsContent>

        <TabsContent value="aprende">
          <LearnTab topicId={selectedTopicId} />
        </TabsContent>

        <TabsContent value="quiz">
          <QuizTab topicId={selectedTopicId} />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}

/* ──────────────── Main Export ──────────────── */

export default function Academy() {
  const selectedTopicId = useFiniStore((s) => s.selectedTopicId);

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6">
      <AnimatePresence mode="wait">
        {selectedTopicId ? (
          <TopicDetailView key="detail" />
        ) : (
          <TopicListView key="list" />
        )}
      </AnimatePresence>
    </div>
  );
}
