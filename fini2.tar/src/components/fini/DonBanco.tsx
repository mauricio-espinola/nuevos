'use client';

import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFiniStore } from '@/store/fini';

function getBorderClass(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('peligro') || lower.includes('error') || lower.includes('cuidado') || lower.includes('no puedes') || lower.includes('insuficiente') || lower.includes('denegado')) {
    return 'border-red-400 dark:border-red-500';
  }
  if (lower.includes('advertencia') || lower.includes('ojo') || lower.includes('ten cuidado') || lower.includes('limite') || lower.includes('casi')) {
    return 'border-amber-400 dark:border-amber-500';
  }
  return 'border-green-400 dark:border-green-500';
}

function getAccentClass(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('peligro') || lower.includes('error') || lower.includes('cuidado') || lower.includes('no puedes') || lower.includes('insuficiente') || lower.includes('denegado')) {
    return 'bg-red-50 dark:bg-red-950/40';
  }
  if (lower.includes('advertencia') || lower.includes('ojo') || lower.includes('ten cuidado') || lower.includes('limite') || lower.includes('casi')) {
    return 'bg-amber-50 dark:bg-amber-950/40';
  }
  return 'bg-green-50 dark:bg-green-950/40';
}

export default function DonBanco() {
  const isDonBancoVisible = useFiniStore((s) => s.isDonBancoVisible);
  const donBancoMessage = useFiniStore((s) => s.donBancoMessage);
  const hideDonBanco = useFiniStore((s) => s.hideDonBanco);

  useEffect(() => {
    if (!isDonBancoVisible) return;
    const timer = setTimeout(() => {
      hideDonBanco();
    }, 8000);
    return () => clearTimeout(timer);
  }, [isDonBancoVisible, hideDonBanco]);

  return (
    <AnimatePresence>
      {isDonBancoVisible && (
        <motion.div
          className="fixed bottom-24 left-0 right-0 z-50 flex justify-center px-4"
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        >
          <div
            className={`
              relative w-full max-w-sm rounded-2xl border-2
              bg-white/95 backdrop-blur-xl
              dark:bg-gray-900/95
              shadow-2xl
              ${getBorderClass(donBancoMessage)}
            `}
          >
            {/* Dismiss button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 size-7 text-muted-foreground hover:text-foreground"
              onClick={hideDonBanco}
              aria-label="Cerrar"
            >
              <X className="size-4" />
            </Button>

            {/* Character header */}
            <div className="flex items-center gap-3 p-4 pb-2">
              <span className="flex items-center justify-center size-10 text-2xl rounded-full bg-green-100 dark:bg-green-900/50">
                🏦
              </span>
              <div>
                <h3 className="text-sm font-bold text-foreground leading-tight">
                  Don Banco
                </h3>
                <p className="text-xs text-muted-foreground">
                  Tu consejero financiero
                </p>
              </div>
            </div>

            {/* Speech bubble */}
            <div
              className={`
                mx-4 mb-4 rounded-xl p-3
                ${getAccentClass(donBancoMessage)}
              `}
            >
              <p className="text-sm leading-relaxed text-foreground/90">
                {donBancoMessage}
              </p>
            </div>

            {/* Action button */}
            <div className="px-4 pb-4">
              <Button
                size="sm"
                className="w-full rounded-xl font-semibold"
                onClick={hideDonBanco}
              >
                Entendido
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
