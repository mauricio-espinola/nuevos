'use client';

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  GraduationCap,
  Landmark,
  Gamepad2,
  Gift,
  MessageCircle,
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFiniStore } from '@/store/fini';
import type { AppView } from '@/types/fini';

const NavigationTab = {
  dashboard: 'dashboard',
  academy: 'academy',
  banco: 'banco',
  escenarios: 'escenarios',
  beneficios: 'beneficios',
} as const;

type NavigationTabValue = (typeof NavigationTab)[keyof typeof NavigationTab];

interface TabItem {
  key: NavigationTabValue;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  view: AppView;
}

const tabs: TabItem[] = [
  { key: NavigationTab.dashboard, label: 'Dashboard', icon: LayoutDashboard, view: 'dashboard' },
  { key: NavigationTab.academy, label: 'Academia', icon: GraduationCap, view: 'academy' },
  { key: NavigationTab.banco, label: 'Banco', icon: Landmark, view: 'bank' },
  { key: NavigationTab.escenarios, label: 'Escenarios', icon: Gamepad2, view: 'scenarios' },
  { key: NavigationTab.beneficios, label: 'Beneficios', icon: Gift, view: 'benefits' },
];

function viewToTab(view: AppView): NavigationTabValue | null {
  switch (view) {
    case 'dashboard':
      return NavigationTab.dashboard;
    case 'academy':
    case 'academy-topic':
      return NavigationTab.academy;
    case 'bank':
    case 'bank-apply':
      return NavigationTab.banco;
    case 'scenarios':
    case 'scenario-active':
    case 'scenario-results':
      return NavigationTab.escenarios;
    case 'benefits':
      return NavigationTab.beneficios;
    default:
      return null;
  }
}

export default function Navigation() {
  const { currentView, navigate, goBack, user } = useFiniStore();

  const activeTab = useMemo(() => viewToTab(currentView), [currentView]);

  const showBackArrow = currentView !== 'dashboard' && currentView !== 'onboarding' && currentView !== 'chat';

  if (!user || !user.onboardingDone) {
    return null;
  }

  return (
    <>
      {/* Back Arrow */}
      <AnimatePresence>
        {showBackArrow && (
          <motion.div
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -8 }}
            transition={{ duration: 0.2 }}
            className="fixed top-0 left-0 right-0 z-50 flex items-center px-4 pt-3 pb-2 bg-background/60 backdrop-blur-md"
          >
            <Button
              variant="ghost"
              size="icon"
              onClick={goBack}
              className="h-10 w-10 rounded-full hover:bg-muted"
              aria-label="Volver"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Chat Button */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, type: 'spring', stiffness: 260, damping: 20 }}
        className="fixed bottom-24 right-5 z-50"
      >
        <Button
          size="icon"
          onClick={() => navigate('chat')}
          className="relative h-14 w-14 rounded-full bg-fini-green text-white shadow-lg hover:bg-fini-green/90"
          aria-label="Chat con FINI AI"
        >
          <MessageCircle className="h-6 w-6" />
          {/* Pulse glow ring */}
          <span className="absolute inset-0 rounded-full animate-ping bg-fini-green/30 pointer-events-none" />
          {/* Subtle outer glow */}
          <span className="absolute -inset-1 rounded-full bg-fini-green/20 blur-md -z-10 animate-pulse" />
        </Button>
      </motion.div>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-t border-border/50">
        <div className="flex items-center justify-around px-1 pt-2 pb-2 max-w-lg mx-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.key;
            const Icon = tab.icon;

            return (
              <Button
                key={tab.key}
                variant="ghost"
                onClick={() => navigate(tab.view)}
                className={`
                  relative flex flex-col items-center justify-center gap-0.5
                  h-auto w-auto px-3 py-1.5 rounded-xl
                  transition-colors duration-200
                  ${isActive
                    ? 'text-fini-green'
                    : 'text-muted-foreground hover:text-foreground'
                  }
                `}
                aria-label={tab.label}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon className="h-5 w-5 shrink-0" />
                <span className="text-[10px] leading-tight font-medium">{tab.label}</span>

                {/* Active dot indicator */}
                <AnimatePresence mode="wait">
                  {isActive && (
                    <motion.span
                      layoutId="fini-nav-dot"
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 h-1 w-1 rounded-full bg-fini-green"
                    />
                  )}
                </AnimatePresence>
              </Button>
            );
          })}
        </div>

        {/* iOS safe area padding */}
        <div className="h-[env(safe-area-inset-bottom)]" />
      </nav>
    </>
  );
}
