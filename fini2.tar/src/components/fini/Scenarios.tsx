'use client';

import { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Gamepad2,
  Zap,
  ArrowLeft,
  ThumbsUp,
  ThumbsDown,
  Clock,
  Wallet,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Trophy,
  TrendingDown,
  Brain,
  AlertTriangle,
  Target,
  BarChart3,
  ChevronRight,
} from 'lucide-react';
import { useFiniStore } from '@/store/fini';
import { SCENARIO_EVENTS, CATEGORY_COLORS, CATEGORY_ICONS } from '@/data/fini-data';
import type { ScenarioRun, ScenarioDecision, Transaction } from '@/types/fini';

// ── Helpers ──────────────────────────────────────────────────────────────────

const moneyFormatter = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});

function fmt(amount: number): string {
  return moneyFormatter.format(amount);
}

type ScenarioType = 'sin_control' | 'controlado' | 'con_ai';
type InternalView = 'scenarios' | 'budget-setup' | 'scenario-active' | 'scenario-results';

interface BudgetAllocation {
  comida: number;
  transporte: number;
  ocio: number;
  ahorro: number;
  otro: number;
}

interface EventWithMeta {
  id: string;
  description: string;
  amount: number;
  category: string;
  isRecommended: boolean;
  commerce: string | null;
  aiRecommendation?: string;
}

const TIMER_SECONDS = 15;

function getAiRecommendation(event: EventWithMeta): string {
  if (event.isRecommended) {
    const tips = [
      `Este gasto en ${event.category} es necesario. ¡Conviente realizarlo! Te quedarán ${fmt(100000 - event.amount)} si este es tu único gasto.`,
      `Buen momento para este gasto. ${event.category === 'comida' ? 'La comida es una necesidad básica.' : event.category === 'transporte' ? 'Sin transporte no puedes moverte.' : 'Es una inversión razonable.'}`,
      `Recomendado. Este gasto de ${fmt(event.amount)} es justificado y entra dentro de un presupuesto saludable.`,
    ];
    return tips[Math.floor(Math.random() * tips.length)];
  }
  const tips = [
    `⚠️ ¡Cuidado! ${fmt(event.amount)} por ${event.category} es bastante. ¿Realmente lo necesitas ahora? Guardar esa plata te daría más tranquilidad.`,
    `Te sugiero pensar dos veces. Con ese dinero podrías ahorrar o gastarlo en algo más importante después.`,
    `Este gasto de ${fmt(event.amount)} puede esperar. Prioriza lo esencial y deja estos gustos para cuando tengas más holgura.`,
    `¡Ojo! Si gastas ${fmt(event.amount)} ahora, podrías quedarte corto para cosas importantes después del mes.`,
  ];
  return tips[Math.floor(Math.random() * tips.length)];
}

const SCENARIO_META: Record<
  ScenarioType,
  { title: string; emoji: string; color: string; description: string }
> = {
  sin_control: {
    title: 'Mes sin Control',
    emoji: '🌪️',
    color: 'fini-coral',
    description: 'Gasto impulsivo',
  },
  controlado: {
    title: 'Mes Controlado',
    emoji: '📋',
    color: 'fini-teal',
    description: 'Planificación de presupuesto',
  },
  con_ai: {
    title: 'Con FINI AI',
    emoji: '🤖',
    color: 'fini-gold',
    description: 'Asistencia inteligente',
  },
};

// ── Component ────────────────────────────────────────────────────────────────

export default function Scenarios() {
  // Store
  const currentView = useFiniStore((s) => s.currentView);
  const navigate = useFiniStore((s) => s.navigate);
  const user = useFiniStore((s) => s.user);
  const bankAccount = useFiniStore((s) => s.bankAccount);
  const activeScenario = useFiniStore((s) => s.activeScenario);
  const setActiveScenario = useFiniStore((s) => s.setActiveScenario);
  const updateUser = useFiniStore((s) => s.updateUser);
  const addTransaction = useFiniStore((s) => s.addTransaction);
  const showToast = useFiniStore((s) => s.showToast);
  const showDonBanco = useFiniStore((s) => s.showDonBanco);

  // Internal state
  const [internalView, setInternalView] = useState<InternalView>('scenarios');
  const [scenarioType, setScenarioType] = useState<ScenarioType | null>(null);
  const [currentEventIndex, setCurrentEventIndex] = useState(0);
  const [balance, setBalance] = useState(100000);
  const [decisions, setDecisions] = useState<ScenarioDecision[]>([]);
  const [balanceHistory, setBalanceHistory] = useState<number[]>([100000]);
  const [timerCount, setTimerCount] = useState(TIMER_SECONDS);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [aiFollowedCount, setAiFollowedCount] = useState(0);
  const [showBudgetDialog, setShowBudgetDialog] = useState(false);
  const [budgetAllocation, setBudgetAllocation] = useState<BudgetAllocation>({
    comida: 30,
    transporte: 15,
    ocio: 25,
    ahorro: 20,
    otro: 10,
  });
  const [categorySpending, setCategorySpending] = useState<Record<string, number>>({});
  const [score, setScore] = useState(0);
  const [resultsCalculated, setResultsCalculated] = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Derived: events for current scenario
  const events: EventWithMeta[] = useMemo(() => {
    const base =
      scenarioType === 'con_ai'
        ? SCENARIO_EVENTS.sin_control
        : SCENARIO_EVENTS[scenarioType ?? 'sin_control'] ?? SCENARIO_EVENTS.sin_control;
    return base.map((e) => ({
      ...e,
      aiRecommendation: scenarioType === 'con_ai' ? getAiRecommendation(e as EventWithMeta) : undefined,
    }));
  }, [scenarioType]);

  const totalEvents = events.length;
  const currentEvent = events[currentEventIndex] ?? null;
  const progressPercent = totalEvents > 0 ? (currentEventIndex / totalEvents) * 100 : 0;

  // Budget total check
  const budgetTotal = useMemo(
    () =>
      budgetAllocation.comida +
      budgetAllocation.transporte +
      budgetAllocation.ocio +
      budgetAllocation.ahorro +
      budgetAllocation.otro,
    [budgetAllocation],
  );

  // ── Timer management for sin_control ────────────────────────────────────

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const startTimer = useCallback(() => {
    clearTimer();
    setTimerCount(TIMER_SECONDS);
    timerRef.current = setInterval(() => {
      setTimerCount((prev) => {
        if (prev <= 1) {
          clearTimer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [clearTimer]);

  // Auto-reject when timer runs out (sin_control mode)
  useEffect(() => {
    if (scenarioType === 'sin_control' && internalView === 'scenario-active' && timerCount === 0 && !isTransitioning) {
      handleDecision('reject');
    }
  }, [timerCount, handleDecision]);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => clearTimer();
  }, [clearTimer]);

  // ── Score calculation ──────────────────────────────────────────────────

  const calculateScore = useCallback(
    (finalBalance: number, allDecisions: ScenarioDecision[], aiFollowed: number) => {
      // Factor 1: Remaining money (0-40 pts)
      const moneyRatio = finalBalance / 100000;
      const moneyScore = Math.max(0, Math.min(40, Math.round(moneyRatio * 40)));

      // Factor 2: Good decisions (0-35 pts) - followed recommendations and rejected non-recommended
      const goodDecisions = allDecisions.filter(
        (d) => (d.isRecommended && d.userChoice === 'accept') || (!d.isRecommended && d.userChoice === 'reject'),
      ).length;
      const decisionScore =
        allDecisions.length > 0 ? Math.round((goodDecisions / allDecisions.length) * 35) : 0;

      // Factor 3: AI compliance bonus for con_ai mode (0-25 pts)
      const aiScore =
        scenarioType === 'con_ai'
          ? Math.min(25, Math.round((aiFollowed / Math.max(1, allDecisions.length)) * 25))
          : 0;

      // Factor 4: Budget respect for controlado mode
      const budgetScore =
        scenarioType === 'controlado'
          ? (() => {
              let respected = 0;
              const categories = Object.keys(budgetAllocation) as (keyof BudgetAllocation)[];
              for (const cat of categories) {
                const planned = (budgetAllocation[cat] / 100) * 100000;
                const spent = categorySpending[cat] ?? 0;
                if (spent <= planned) respected++;
              }
              return Math.round((respected / categories.length) * 25);
            })()
          : scenarioType === 'sin_control'
            ? 0
            : 0;

      return scenarioType === 'controlado'
        ? Math.min(100, moneyScore + decisionScore + budgetScore)
        : Math.min(100, moneyScore + decisionScore + aiScore);
    },
    [scenarioType, budgetAllocation, categorySpending],
  );

  // ── Generate AI analysis ──────────────────────────────────────────────

  const generateAnalysis = useCallback(
    (finalScore: number, allDecisions: ScenarioDecision[], finalBal: number) => {
      const acceptedExpenses = allDecisions.filter((d) => d.userChoice === 'accept');
      const rejectedExpenses = allDecisions.filter((d) => d.userChoice === 'reject');
      const totalSpent = acceptedExpenses.reduce((sum, d) => sum + d.amount, 0);

      // Find worst category
      const catTotals: Record<string, number> = {};
      for (const d of acceptedExpenses) {
        catTotals[d.category] = (catTotals[d.category] || 0) + d.amount;
      }
      const worstCat = Object.entries(catTotals).sort((a, b) => b[1] - a[1])[0];

      // Bad decisions: accepting non-recommended or rejecting recommended
      const badMoves = allDecisions.filter(
        (d) => (!d.isRecommended && d.userChoice === 'accept') || (d.isRecommended && d.userChoice === 'reject'),
      );
      const goodMoves = allDecisions.length - badMoves.length;

      if (finalScore >= 80) {
        return `¡Excelente trabajo! 🎉 Tomaste ${goodMoves} de ${allDecisions.length} decisiones correctas y mantuviste ${fmt(finalBal)} de saldo. Gastaste un total de ${fmt(totalSpent)}, lo cual es muy responsable. ${rejectedExpenses.length > 0 ? `Supiste decir que no a ${rejectedExpenses.length} gastos innecesarios, ¡eso demuestra madurez financiera!` : 'Intenta ser más selectivo con los gastos en el futuro.'} Consejo: sigue así y pronto estarás listo para metas más grandes como invertir o ahorrar para algo especial.`;
      } else if (finalScore >= 60) {
        return `¡Buen intento! 💪 Tomaste ${goodMoves} decisiones correctas de ${allDecisions.length}. Te quedaste con ${fmt(finalBal)} de tu presupuesto original. ${worstCat ? `Ojo con los gastos en ${worstCat[0]} (${fmt(worstCat[1])}), es tu categoría donde más gastas.` : ''} ${badMoves.length > 0 ? `Tuviste ${badMoves.length} decisiones que podrías mejorar. Piensa siempre: ¿realmente necesito esto ahora?` : ''} Consejo: antes de cada gasto, pregúntate si podrías esperar una semana. Si después de una semana aún lo quieres, maybe sí vale la pena.`;
      } else if (finalScore >= 40) {
        return `Necesitas mejorar tus decisiones financieras. 📉 Gastaste ${fmt(totalSpent)} y te quedaste con solo ${fmt(finalBal)}. ${worstCat ? `Tu mayor problema fue ${worstCat[0]} con ${fmt(worstCat[1])} gastados.` : ''} Tuviste ${badMoves.length} malas decisiones de ${allDecisions.length}. Esto te llevaría a quedarte sin plata antes de fin de mes si fuera real. Consejo: aprende a distinguir entre necesidades y gustos. Usa la regla 50/30/20: 50% necesidades, 30% gustos, 20% ahorro.`;
      } else {
        return `¡Alerta roja! 🚨 Casi agotaste todo tu presupuesto. Te quedaste con solo ${fmt(finalBal)} de $100.000. ${worstCat ? `El gasto descontrolado en ${worstCat[0]} fue tu caída principal.` : ''} De ${allDecisions.length} decisiones, ${badMoves.length} fueron negativas. Si este patrón continúa, en 3 meses tendrías deuda. Consejo urgente: empieza anotando cada gasto y haz un presupuesto antes de gastar. Los pequeños ahorros diarios se transforman en grandes sumas.`;
      }
    },
    [],
  );

  // ── Decision handler ──────────────────────────────────────────────────

  const handleDecision = useCallback(
    (choice: 'accept' | 'reject') => {
      if (!currentEvent || isTransitioning) return;

      setIsTransitioning(true);
      clearTimer();

      const newBalance = choice === 'accept' ? balance - currentEvent.amount : balance;

      const decision: ScenarioDecision = {
        id: `dec-${Date.now()}`,
        description: currentEvent.description,
        amount: currentEvent.amount,
        category: currentEvent.category,
        isRecommended: currentEvent.isRecommended,
        userChoice: choice,
        timestamp: new Date().toISOString(),
      };

      const newDecisions = [...decisions, decision];
      const newBalanceHistory = [...balanceHistory, newBalance];

      let newCategorySpending = { ...categorySpending };
      if (choice === 'accept') {
        newCategorySpending[currentEvent.category] =
          (newCategorySpending[currentEvent.category] || 0) + currentEvent.amount;
      }

      // Track AI compliance
      let newAiFollowed = aiFollowedCount;
      if (scenarioType === 'con_ai' && currentEvent.isRecommended && choice === 'accept') {
        newAiFollowed++;
      } else if (scenarioType === 'con_ai' && !currentEvent.isRecommended && choice === 'reject') {
        newAiFollowed++;
      }

      setDecisions(newDecisions);
      setBalanceHistory(newBalanceHistory);
      setBalance(newBalance);
      setCategorySpending(newCategorySpending);
      setAiFollowedCount(newAiFollowed);

      // Show feedback toast
      const wasGood =
        (currentEvent.isRecommended && choice === 'accept') ||
        (!currentEvent.isRecommended && choice === 'reject');
      if (wasGood) {
        showToast(choice === 'accept' ? `💰 Gasto de ${fmt(currentEvent.amount)} registrado` : '👍 ¡Buena decisión!');
      } else if (choice === 'accept' && !currentEvent.isRecommended) {
        showToast(`⚠️ Gasto no recomendado: -${fmt(currentEvent.amount)}`);
      } else {
        showToast('💡 Rechazaste un gasto recomendado');
      }

      // Animate transition then move to next event or results
      setTimeout(() => {
        if (currentEventIndex + 1 >= totalEvents) {
          // Calculate final score
          const finalScore = calculateScore(newBalance, newDecisions, newAiFollowed);
          setScore(finalScore);
          setResultsCalculated(true);

          // Award points
          if (user) {
            const pointsEarned = finalScore >= 70 ? 100 : 30;
            updateUser({ points: (user.points ?? 0) + pointsEarned });
            showToast(`🏆 ¡Ganaste ${pointsEarned} puntos FINI!`);
          }

          // Update active scenario in store
          if (activeScenario) {
            setActiveScenario({
              ...activeScenario,
              status: 'completed',
              finalBalance: newBalance,
              score: finalScore,
              decisions: newDecisions,
              completedAt: new Date().toISOString(),
            });
          }

          // Show Don Banco reaction
          if (finalScore >= 80) {
            showDonBanco('¡Increíble! Manejaste tu presupuesto como un profesional. Sigue así y llegarás lejos.');
          } else if (finalScore >= 50) {
            showDonBanco('No estuvo mal, pero sé que puedes hacerlo mejor. ¡Sigue practicando!');
          } else {
            showDonBanco('¡Ojo con los gastos! La práctica hace al maestro. Intenta de nuevo.');
          }

          setInternalView('scenario-results');
        } else {
          setCurrentEventIndex((prev) => prev + 1);
          if (scenarioType === 'sin_control') {
            setTimerCount(TIMER_SECONDS);
          }
        }
        setIsTransitioning(false);
      }, 600);
    },
    [
      currentEvent,
      isTransitioning,
      clearTimer,
      balance,
      decisions,
      balanceHistory,
      categorySpending,
      aiFollowedCount,
      scenarioType,
      currentEventIndex,
      totalEvents,
      calculateScore,
      user,
      updateUser,
      showToast,
      showDonBanco,
      activeScenario,
      setActiveScenario,
    ],
  );

  // Start timer when sin_control event appears
  useEffect(() => {
    if (scenarioType === 'sin_control' && internalView === 'scenario-active' && !isTransitioning) {
      startTimer();
    }
  }, [currentEventIndex, internalView, scenarioType, startTimer]);

  // ── Start scenario ────────────────────────────────────────────────────

  const startScenario = useCallback(
    (type: ScenarioType) => {
      setScenarioType(type);
      setCurrentEventIndex(0);
      setBalance(100000);
      setDecisions([]);
      setBalanceHistory([100000]);
      setCategorySpending({});
      setAiFollowedCount(0);
      setScore(0);
      setResultsCalculated(false);
      setIsTransitioning(false);

      if (type === 'controlado') {
        // Show budget setup dialog
        setShowBudgetDialog(true);
      } else {
        // Create scenario run in store
        const run: ScenarioRun = {
          id: `scenario-${Date.now()}`,
          scenarioType: type,
          status: 'active',
          monthlyBudget: 100000,
          initialBalance: 100000,
          transactions: [],
          startedAt: new Date().toISOString(),
        };
        setActiveScenario(run);

        // POST to API
        fetch('/api/scenarios', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scenarioType: type, monthlyBudget: 100000 }),
        }).catch(() => {});

        setInternalView('scenario-active');
      }
    },
    [setActiveScenario],
  );

  const confirmBudgetAndStart = useCallback(() => {
    if (budgetTotal !== 100) return;

    const run: ScenarioRun = {
      id: `scenario-${Date.now()}`,
      scenarioType: 'controlado',
      status: 'active',
      monthlyBudget: 100000,
      initialBalance: 100000,
      transactions: [],
      startedAt: new Date().toISOString(),
    };
    setActiveScenario(run);

    fetch('/api/scenarios', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scenarioType: 'controlado', monthlyBudget: 100000 }),
    }).catch(() => {});

    setShowBudgetDialog(false);
    setInternalView('scenario-active');
  }, [budgetTotal, setActiveScenario]);

  // ── Reset ─────────────────────────────────────────────────────────────

  const resetScenario = useCallback(() => {
    clearTimer();
    setActiveScenario(null);
    setScenarioType(null);
    setInternalView('scenarios');
    setCurrentEventIndex(0);
  }, [clearTimer, setActiveScenario]);

  // ── Results data ──────────────────────────────────────────────────────

  const resultsData = useMemo(() => {
    if (!resultsCalculated) return null;

    const finalBal = balanceHistory[balanceHistory.length - 1] ?? 0;

    // Balance evolution data
    const balanceChartData = balanceHistory.map((b, i) => ({
      name: i === 0 ? 'Inicio' : `Decisión ${i}`,
      saldo: b,
    }));

    // Category breakdown for pie chart
    const pieData = Object.entries(categorySpending)
      .filter(([, val]) => val > 0)
      .map(([category, total]) => ({
        name: `${CATEGORY_ICONS[category] ?? '📌'} ${category}`,
        value: total,
        category,
      }));

    // Category budget comparison for controlado mode
    const budgetComparisonData = scenarioType === 'controlado'
      ? (Object.keys(budgetAllocation) as (keyof BudgetAllocation)[]).map((cat) => {
          const planned = (budgetAllocation[cat] / 100) * 100000;
          const actual = categorySpending[cat] ?? 0;
          return {
            category: `${CATEGORY_ICONS[cat] ?? '📌'} ${cat}`,
            planificado: planned,
            real: actual,
            diff: planned - actual,
          };
        })
      : null;

    // 12-month projection (linear extrapolation)
    const avgSpendPerMonth = 100000 - finalBal;
    const projectionData = Array.from({ length: 12 }, (_, i) => ({
      mes: `Mes ${i + 1}`,
      saldo: Math.max(0, 100000 * (i + 1) - avgSpendPerMonth * (i + 1)),
    }));

    // Analysis text
    const analysis = generateAnalysis(score, decisions, finalBal);

    return { finalBal, balanceChartData, pieData, budgetComparisonData, projectionData, analysis };
  }, [resultsCalculated, balanceHistory, categorySpending, budgetAllocation, scenarioType, score, decisions, generateAnalysis]);

  // ── Render: Budget Setup Dialog ───────────────────────────────────────

  const renderBudgetSetup = () => (
    <Dialog open={showBudgetDialog} onOpenChange={setShowBudgetDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            📋 Planifica tu Presupuesto
          </DialogTitle>
          <DialogDescription>
            Asigna porcentajes a cada categoría. ¡El total debe ser 100%!
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {(['comida', 'transporte', 'ocio', 'ahorro', 'otro'] as const).map((cat) => (
            <div key={cat} className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium flex items-center gap-2">
                  <span>{CATEGORY_ICONS[cat]}</span>
                  <span className="capitalize">{cat}</span>
                </label>
                <span className="text-sm font-bold tabular-nums">
                  {budgetAllocation[cat]}% = {fmt((budgetAllocation[cat] / 100) * 100000)}
                </span>
              </div>
              <Slider
                value={[budgetAllocation[cat]]}
                onValueChange={([val]) =>
                  setBudgetAllocation((prev) => ({ ...prev, [cat]: val }))
                }
                min={0}
                max={100}
                step={5}
              />
            </div>
          ))}

          <div
            className={`text-center text-lg font-bold p-3 rounded-xl ${
              budgetTotal === 100
                ? 'bg-emerald-500/10 text-emerald-600'
                : 'bg-red-500/10 text-red-500'
            }`}
          >
            Total: {budgetTotal}% {budgetTotal === 100 ? '✅' : `(${budgetTotal > 100 ? 'Te pasaste' : 'Te falta'} ${Math.abs(100 - budgetTotal)}%)`}
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setShowBudgetDialog(false)}>
            Cancelar
          </Button>
          <Button
            disabled={budgetTotal !== 100}
            onClick={confirmBudgetAndStart}
            className="gap-2"
          >
            <Target className="w-4 h-4" />
            Comenzar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  // ── Render: Scenario Selection ────────────────────────────────────────

  const renderScenarioSelection = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-fini-coral/20 to-fini-coral/5 flex items-center justify-center">
          <Gamepad2 className="w-6 h-6 text-fini-coral" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Motor de Escenarios</h1>
          <p className="text-muted-foreground text-sm">
            Simula un mes de decisiones financieras reales
          </p>
        </div>
      </div>

      {/* Scenario cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Mes sin Control */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Card className="card-glow overflow-hidden h-full cursor-pointer" onClick={() => startScenario('sin_control')}>
            <div className="h-2 bg-gradient-to-r from-fini-coral to-orange-400" />
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <span className="text-4xl">🌪️</span>
                <Badge variant="secondary" className="text-xs">Impulso</Badge>
              </div>
              <CardTitle className="text-lg">Mes sin Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Recibes tu asignación y debes sobrevivir al mes. Los gastos tentadores aparecen sin aviso. ¿Puedes mantener el control?
              </p>
              <div className="flex items-center gap-2 text-sm font-medium">
                <Wallet className="w-4 h-4 text-fini-coral" />
                <span>Presupuesto mensual:</span>
                <span className="font-bold">{fmt(100000)}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                <span>{TIMER_SECONDS} segundos por decisión</span>
              </div>
              <Button className="w-full bg-fini-coral hover:bg-fini-coral/90 text-white gap-2">
                <Zap className="w-4 h-4" />
                Comenzar
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Mes Controlado */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Card className="card-glow overflow-hidden h-full cursor-pointer" onClick={() => startScenario('controlado')}>
            <div className="h-2 bg-gradient-to-r from-fini-teal to-cyan-400" />
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <span className="text-4xl">📋</span>
                <Badge variant="secondary" className="text-xs">Planificado</Badge>
              </div>
              <CardTitle className="text-lg">Mes Controlado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Planifica tu presupuesto antes de empezar. Asigna categorías y respétalas. Al final verás cómo te fue vs lo planificado.
              </p>
              <div className="flex items-center gap-2 text-sm font-medium">
                <Wallet className="w-4 h-4 text-fini-teal" />
                <span>Presupuesto mensual:</span>
                <span className="font-bold">{fmt(100000)}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Target className="w-3.5 h-3.5" />
                <span>Planifica antes de gastar</span>
              </div>
              <Button className="w-full bg-fini-teal hover:bg-fini-teal/90 text-white gap-2">
                <Target className="w-4 h-4" />
                Comenzar
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Con FINI AI */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Card className="card-glow overflow-hidden h-full cursor-pointer" onClick={() => startScenario('con_ai')}>
            <div className="h-2 bg-gradient-to-r from-fini-gold to-yellow-400" />
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <span className="text-4xl">🤖</span>
                <Badge variant="secondary" className="text-xs">IA Asistente</Badge>
              </div>
              <CardTitle className="text-lg">Con FINI AI</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                FINI AI te acompaña en cada decisión. Te dice si conviene o no gastar, te muestra el impacto en tu saldo y te da alternativas.
              </p>
              <div className="flex items-center gap-2 text-sm font-medium">
                <Wallet className="w-4 h-4 text-fini-gold" />
                <span>Presupuesto mensual:</span>
                <span className="font-bold">{fmt(100000)}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Brain className="w-3.5 h-3.5" />
                <span>Recomendaciones inteligentes</span>
              </div>
              <Button className="w-full bg-fini-gold hover:bg-fini-gold/90 text-white gap-2">
                <Brain className="w-4 h-4" />
                Comenzar
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Info card */}
      <Card className="card-glow">
        <CardContent className="flex items-center gap-4 py-4">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">¿Cómo funciona?</p>
            <p className="text-xs text-muted-foreground">
              Simula un mes de gastos reales de un adolescente chileno. Toma decisiones y al final
              obtendrás tu puntaje, análisis detallado y proyección a 12 meses. ¡Gana puntos por buen desempeño!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // ── Render: Active Scenario ───────────────────────────────────────────

  const renderActiveScenario = () => {
    if (!currentEvent || !scenarioType) return null;

    const meta = SCENARIO_META[scenarioType];
    const timerPercent = (timerCount / TIMER_SECONDS) * 100;
    const isUrgent = timerCount < 5 && scenarioType === 'sin_control';
    const projectedBalance = balance - currentEvent.amount;

    // Budget info for controlado mode
    const categoryBudget = scenarioType === 'controlado'
      ? (budgetAllocation[currentEvent.category as keyof BudgetAllocation] / 100) * 100000
      : null;
    const categorySpent = categorySpending[currentEvent.category] ?? 0;
    const overBudget = categoryBudget !== null && categorySpent + currentEvent.amount > categoryBudget;

    return (
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={resetScenario}
            className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xl">{meta.emoji}</span>
              <h2 className="text-lg font-bold">{meta.title}</h2>
            </div>
            <p className="text-xs text-muted-foreground">
              Decisión {currentEventIndex + 1} de {totalEvents}
            </p>
          </div>
          <Badge variant="outline" className="text-xs">
            <span>{meta.description}</span>
          </Badge>
        </div>

        {/* Progress bar */}
        <div className="space-y-1">
          <Progress value={progressPercent} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{currentEventIndex} completadas</span>
            <span>{totalEvents} total</span>
          </div>
        </div>

        {/* Balance display */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="card-glow py-3">
            <CardContent className="text-center">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Saldo actual</p>
              <p className={`text-xl md:text-2xl font-bold ${balance < 20000 ? 'text-red-500' : 'text-foreground'}`}>
                {fmt(balance)}
              </p>
            </CardContent>
          </Card>
          <Card className="card-glow py-3">
            <CardContent className="text-center">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Gastado</p>
              <p className="text-xl md:text-2xl font-bold text-fini-coral">
                {fmt(100000 - balance)}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Budget status for controlado mode */}
        {scenarioType === 'controlado' && (
          <div className="space-y-2">
            <p className="text-sm font-semibold flex items-center gap-2">
              <Target className="w-4 h-4 text-fini-teal" />
              Estado del presupuesto por categoría
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(Object.keys(budgetAllocation) as (keyof BudgetAllocation)[]).map((cat) => {
                const planned = (budgetAllocation[cat] / 100) * 100000;
                const actual = categorySpending[cat] ?? 0;
                const pct = planned > 0 ? Math.min(100, (actual / planned) * 100) : 0;
                const isOver = actual > planned;
                return (
                  <div
                    key={cat}
                    className={`rounded-lg p-2 text-xs border ${isOver ? 'border-red-300 bg-red-50 dark:bg-red-950/20' : 'border-border bg-muted/30'}`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1">
                        {CATEGORY_ICONS[cat]} <span className="capitalize font-medium">{cat}</span>
                      </span>
                      {isOver && <AlertTriangle className="w-3 h-3 text-red-500" />}
                    </div>
                    <Progress value={pct} className={`h-1.5 ${isOver ? '[&>div]:bg-red-500' : ''}`} />
                    <p className="mt-1 text-muted-foreground">
                      {fmt(actual)} / {fmt(planned)}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* AI Recommendation for con_ai mode */}
        {scenarioType === 'con_ai' && currentEvent.aiRecommendation && (
          <AnimatePresence mode="wait">
            <motion.div
              key={currentEvent.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-fini-gold/30 bg-fini-gold/5">
                <CardContent className="py-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-fini-gold/20 flex items-center justify-center">
                      <Brain className="w-4 h-4 text-fini-gold" />
                    </div>
                    <span className="font-semibold text-sm">FINI AI dice:</span>
                  </div>
                  <p className="text-sm leading-relaxed">{currentEvent.aiRecommendation}</p>
                  <div className="flex items-center gap-3 text-xs">
                    <span className={`flex items-center gap-1 ${currentEvent.isRecommended ? 'text-emerald-600' : 'text-red-500'}`}>
                      {currentEvent.isRecommended ? <ThumbsUp className="w-3.5 h-3.5" /> : <ThumbsDown className="w-3.5 h-3.5" />}
                      {currentEvent.isRecommended ? 'Recomendado' : 'No recomendado'}
                    </span>
                    <span className="text-muted-foreground">
                      Saldo después: {fmt(projectedBalance)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>
        )}

        {/* Timer bar for sin_control */}
        {scenarioType === 'sin_control' && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Tiempo restante
              </span>
              <span className={`font-bold tabular-nums ${isUrgent ? 'text-red-500' : ''}`}>
                {timerCount}s
              </span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full ${isUrgent ? 'bg-red-500' : 'bg-fini-coral'}`}
                initial={{ width: '100%' }}
                animate={{ width: `${timerPercent}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        )}

        {/* Event card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentEvent.id}
            initial={{ opacity: 0, x: 40, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -40, scale: 0.95 }}
            transition={{ duration: 0.4, type: 'spring', stiffness: 300, damping: 25 }}
          >
            <Card className={`overflow-hidden border-2 ${isUrgent ? 'border-red-400 shadow-red-100' : 'border-transparent'}`}>
              {isUrgent && (
                <motion.div
                  className="h-1 bg-red-500"
                  animate={{ opacity: [1, 0.3, 1] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                />
              )}
              <CardContent className="p-5 space-y-4">
                <div className="flex items-start gap-3">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0"
                    style={{ backgroundColor: `${CATEGORY_COLORS[currentEvent.category]}20` }}
                  >
                    {CATEGORY_ICONS[currentEvent.category]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-base leading-snug">{currentEvent.description}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-sm">
                      <span className="font-bold text-fini-coral">{fmt(currentEvent.amount)}</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="capitalize text-muted-foreground">{currentEvent.category}</span>
                      {currentEvent.commerce && (
                        <>
                          <span className="text-muted-foreground">•</span>
                          <span className="text-muted-foreground">{currentEvent.commerce}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Budget warning for controlado */}
                {scenarioType === 'controlado' && categoryBudget !== null && (
                  <div
                    className={`rounded-lg p-3 text-sm flex items-center gap-2 ${overBudget ? 'bg-red-50 dark:bg-red-950/20 text-red-600' : 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600'}`}
                  >
                    {overBudget ? (
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                    )}
                    <span>
                      {overBudget
                        ? `¡Excede el presupuesto de ${currentEvent.category}! (${fmt(categorySpent)} + {fmt(currentEvent.amount)} > {fmt(categoryBudget)})`
                        : `Dentro del presupuesto de ${currentEvent.category} (${fmt(categorySpent)}/{fmt(categoryBudget)})`}
                    </span>
                  </div>
                )}

                {/* Projected balance */}
                <div className="text-sm text-muted-foreground text-center py-1">
                  {balance < currentEvent.amount ? (
                    <span className="text-red-500 font-medium">⚠️ ¡No tienes suficiente saldo!</span>
                  ) : (
                    <span>
                      Saldo después: <span className="font-semibold text-foreground">{fmt(projectedBalance)}</span>
                    </span>
                  )}
                </div>

                {/* Action buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full h-12 text-sm font-semibold gap-2"
                      onClick={() => handleDecision('reject')}
                      disabled={isTransitioning}
                    >
                      <XCircle className="w-4 h-4 text-muted-foreground" />
                      No comprar
                    </Button>
                  </motion.div>
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button
                      size="lg"
                      className="w-full h-12 text-sm font-semibold gap-2"
                      onClick={() => handleDecision('accept')}
                      disabled={isTransitioning || balance < currentEvent.amount}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Comprar
                    </Button>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* AI follow buttons for con_ai */}
        {scenarioType === 'con_ai' && (
          <div className="grid grid-cols-2 gap-3">
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                size="lg"
                variant="outline"
                className="w-full h-11 text-sm font-semibold gap-2"
                onClick={() => handleDecision(currentEvent.isRecommended ? 'accept' : 'reject')}
                disabled={isTransitioning}
              >
                <ThumbsUp className="w-4 h-4 text-emerald-500" />
                Seguir recomendación
              </Button>
            </motion.div>
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                size="lg"
                variant="outline"
                className="w-full h-11 text-sm font-semibold gap-2"
                onClick={() => handleDecision(currentEvent.isRecommended ? 'reject' : 'accept')}
                disabled={isTransitioning}
              >
                <ThumbsDown className="w-4 h-4 text-red-400" />
                Ignorar
              </Button>
            </motion.div>
          </div>
        )}

        {/* Decision history mini list */}
        {decisions.length > 0 && (
          <Card className="card-glow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Historial de decisiones
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-40 overflow-y-auto fini-scroll">
              {decisions.map((d, i) => {
                const wasGood =
                  (d.isRecommended && d.userChoice === 'accept') ||
                  (!d.isRecommended && d.userChoice === 'reject');
                return (
                  <div key={d.id} className="flex items-center gap-2 py-1.5 text-sm">
                    <span className="w-5 text-center text-xs text-muted-foreground">{i + 1}</span>
                    {wasGood ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                    )}
                    <span className="flex-1 truncate">{d.description}</span>
                    <span className="text-xs text-muted-foreground shrink-0">
                      {d.userChoice === 'accept' ? `-${fmt(d.amount)}` : '$0'}
                    </span>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  // ── Render: Scenario Results ──────────────────────────────────────────

  const renderResults = () => {
    if (!resultsData) return null;

    const { finalBal, balanceChartData, pieData, budgetComparisonData, projectionData, analysis } = resultsData;
    const scoreColor = score >= 80 ? 'text-emerald-600' : score >= 50 ? 'text-fini-gold' : 'text-red-500';
    const scoreEmoji = score >= 80 ? '🏆' : score >= 50 ? '👍' : '💪';

    return (
      <div className="space-y-6">
        {/* Header with score */}
        <div className="text-center space-y-3">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, delay: 0.1 }}
          >
            <span className="text-6xl">{scoreEmoji}</span>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-2xl md:text-3xl font-bold">Resultados del Escenario</h1>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-center gap-3"
          >
            <Badge className={`text-2xl px-5 py-2 ${scoreColor} border-2`} variant="outline">
              {score}/100
            </Badge>
            <span className="text-muted-foreground text-sm">
              {scenarioType && SCENARIO_META[scenarioType].emoji} {scenarioType && SCENARIO_META[scenarioType].title}
            </span>
          </motion.div>
        </div>

        {/* Key stats */}
        <div className="grid grid-cols-3 gap-3">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Card className="card-glow py-3">
              <CardContent className="text-center">
                <p className="text-xs text-muted-foreground">Saldo final</p>
                <p className={`text-lg font-bold ${finalBal < 30000 ? 'text-red-500' : 'text-emerald-600'}`}>
                  {fmt(finalBal)}
                </p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Card className="card-glow py-3">
              <CardContent className="text-center">
                <p className="text-xs text-muted-foreground">Total gastado</p>
                <p className="text-lg font-bold text-fini-coral">{fmt(100000 - finalBal)}</p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
            <Card className="card-glow py-3">
              <CardContent className="text-center">
                <p className="text-xs text-muted-foreground">Buenas decisiones</p>
                <p className="text-lg font-bold">
                  {decisions.filter(
                    (d) =>
                      (d.isRecommended && d.userChoice === 'accept') ||
                      (!d.isRecommended && d.userChoice === 'reject'),
                  ).length}/{decisions.length}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Balance Evolution Chart */}
        {balanceChartData.length > 1 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
            <Card className="card-glow">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-fini-teal" />
                  Evolución del saldo
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[220px] md:h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={balanceChartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(val: number) => `$${(val / 1000).toFixed(0)}k`}
                      width={50}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid var(--color-border)',
                        fontSize: '12px',
                      }}
                      formatter={(value: number) => [fmt(value), 'Saldo']}
                      labelStyle={{ fontWeight: 600, marginBottom: 4 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="saldo"
                      stroke="var(--color-chart-1)"
                      strokeWidth={2.5}
                      dot={{ r: 4, fill: 'var(--color-chart-1)', strokeWidth: 0 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Category Breakdown + Budget Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Pie Chart */}
          {pieData.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>
              <Card className="card-glow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-fini-coral" />
                    Gastos por categoría
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={75}
                          paddingAngle={3}
                          dataKey="value"
                          nameKey="name"
                        >
                          {pieData.map((entry) => (
                            <Cell
                              key={entry.category}
                              fill={CATEGORY_COLORS[entry.category] ?? '#94a3b8'}
                              strokeWidth={0}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value: number) => fmt(value)}
                          contentStyle={{
                            borderRadius: '10px',
                            border: '1px solid var(--color-border)',
                            fontSize: '12px',
                          }}
                        />
                        <Legend
                          formatter={(value: string) => <span className="text-xs">{value}</span>}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Budget comparison for controlado mode */}
          {budgetComparisonData && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.85 }}>
              <Card className="card-glow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <Target className="w-4 h-4 text-fini-teal" />
                    Planificado vs Real
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={budgetComparisonData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                      <XAxis dataKey="category" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis
                        tick={{ fontSize: 10 }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(val: number) => `$${(val / 1000).toFixed(0)}k`}
                        width={45}
                      />
                      <Tooltip
                        contentStyle={{
                          borderRadius: '10px',
                          border: '1px solid var(--color-border)',
                          fontSize: '12px',
                        }}
                        formatter={(value: number) => fmt(value)}
                      />
                      <Bar dataKey="planificado" fill="var(--color-chart-5)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="real" fill="var(--color-chart-3)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>

        {/* 12-Month Projection */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}>
          <Card className="card-glow">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-fini-gold" />
                Proyección a 12 meses
              </CardTitle>
              <p className="text-xs text-muted-foreground">
                ¿Qué pasaría si mantienes este patrón de gasto durante un año?
              </p>
            </CardHeader>
            <CardContent className="h-[220px] md:h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={projectionData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                  <XAxis
                    dataKey="mes"
                    tick={{ fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    interval={1}
                  />
                  <YAxis
                    tick={{ fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(val: number) => `$${(val / 1000).toFixed(0)}k`}
                    width={50}
                  />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '10px',
                      border: '1px solid var(--color-border)',
                      fontSize: '12px',
                    }}
                    formatter={(value: number) => [fmt(value), 'Saldo acumulado']}
                    labelStyle={{ fontWeight: 600, marginBottom: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="saldo"
                    stroke="var(--color-chart-2)"
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Decision Review */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.95 }}>
          <Card className="card-glow">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Revisión de decisiones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-72 overflow-y-auto fini-scroll">
                {decisions.map((d, i) => {
                  const wasGood =
                    (d.isRecommended && d.userChoice === 'accept') ||
                    (!d.isRecommended && d.userChoice === 'reject');
                  return (
                    <motion.div
                      key={d.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1 + i * 0.05 }}
                      className={`flex items-center gap-3 p-3 rounded-lg border ${wasGood ? 'border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/10' : 'border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-950/10'}`}
                    >
                      <div className="text-lg shrink-0">{CATEGORY_ICONS[d.category]}</div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{d.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {d.userChoice === 'accept'
                            ? `Aceptaste: -${fmt(d.amount)}`
                            : `Rechazaste: ahorro ${fmt(d.amount)}`}
                        </p>
                      </div>
                      {wasGood ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* AI Analysis */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.1 }}>
          <Card className="card-glow border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Brain className="w-4 h-4 text-primary" />
                Análisis de FINI AI
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed text-muted-foreground">{analysis}</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Action buttons */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="flex gap-3"
        >
          <Button
            variant="outline"
            className="flex-1 gap-2"
            onClick={resetScenario}
          >
            <RotateCcw className="w-4 h-4" />
            Repetir Escenario
          </Button>
          <Button
            className="flex-1 gap-2"
            onClick={() => navigate('dashboard')}
          >
            <ChevronRight className="w-4 h-4" />
            Volver al inicio
          </Button>
        </motion.div>
      </div>
    );
  };

  // ── Main render ───────────────────────────────────────────────────────

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-24">
      {renderBudgetSetup()}
      {internalView === 'scenarios' && renderScenarioSelection()}
      {internalView === 'scenario-active' && renderActiveScenario()}
      {internalView === 'scenario-results' && renderResults()}
    </div>
  );
}
