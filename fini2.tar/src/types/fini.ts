// Types for the FINI application

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  age: number;
  rut: string;
  avatarSeed: string;
  points: number;
  level: number;
  levelName: string;
  streak: number;
  lastLoginAt: string;
  onboardingDone: boolean;
}

export interface BankAccount {
  id: string;
  accountNumber: string;
  accountType: string;
  balance: number;
  monthlyBudget: number;
  cardNumber: string;
  cardExpiry: string;
  cardCvv: string;
  isActive: boolean;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  commerce?: string;
  balanceAfter: number;
  createdAt: string;
}

export interface TopicProgress {
  topicId: string;
  status: 'locked' | 'available' | 'in_progress' | 'completed';
  quizScore?: number;
  quizAttempts: number;
}

export interface ScenarioRun {
  id: string;
  scenarioType: 'sin_control' | 'controlado' | 'con_ai';
  status: 'active' | 'completed';
  monthlyBudget: number;
  initialBalance: number;
  finalBalance?: number;
  score?: number;
  decisions?: ScenarioDecision[];
  transactions: Transaction[];
  startedAt: string;
  completedAt?: string;
}

export interface ScenarioDecision {
  id: string;
  description: string;
  amount: number;
  category: string;
  isRecommended: boolean;
  userChoice: 'accept' | 'reject';
  timestamp: string;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: string;
  points: number;
  earned?: boolean;
  earnedAt?: string;
}

export interface Reward {
  id: string;
  name: string;
  description: string;
  image?: string;
  pointCost: number;
  quantity: number;
  available: boolean;
  sponsorName?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

export interface Topic {
  id: string;
  title: string;
  icon: string;
  description: string;
  order: number;
}

export type AppView = 
  | 'onboarding'
  | 'dashboard'
  | 'academy'
  | 'academy-topic'
  | 'bank'
  | 'bank-apply'
  | 'scenarios'
  | 'scenario-active'
  | 'scenario-results'
  | 'benefits'
  | 'chat';

export const LEVEL_NAMES = [
  'Aprendiz',
  'Ahorrante', 
  'Inversionista',
  'Analista',
  'Gurú Financiero'
] as const;

export const LEVEL_THRESHOLDS = [0, 500, 1500, 3500, 7000] as const;
