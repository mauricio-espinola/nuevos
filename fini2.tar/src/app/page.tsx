'use client';

import Onboarding from '@/components/fini/Onboarding';
import Navigation from '@/components/fini/Navigation';
import Dashboard from '@/components/fini/Dashboard';
import Academy from '@/components/fini/Academy';
import Bank from '@/components/fini/Bank';
import Scenarios from '@/components/fini/Scenarios';
import Benefits from '@/components/fini/Benefits';
import Chat from '@/components/fini/Chat';
import DonBanco from '@/components/fini/DonBanco';
import FiniToast from '@/components/fini/FiniToast';
import { useFiniStore } from '@/store/fini';
import { AnimatePresence, motion } from 'framer-motion';

const pageVariants = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -12 },
};

function AppContent() {
  const currentView = useFiniStore((s) => s.currentView);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentView}
        variants={pageVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        transition={{ duration: 0.25, ease: 'easeInOut' }}
        className="min-h-screen"
      >
        {currentView === 'onboarding' && <Onboarding />}
        {(currentView === 'dashboard' ||
          currentView === 'academy' ||
          currentView === 'academy-topic' ||
          currentView === 'bank' ||
          currentView === 'bank-apply' ||
          currentView === 'scenarios' ||
          currentView === 'scenario-active' ||
          currentView === 'scenario-results' ||
          currentView === 'benefits') && (
          <>
            <main className="pb-24">
              {currentView === 'dashboard' && <Dashboard />}
              {(currentView === 'academy' || currentView === 'academy-topic') && <Academy />}
              {(currentView === 'bank' || currentView === 'bank-apply') && <Bank />}
              {(currentView === 'scenarios' || currentView === 'scenario-active' || currentView === 'scenario-results') && <Scenarios />}
              {currentView === 'benefits' && <Benefits />}
            </main>
            <Navigation />
          </>
        )}
        {currentView === 'chat' && <Chat />}
      </motion.div>
    </AnimatePresence>
  );
}

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <AppContent />
      <DonBanco />
      <FiniToast />
    </div>
  );
}
