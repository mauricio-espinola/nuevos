import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ACHIEVEMENTS_DATA, REWARDS_DATA } from '@/data/fini-data';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'userId requerido' }, { status: 400 });
    }

    // Get user's earned achievements
    const earnedAchievements = await db.userAchievement.findMany({
      where: { userId },
      include: { achievement: true },
    });

    const earnedIds = new Set(earnedAchievements.map((e: { achievementId: string }) => e.achievementId));

    const achievements = ACHIEVEMENTS_DATA.map((a) => ({
      ...a,
      earned: earnedIds.has(a.id),
      earnedAt: earnedAchievements.find((e: { achievementId: string }) => e.achievementId === a.id)?.earnedAt,
    }));

    // Get rewards
    const rewards = REWARDS_DATA;

    return NextResponse.json({ achievements, rewards });
  } catch (error) {
    console.error('Error fetching benefits:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, rewardId } = body;

    if (!userId || !rewardId) {
      return NextResponse.json({ error: 'Faltan campos requeridos' }, { status: 400 });
    }

    const user = await db.userProfile.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const reward = REWARDS_DATA.find((r) => r.id === rewardId);
    if (!reward || !reward.available) {
      return NextResponse.json({ error: 'Premio no disponible' }, { status: 404 });
    }

    if (user.points < reward.pointCost) {
      return NextResponse.json({ error: 'Puntos insuficientes' }, { status: 400 });
    }

    // Create redemption
    await db.redemption.create({
      data: {
        userId,
        rewardId,
        pointsSpent: reward.pointCost,
        status: 'completed',
      },
    });

    // Deduct points
    const updatedUser = await db.userProfile.update({
      where: { id: userId },
      data: { points: { decrement: reward.pointCost } },
    });

    return NextResponse.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error('Error processing redemption:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
