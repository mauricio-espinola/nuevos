import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, type, category, description, amount, commerce, scenarioRunId } = body;

    if (!userId || !type || !category || !description || !amount) {
      return NextResponse.json({ error: 'Faltan campos requeridos' }, { status: 400 });
    }

    const account = await db.bankAccount.findUnique({ where: { userId } });
    if (!account) {
      return NextResponse.json({ error: 'Cuenta bancaria no encontrada' }, { status: 404 });
    }

    const balanceAfter = type === 'expense' 
      ? account.balance - amount 
      : account.balance + amount;

    if (type === 'expense' && balanceAfter < 0) {
      return NextResponse.json({ error: 'Saldo insuficiente' }, { status: 400 });
    }

    // Create transaction
    const transaction = await db.transaction.create({
      data: {
        accountId: account.id,
        userId,
        type,
        category,
        description,
        amount,
        commerce: commerce || null,
        balanceAfter,
        scenarioRunId: scenarioRunId || null,
      },
    });

    // Update account balance
    await db.bankAccount.update({
      where: { id: account.id },
      data: { balance: balanceAfter },
    });

    // Add points for spending decisions (small rewards)
    if (type === 'expense' && amount < 10000) {
      await db.userProfile.update({
        where: { id: userId },
        data: { points: { increment: 5 } },
      });
    }

    return NextResponse.json(transaction);
  } catch (error) {
    console.error('Error creating transaction:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const limit = parseInt(searchParams.get('limit') || '50');

    if (!userId) {
      return NextResponse.json({ error: 'userId requerido' }, { status: 400 });
    }

    const transactions = await db.transaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return NextResponse.json(transactions);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
