import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, scenarioType, monthlyBudget } = body;

    if (!userId || !scenarioType) {
      return NextResponse.json({ error: 'Faltan campos requeridos' }, { status: 400 });
    }

    const scenario = await db.scenarioRun.create({
      data: {
        userId,
        scenarioType,
        status: 'active',
        monthlyBudget: monthlyBudget || 100000,
        initialBalance: monthlyBudget || 100000,
      },
    });

    return NextResponse.json(scenario);
  } catch (error) {
    console.error('Error creating scenario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, finalBalance, score, decisions, aiReport, status } = body;

    const scenario = await db.scenarioRun.update({
      where: { id },
      data: {
        finalBalance,
        score,
        decisions: decisions ? JSON.stringify(decisions) : undefined,
        aiReport,
        status,
        completedAt: status === 'completed' ? new Date() : undefined,
      },
    });

    // Award points based on score
    if (score && status === 'completed') {
      const points = score >= 70 ? 100 : 30;
      await db.userProfile.update({
        where: { id: scenario.userId },
        data: { points: { increment: points } },
      });
    }

    return NextResponse.json(scenario);
  } catch (error) {
    console.error('Error updating scenario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
