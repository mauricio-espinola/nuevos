import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, message, history, context } = body;

    if (!userId || !message) {
      return NextResponse.json({ error: 'Faltan campos requeridos' }, { status: 400 });
    }

    // Use the LLM SDK from z-ai-web-dev-sdk
    const { createLLMChat } = await import('z-ai-web-dev-sdk');

    const systemPrompt = `Eres FINI AI, un asesor financiero amigable y cercano para adolescentes chilenos de 13 a 18 años. 

TU PERSONALIDAD:
- Hablas en chileno coloquial juvenil (usas "poh", "cachai", "bakán", "wea" moderadamente)
- Eres empático, paciente y nunca juzgas
- Usas ejemplos de la vida real chilena (transantiago, jumbo, bip, etc.)
- Explicas conceptos financieros de forma simple y con analogías
- Celebras las buenas decisiones del joven
- Eres honesto sobre los riesgos pero no alarmista

CONTEXTO ACTUAL DEL USUARIO:
- Saldo en cuenta: $${context?.balance?.toLocaleString('es-CL') || '0'} CLP
- Nivel: ${context?.level || 1} (${context?.levelName || 'Aprendiz'})
- Puntos FINI: ${context?.points || 0}
- Racha: ${context?.streak || 0} días

REGLAS:
- Nunca des consejos financieros que pongan en riesgo al adolescente
- Siempre explica el "por qué" detrás de cada concepto
- Usa montos en pesos chilenos (CLP)
- Menciona la UF y conceptos chilenos cuando sea relevante
- Responde en máximo 3 párrafos cortos
- Si te preguntan por temas fuera de finanzas, redirige amablemente`;

    const chatMessages = [
      { role: 'system' as const, content: systemPrompt },
      ...(history || []).map((m: { role: string; content: string }) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
      { role: 'user' as const, content: message },
    ];

    const response = await createLLMChat({
      messages: chatMessages,
      temperature: 0.8,
      maxTokens: 500,
    });

    const reply = response?.choices?.[0]?.message?.content || 
      '¡Ups! Tuve un problemilla technical. Intenta de nuevo en un ratito, ¿sí? 💚';

    return NextResponse.json({ reply });
  } catch (error) {
    console.error('Error in chat:', error);
    
    // Fallback responses if SDK fails
    const fallbacks = [
      '¡Buena pregunta! Mira, eso tiene mucho que ver con cómo manejamos nuestra plata día a día. La clave es siempre saber cuánto entra y cuánto sale. ¿Te gustaría que profundice en algo específico?',
      'Oye, eso es súper importante cachar. Te lo explico así de simple: es como cuando ahorras para un videojuego. Si no planificas, la plata se te va como agua. ¿Quieres que te cuente cómo hacer un presupuesto básico?',
      '¡Interesante! Para entender eso mejor, te recomiendo pasar por la Academia FINI. Allí hay simuladores interactivos donde puedes ver con tus propios ojos cómo funciona. ¿Te animas a probar uno?',
    ];

    return NextResponse.json({ 
      reply: fallbacks[Math.floor(Math.random() * fallbacks.length)]
    });
  }
}
