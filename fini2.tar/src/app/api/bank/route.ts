import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

function generateCardNumber() {
  const segments = Array.from({ length: 4 }, () => 
    Math.floor(Math.random() * 9000 + 1000).toString()
  );
  return segments.join(' ');
}

function generateCVV() {
  return Math.floor(Math.random() * 900 + 100).toString();
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json({ error: 'userId requerido' }, { status: 400 });
    }

    const existing = await db.bankAccount.findUnique({ where: { userId } });
    if (existing) {
      return NextResponse.json(existing);
    }

    const account = await db.bankAccount.create({
      data: {
        userId,
        accountNumber: `00${Math.floor(Math.random() * 90000000 + 10000000)}`,
        accountType: 'cuenta_vista',
        balance: 100000,
        monthlyBudget: 100000,
        cardNumber: generateCardNumber(),
        cardExpiry: `${String(Math.floor(Math.random() * 12 + 1)).padStart(2, '0')}/${String(new Date().getFullYear() + 5).slice(-2)}`,
        cardCvv: generateCVV(),
        isActive: true,
      },
    });

    // Create initial deposit transaction
    await db.transaction.create({
      data: {
        accountId: account.id,
        userId,
        type: 'income',
        category: 'otro',
        description: 'Depósito inicial de bienvenida',
        amount: 100000,
        balanceAfter: 100000,
      },
    });

    return NextResponse.json(account);
  } catch (error) {
    console.error('Error creating bank account:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'userId requerido' }, { status: 400 });
    }

    const account = await db.bankAccount.findUnique({ where: { userId } });
    if (!account) {
      return NextResponse.json({ error: 'Cuenta no encontrada' }, { status: 404 });
    }

    return NextResponse.json(account);
  } catch (error) {
    console.error('Error fetching bank account:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
