// MIDI Note definitions for piano
export interface MidiNote {
  note: string;
  midi: number;
  frequency: number;
  isBlack: boolean;
}

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const BLACK_KEYS = [1, 3, 6, 8, 10]; // C#, D#, F#, G#, A#

function midiToFrequency(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

export function generateNotes(startOctave: number = 2, endOctave: number = 7): MidiNote[] {
  const notes: MidiNote[] = [];
  for (let octave = startOctave; octave <= endOctave; octave++) {
    for (let i = 0; i < 12; i++) {
      const midi = (octave + 1) * 12 + i;
      notes.push({
        note: `${NOTE_NAMES[i]}${octave}`,
        midi,
        frequency: midiToFrequency(midi),
        isBlack: BLACK_KEYS.includes(i),
      });
    }
  }
  return notes;
}

// Default piano range C2 to C7
export const PIANO_NOTES = generateNotes(2, 7);

// Note name from MIDI number
export function midiToNoteName(midi: number): string {
  const octave = Math.floor(midi / 12) - 1;
  const noteIndex = midi % 12;
  return `${NOTE_NAMES[noteIndex]}${octave}`;
}

// Frequency from note name
export function noteToFrequency(note: string): number {
  const match = note.match(/^([A-G]#?)(\d+)$/);
  if (!match) return 440;
  const noteName = match[1];
  const octave = parseInt(match[2]);
  const noteIndex = NOTE_NAMES.indexOf(noteName);
  const midi = (octave + 1) * 12 + noteIndex;
  return midiToFrequency(midi);
}
