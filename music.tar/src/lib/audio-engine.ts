/**
 * Professional Audio Engine built on Tone.js
 * Manages synths, audio tracks, transport, and effects
 */

import { ToneAudioBuffer } from 'tone';

// Synth preset definitions
export interface SynthPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  icon: string;
}

export const SYNTH_PRESETS: SynthPreset[] = [
  {
    id: 'grand-piano',
    name: 'Grand Piano',
    category: 'Piano',
    description: 'Classic grand piano with rich harmonics',
    icon: '🎹',
  },
  {
    id: 'electric-piano',
    name: 'Electric Piano',
    category: 'Piano',
    description: 'Warm Rhodes-style electric piano',
    icon: '🎹',
  },
  {
    id: 'synth-pad',
    name: 'Ambient Pad',
    category: 'Synth',
    description: 'Lush ambient synthesizer pad',
    icon: '🎛️',
  },
  {
    id: 'synth-lead',
    name: 'Synth Lead',
    category: 'Synth',
    description: 'Bright lead synthesizer',
    icon: '🎛️',
  },
  {
    id: 'bass-synth',
    name: 'Bass Synth',
    category: 'Synth',
    description: 'Deep sub-bass synthesizer',
    icon: '🎸',
  },
  {
    id: 'strings',
    name: 'String Ensemble',
    category: 'Orchestral',
    description: 'Rich string ensemble sound',
    icon: '🎻',
  },
  {
    id: 'organ',
    name: 'Church Organ',
    category: 'Organ',
    description: 'Classic tonewheel organ',
    icon: '⛪',
  },
  {
    id: 'marimba',
    name: 'Marimba',
    category: 'Percussion',
    description: 'Warm wooden percussion',
    icon: '🪵',
  },
  {
    id: 'pluck',
    name: 'Pluck',
    category: 'Synth',
    description: 'Plucked string synthesizer',
    icon: '🎵',
  },
  {
    id: 'mono-synth',
    name: 'Mono Synth',
    category: 'Synth',
    description: 'Fat monophonic synthesizer',
    icon: '🎛️',
  },
  {
    id: 'fm-synth',
    name: 'FM Synth',
    category: 'Synth',
    description: 'Yamaha DX-style FM synthesis',
    icon: '📻',
  },
  {
    id: 'am-synth',
    name: 'AM Synth',
    category: 'Synth',
    description: 'Amplitude modulation synthesizer',
    icon: '📻',
  },
];

export interface AudioTrack {
  id: string;
  name: string;
  type: 'audio' | 'synth';
  buffer: AudioBuffer | null;
  file?: File;
  volume: number;
  pan: number;
  muted: boolean;
  solo: boolean;
  color: string;
  waveformData: number[];
  duration: number;
  loops: LoopRegion[];
}

export interface LoopRegion {
  id: string;
  start: number;
  end: number;
  enabled: boolean;
  color: string;
}

export interface RecordedNote {
  note: string;
  time: number;
  duration: number;
  velocity: number;
}

// Synth configuration for each preset
export const SYNTH_CONFIGS: Record<string, any> = {
  'grand-piano': {
    oscillator: { type: 'triangle' },
    envelope: { attack: 0.005, decay: 1.5, sustain: 0.2, release: 1.5 },
  },
  'electric-piano': {
    oscillator: { type: 'sine' },
    envelope: { attack: 0.01, decay: 0.8, sustain: 0.3, release: 1.0 },
  },
  'synth-pad': {
    oscillator: { type: 'sawtooth' },
    envelope: { attack: 0.5, decay: 0.5, sustain: 0.8, release: 2.0 },
  },
  'synth-lead': {
    oscillator: { type: 'square' },
    envelope: { attack: 0.01, decay: 0.2, sustain: 0.5, release: 0.3 },
  },
  'bass-synth': {
    oscillator: { type: 'sine' },
    envelope: { attack: 0.01, decay: 0.3, sustain: 0.6, release: 0.2 },
  },
  'strings': {
    oscillator: { type: 'sawtooth' },
    envelope: { attack: 0.8, decay: 0.3, sustain: 0.9, release: 2.0 },
  },
  'organ': {
    oscillator: { type: 'sine' },
    envelope: { attack: 0.05, decay: 0.1, sustain: 1.0, release: 0.1 },
  },
  'marimba': {
    oscillator: { type: 'sine' },
    envelope: { attack: 0.001, decay: 0.8, sustain: 0.0, release: 0.5 },
  },
  'pluck': {
    oscillator: { type: 'triangle' },
    envelope: { attack: 0.001, decay: 0.5, sustain: 0.0, release: 0.3 },
  },
  'mono-synth': {
    oscillator: { type: 'sawtooth' },
    envelope: { attack: 0.01, decay: 0.2, sustain: 0.6, release: 0.3 },
  },
  'fm-synth': {
    oscillator: { type: 'fm' },
    envelope: { attack: 0.01, decay: 0.5, sustain: 0.3, release: 1.0 },
  },
  'am-synth': {
    oscillator: { type: 'am' },
    envelope: { attack: 0.01, decay: 0.3, sustain: 0.4, release: 0.8 },
  },
};

// Color palette for tracks
export const TRACK_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4',
  '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#6366f1',
];

export const LOOP_COLORS = [
  '#22c55e', '#3b82f6', '#a855f7', '#f59e0b', '#ef4444',
  '#06b6d4', '#ec4899', '#14b8a6',
];
