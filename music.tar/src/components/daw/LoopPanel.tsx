'use client';

import React from 'react';
import { useDawStore } from '@/store/daw-store';
import { cn } from '@/lib/utils';
import { Play, Square, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 100);
  return `${mins}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
}

export default function LoopPanel() {
  const { tracks, removeLoopRegion, toggleLoopRegion } = useDawStore();

  const allLoops = tracks.flatMap((track) =>
    track.loops.map((loop) => ({
      ...loop,
      trackId: track.id,
      trackName: track.name,
      trackColor: track.color,
      trackDuration: track.duration,
    }))
  );

  return (
    <div className="bg-zinc-900 border-t border-zinc-700/50">
      <div className="px-3 py-2 border-b border-zinc-800/50 flex items-center justify-between">
        <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
          🔁 Loop Regions
        </span>
        <span className="text-[10px] text-zinc-600">{allLoops.length} regions</span>
      </div>
      <ScrollArea className="h-[120px]">
        <div className="p-2 space-y-1.5">
          {allLoops.length === 0 ? (
            <div className="flex items-center justify-center py-6">
              <span className="text-xs text-zinc-600">
                Drag on a track waveform to create a loop region
              </span>
            </div>
          ) : (
            allLoops.map((loop) => (
              <div
                key={loop.id}
                className={cn(
                  'flex items-center gap-2 px-2 py-1.5 rounded-lg border transition-all',
                  loop.enabled
                    ? 'bg-zinc-800/60 border-zinc-700/50'
                    : 'bg-zinc-900/30 border-zinc-800/30 opacity-60'
                )}
              >
                <div
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ backgroundColor: loop.trackColor }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-zinc-300 font-medium truncate">
                      {loop.trackName}
                    </span>
                    <div
                      className="h-1 rounded-full"
                      style={{
                        width: `${((loop.end - loop.start) / loop.trackDuration) * 100}%`,
                        backgroundColor: loop.color,
                        maxWidth: '60px',
                        minWidth: '8px',
                      }}
                    />
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    {formatTime(loop.start)} → {formatTime(loop.end)} ({formatTime(loop.end - loop.start)})
                  </span>
                </div>
                <div className="flex items-center gap-0.5">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-zinc-500 hover:text-zinc-300"
                    onClick={() => toggleLoopRegion(loop.trackId, loop.id)}
                  >
                    {loop.enabled ? (
                      <ToggleRight className="w-4 h-4 text-green-400" />
                    ) : (
                      <ToggleLeft className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-zinc-500 hover:text-red-400"
                    onClick={() => removeLoopRegion(loop.trackId, loop.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
        <ScrollBar orientation="horizontal" className="h-1" />
      </ScrollArea>
    </div>
  );
}
