'use client';

import React, { useCallback, useEffect, useRef, useState, useMemo } from 'react';
import * as Tone from 'tone';
import { useDawStore } from '@/store/daw-store';
import { PIANO_NOTES } from '@/lib/midi-notes';
import { SYNTH_CONFIGS } from '@/lib/audio-engine';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';

export default function Piano() {
  const {
    activeSynthPreset,
    activeOctave,
    activeNotes,
    masterVolume,
    reverbMix,
    delayMix,
    attack,
    release,
    filterFreq,
    isRecording,
    addActiveNote,
    removeActiveNote,
    addRecordedNote,
  } = useDawStore();

  const synthRef = useRef<Tone.PolySynth | null>(null);
  const reverbRef = useRef<Tone.Reverb | null>(null);
  const delayRef = useRef<Tone.FeedbackDelay | null>(null);
  const filterRef = useRef<Tone.Filter | null>(null);
  const gainRef = useRef<Tone.Gain | null>(null);
  const noteStartTimesRef = useRef<Map<string, number>>(new Map());
  const initializedRef = useRef(false);
  const toneStartedRef = useRef(false);
  const [toneStarted, setToneStarted] = useState(false);

  // Get visible notes based on active octave
  const visibleNotes = useMemo(() => {
    const startMidi = (activeOctave + 1) * 12;
    const endMidi = startMidi + 24;
    return PIANO_NOTES.filter((n) => n.midi >= startMidi && n.midi < endMidi);
  }, [activeOctave]);

  const whiteCount = useMemo(() => visibleNotes.filter((n) => !n.isBlack).length, [visibleNotes]);

  // Create synth (must be before initAudio to avoid hoisting issues)
  const createSynth = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.dispose();
    }

    const state = useDawStore.getState();
    const preset = state.activeSynthPreset;
    const atk = state.attack;
    const rel = state.release;
    const config = SYNTH_CONFIGS[preset] || SYNTH_CONFIGS['grand-piano'];

    let synth: Tone.PolySynth;

    if (preset === 'fm-synth') {
      synth = new Tone.PolySynth(Tone.FMSynth, {
        harmonicity: 3,
        modulationIndex: 10,
        oscillator: { type: 'sine' },
        envelope: { attack: config.envelope.attack, decay: config.envelope.decay, sustain: config.envelope.sustain, release: config.envelope.release },
        modulation: { type: 'square' },
        modulationEnvelope: { attack: 0.5, decay: 0, sustain: 1, release: 0.5 },
      });
    } else if (preset === 'am-synth') {
      synth = new Tone.PolySynth(Tone.AMSynth, {
        harmonicity: 2,
        oscillator: { type: 'sine' },
        envelope: { attack: config.envelope.attack, decay: config.envelope.decay, sustain: config.envelope.sustain, release: config.envelope.release },
        modulation: { type: 'square' },
        modulationEnvelope: { attack: 0.5, decay: 0, sustain: 1, release: 0.5 },
      });
    } else if (preset === 'mono-synth') {
      synth = new Tone.PolySynth(Tone.MonoSynth, {
        oscillator: { type: config.oscillator.type },
        envelope: config.envelope,
        filterEnvelope: {
          attack: 0.05,
          decay: 0.3,
          sustain: 0.7,
          release: 0.8,
          baseFrequency: 200,
          octaves: 4,
        },
      });
    } else {
      synth = new Tone.PolySynth(Tone.Synth, {
        oscillator: config.oscillator,
        envelope: {
          ...config.envelope,
          attack: Math.max(0.001, atk),
          release: Math.max(0.01, rel),
        },
      });
    }

    synth.maxPolyphony = 32;
    if (gainRef.current) {
      synth.connect(gainRef.current);
    }

    synthRef.current = synth;
  }, []);

  // Initialize Tone.js audio context
  const initAudio = useCallback(async () => {
    if (initializedRef.current) return;
    initializedRef.current = true;

    await Tone.start();
    toneStartedRef.current = true;
    setToneStarted(true);

    // Create effects chain
    reverbRef.current = new Tone.Reverb({ decay: 2.5, wet: reverbMix }).toDestination();
    delayRef.current = new Tone.FeedbackDelay({ delayTime: '8n', feedback: 0.3, wet: delayMix }).connect(
      reverbRef.current
    );
    filterRef.current = new Tone.Filter({
      type: 'lowpass',
      frequency: filterFreq,
      Q: 1,
    }).connect(delayRef.current);
    gainRef.current = new Tone.Gain(masterVolume).connect(filterRef.current);

    createSynth();
  }, [reverbMix, delayMix, filterFreq, masterVolume, createSynth]);

  // Recreate synth when preset changes
  useEffect(() => {
    if (toneStartedRef.current) {
      createSynth();
    }
  }, [activeSynthPreset, attack, release, createSynth]);

  // Update effects parameters
  useEffect(() => {
    if (reverbRef.current) reverbRef.current.wet.value = reverbMix;
  }, [reverbMix]);

  useEffect(() => {
    if (delayRef.current) delayRef.current.wet.value = delayMix;
  }, [delayMix]);

  useEffect(() => {
    if (filterRef.current) filterRef.current.frequency.value = filterFreq;
  }, [filterFreq]);

  useEffect(() => {
    if (gainRef.current) gainRef.current.gain.value = masterVolume;
  }, [masterVolume]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (synthRef.current) synthRef.current.dispose();
      if (reverbRef.current) reverbRef.current.dispose();
      if (delayRef.current) delayRef.current.dispose();
      if (filterRef.current) filterRef.current.dispose();
      if (gainRef.current) gainRef.current.dispose();
      initializedRef.current = false;
    };
  }, []);

  const noteOn = useCallback(
    async (note: string) => {
      if (!toneStartedRef.current) await initAudio();
      if (!synthRef.current) return;

      try {
        synthRef.current.triggerAttack(note, Tone.now());
        addActiveNote(note);

        const state = useDawStore.getState();
        if (state.isRecording) {
          noteStartTimesRef.current.set(note, Date.now());
        }
      } catch (e) {
        console.error('Note on error:', e);
      }
    },
    [initAudio, addActiveNote]
  );

  const noteOff = useCallback(
    (note: string) => {
      if (!synthRef.current) return;

      try {
        synthRef.current.triggerRelease(note, Tone.now());
        removeActiveNote(note);

        const state = useDawStore.getState();
        if (state.isRecording && noteStartTimesRef.current.has(note)) {
          const startTime = noteStartTimesRef.current.get(note)!;
          const duration = (Date.now() - startTime) / 1000;
          state.addRecordedNote({
            note,
            time: startTime,
            duration,
            velocity: 0.8,
          });
          noteStartTimesRef.current.delete(note);
        }
      } catch (e) {
        console.error('Note off error:', e);
      }
    },
    [removeActiveNote]
  );

  // Keyboard mapping
  const keyboardMap = useMemo(() => {
    const keys = 'awsedftgyhujkolp';
    const map: Record<string, string> = {};
    let keyIdx = 0;
    for (let i = 0; i < visibleNotes.length && keyIdx < keys.length; i++) {
      if (!visibleNotes[i].isBlack) {
        map[keys[keyIdx]] = visibleNotes[i].note;
        keyIdx++;
      }
    }
    return map;
  }, [visibleNotes]);

  // Keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const key = e.key.toLowerCase();
      if (keyboardMap[key]) {
        e.preventDefault();
        noteOn(keyboardMap[key]);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (keyboardMap[key]) {
        e.preventDefault();
        noteOff(keyboardMap[key]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [keyboardMap, noteOn, noteOff]);

  const handleOctaveChange = (dir: number) => {
    const newOctave = activeOctave + dir;
    if (newOctave >= 1 && newOctave <= 6) {
      useDawStore.getState().setActiveOctave(newOctave);
    }
  };

  if (!toneStarted) {
    return (
      <div className="bg-zinc-950 border-t border-zinc-700/50 p-4">
        <button
          onClick={initAudio}
          className="w-full py-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all text-lg shadow-lg shadow-violet-500/20"
        >
          🎹 Click to Start Audio Engine
        </button>
        <p className="text-zinc-500 text-xs text-center mt-2">
          Start the audio engine to play instruments
        </p>
      </div>
    );
  }

  return (
    <div className="bg-zinc-950 border-t border-zinc-700/50">
      {/* Piano Controls */}
      <div className="flex items-center justify-between px-4 py-1.5 border-b border-zinc-800/50">
        <div className="flex items-center gap-3">
          <span className="text-zinc-500 text-xs font-medium">OCTAVE</span>
          <div className="flex items-center gap-0.5">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              onClick={() => handleOctaveChange(-1)}
            >
              <ChevronLeft className="w-3 h-3" />
            </Button>
            <span className="text-zinc-300 font-mono text-sm w-4 text-center">{activeOctave}</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              onClick={() => handleOctaveChange(1)}
            >
              <ChevronRight className="w-3 h-3" />
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-4 flex-wrap justify-end">
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-zinc-500">ATK</Label>
            <Slider
              value={[attack * 100]}
              onValueChange={([v]) => useDawStore.getState().setAttack(v / 100)}
              max={500}
              step={1}
              className="w-16"
            />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-zinc-500">REL</Label>
            <Slider
              value={[release * 100]}
              onValueChange={([v]) => useDawStore.getState().setRelease(v / 100)}
              max={500}
              step={1}
              className="w-16"
            />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-zinc-500">REV</Label>
            <Slider
              value={[reverbMix * 100]}
              onValueChange={([v]) => useDawStore.getState().setReverbMix(v / 100)}
              max={100}
              step={1}
              className="w-16"
            />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-zinc-500">DLY</Label>
            <Slider
              value={[delayMix * 100]}
              onValueChange={([v]) => useDawStore.getState().setDelayMix(v / 100)}
              max={100}
              step={1}
              className="w-16"
            />
          </div>
        </div>
      </div>

      {/* Piano Keys */}
      <div className="overflow-x-auto">
        <div className="relative flex h-[140px] min-w-[600px] mx-auto" style={{ justifyContent: 'center' }}>
          {visibleNotes.map((note, index) => {
            const isActive = activeNotes.has(note.note);
            const isBlack = note.isBlack;

            if (isBlack) {
              const prevWhiteIdx = visibleNotes.slice(0, index).filter((n) => !n.isBlack).length;
              const wkPct = `${100 / whiteCount}%`;
              return (
                <div
                  key={note.note}
                  className={cn(
                    'absolute top-0 z-10 rounded-b-md cursor-pointer transition-all duration-75 select-none',
                    isActive
                      ? 'bg-gradient-to-b from-violet-400 to-violet-700 shadow-lg shadow-violet-500/30'
                      : 'bg-gradient-to-b from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800'
                  )}
                  style={{
                    left: `calc(${prevWhiteIdx} * ${wkPct} + ${wkPct} * 0.65 - 1.5%)`,
                    width: `calc(${wkPct} * 0.7)`,
                    height: '60%',
                  }}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    noteOn(note.note);
                  }}
                  onMouseUp={() => noteOff(note.note)}
                  onMouseLeave={() => {
                    if (activeNotes.has(note.note)) noteOff(note.note);
                  }}
                  onTouchStart={(e) => {
                    e.preventDefault();
                    noteOn(note.note);
                  }}
                  onTouchEnd={() => noteOff(note.note)}
                >
                  <div className="w-full h-full flex items-end justify-center pb-1">
                    <span className="text-[8px] text-zinc-400 font-mono">{note.note.replace(/\d/, '')}</span>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={note.note}
                className={cn(
                  'flex-shrink-0 relative cursor-pointer border-x border-zinc-700/50 transition-all duration-75 select-none',
                  isActive
                    ? 'bg-gradient-to-b from-violet-100 to-violet-300 border-violet-400 shadow-inner'
                    : 'bg-gradient-to-b from-zinc-100 to-zinc-200 hover:from-zinc-50 hover:to-zinc-100'
                )}
                style={{
                  width: `${100 / whiteCount}%`,
                  height: '100%',
                }}
                onMouseDown={(e) => {
                  e.preventDefault();
                  noteOn(note.note);
                }}
                onMouseUp={() => noteOff(note.note)}
                onMouseLeave={() => {
                  if (activeNotes.has(note.note)) noteOff(note.note);
                }}
                onTouchStart={(e) => {
                  e.preventDefault();
                  noteOn(note.note);
                }}
                onTouchEnd={() => noteOff(note.note)}
              >
                <div className="w-full h-full flex flex-col items-center justify-end pb-2">
                  <span className="text-[10px] text-zinc-400 font-mono font-medium">{note.note}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Keyboard hints */}
      <div className="px-4 py-1 border-t border-zinc-800/50 flex items-center justify-center gap-2">
        <span className="text-[10px] text-zinc-600">⌨️</span>
        <span className="text-[10px] text-zinc-500">
          Use keyboard: A S D F G H J K L to play white keys
        </span>
      </div>
    </div>
  );
}
