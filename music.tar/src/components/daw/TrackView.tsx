'use client';

import React, { useCallback, useRef, useState } from 'react';
import { useDawStore } from '@/store/daw-store';
import { cn } from '@/lib/utils';
import {
  Upload,
  Trash2,
  Volume2,
  VolumeX,
  Headphones,
  Scissors,
  Copy,
  Plus,
  Music,
  GripVertical,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface TrackHeaderProps {
  trackId: string;
}

function TrackHeader({ trackId }: TrackHeaderProps) {
  const track = useDawStore((s) => s.tracks.find((t) => t.id === trackId));
  const updateTrack = useDawStore((s) => s.updateTrack);
  const removeTrack = useDawStore((s) => s.removeTrack);
  const selectedTrackId = useDawStore((s) => s.selectedTrackId);
  const setSelectedTrackId = useDawStore((s) => s.setSelectedTrackId);

  if (!track) return null;

  return (
    <div
      className={cn(
        'flex flex-col gap-1.5 p-3 border-b border-zinc-800/50 cursor-pointer transition-colors min-h-[80px]',
        selectedTrackId === trackId ? 'bg-zinc-800/60' : 'hover:bg-zinc-800/30'
      )}
      onClick={() => setSelectedTrackId(trackId)}
    >
      <div className="flex items-center gap-2">
        <div
          className="w-2 h-2 rounded-full flex-shrink-0"
          style={{ backgroundColor: track.color }}
        />
        <span className="text-xs text-zinc-300 font-medium truncate flex-1">{track.name}</span>
        <Button
          variant="ghost"
          size="icon"
          className="h-5 w-5 text-zinc-500 hover:text-red-400 hover:bg-zinc-800"
          onClick={(e) => {
            e.stopPropagation();
            removeTrack(trackId);
          }}
        >
          <Trash2 className="w-3 h-3" />
        </Button>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            'h-6 w-6',
            track.muted ? 'text-red-400' : 'text-zinc-500 hover:text-zinc-300'
          )}
          onClick={(e) => {
            e.stopPropagation();
            updateTrack(trackId, { muted: !track.muted });
          }}
        >
          {track.muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
        </Button>
        <Slider
          value={[track.muted ? 0 : track.volume * 100]}
          onValueChange={([v]) => updateTrack(trackId, { volume: v / 100, muted: false })}
          max={100}
          step={1}
          className="flex-1"
        />
      </div>
    </div>
  );
}

interface TrackWaveformProps {
  trackId: string;
}

function TrackWaveform({ trackId }: TrackWaveformProps) {
  const track = useDawStore((s) => s.tracks.find((t) => t.id === trackId));
  const waveformsCache = useDawStore((s) => s.waveformsCache);
  const addLoopRegion = useDawStore((s) => s.addLoopRegion);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawStart, setDrawStart] = useState(0);
  const [drawEnd, setDrawEnd] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const waveformData = waveformsCache.get(trackId) || track?.waveformData || [];

  // Draw waveform
  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || waveformData.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const midY = height / 2;

    ctx.clearRect(0, 0, width, height);

    // Draw waveform
    if (!track?.muted) {
      const gradient = ctx.createLinearGradient(0, 0, width, 0);
      gradient.addColorStop(0, track?.color || '#22c55e');
      gradient.addColorStop(0.5, track?.color || '#22c55e');
      gradient.addColorStop(1, track?.color || '#22c55e');

      ctx.fillStyle = gradient;
      ctx.globalAlpha = 0.8;
    } else {
      ctx.fillStyle = '#525252';
      ctx.globalAlpha = 0.4;
    }

    const barWidth = Math.max(1, width / waveformData.length);
    for (let i = 0; i < waveformData.length; i++) {
      const x = (i / waveformData.length) * width;
      const amplitude = waveformData[i] * midY * 0.9;
      ctx.fillRect(x, midY - amplitude, barWidth - 0.5, amplitude * 2);
    }

    ctx.globalAlpha = 1;

    // Draw loop regions
    if (track?.loops && track.duration > 0) {
      for (const loop of track.loops) {
        const startX = (loop.start / track.duration) * width;
        const endX = (loop.end / track.duration) * width;
        ctx.fillStyle = loop.enabled ? `${loop.color}30` : `${loop.color}15`;
        ctx.strokeStyle = loop.enabled ? loop.color : `${loop.color}40`;
        ctx.lineWidth = 2;
        ctx.fillRect(startX, 0, endX - startX, height);
        ctx.strokeRect(startX, 1, endX - startX, height - 2);

        // Loop icon
        ctx.fillStyle = loop.color;
        ctx.font = '12px sans-serif';
        ctx.fillText('🔁', startX + 4, 16);
      }
    }
  }, [waveformData, track, track?.muted, track?.loops]);

  // Mouse handling for loop region drawing
  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect || !track?.duration) return;
      const x = (e.clientX - rect.left) / rect.width;
      setIsDrawing(true);
      setDrawStart(x);
      setDrawEnd(x);
    },
    [track?.duration]
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDrawing) return;
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      setDrawEnd(x);
    },
    [isDrawing]
  );

  const handleMouseUp = useCallback(() => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const t = useDawStore.getState().tracks.find((tr) => tr.id === trackId);
    if (!t?.duration) return;
    const start = Math.min(drawStart, drawEnd) * t.duration;
    const end = Math.max(drawStart, drawEnd) * t.duration;
    if (end - start > 0.1) {
      addLoopRegion(trackId, {
        start,
        end,
        enabled: true,
        color: '#22c55e',
      });
    }
  }, [isDrawing, drawStart, drawEnd, trackId, addLoopRegion]);

  if (!track) return null;

  return (
    <div
      ref={containerRef}
      className="relative h-[80px] border-b border-zinc-800/50 cursor-crosshair group"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => {
        if (isDrawing) handleMouseUp();
      }}
    >
      {/* Background grid */}
      <div className="absolute inset-0 opacity-10">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute top-0 bottom-0 w-px bg-zinc-500"
            style={{ left: `${(i / 20) * 100}%` }}
          />
        ))}
      </div>

      {/* Waveform */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
      />

      {/* Drawing overlay */}
      {isDrawing && (
        <div
          className="absolute top-0 bottom-0 bg-green-500/20 border-2 border-green-400 border-dashed pointer-events-none"
          style={{
            left: `${Math.min(drawStart, drawEnd) * 100}%`,
            width: `${Math.abs(drawEnd - drawStart) * 100}%`,
          }}
        />
      )}

      {/* Empty state */}
      {waveformData.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-zinc-600 text-xs">No audio data</span>
        </div>
      )}

      {/* Hover hint */}
      <div className="absolute top-1 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <span className="text-[10px] text-zinc-600 bg-zinc-900/80 px-1.5 py-0.5 rounded">
          Drag to create loop region
        </span>
      </div>
    </div>
  );
}

interface AudioUploaderProps {
  onFileLoaded: (file: File, audioBuffer: AudioBuffer, waveformData: number[]) => void;
}

export function AudioUploader({ onFileLoaded }: AudioUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const processFile = useCallback(
    async (file: File) => {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      try {
        const arrayBuffer = await file.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

        // Generate waveform data
        const channelData = audioBuffer.getChannelData(0);
        const samples = 500;
        const blockSize = Math.floor(channelData.length / samples);
        const waveformData: number[] = [];
        for (let i = 0; i < samples; i++) {
          let sum = 0;
          for (let j = 0; j < blockSize; j++) {
            sum += Math.abs(channelData[i * blockSize + j]);
          }
          waveformData.push(sum / blockSize);
        }

        // Normalize
        const max = Math.max(...waveformData, 0.01);
        const normalized = waveformData.map((v) => v / max);

        onFileLoaded(file, audioBuffer, normalized);
      } catch (error) {
        console.error('Error processing audio file:', error);
      } finally {
        audioContext.close();
      }
    },
    [onFileLoaded]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('audio/')) {
        processFile(file);
      }
    },
    [processFile]
  );

  return (
    <div
      className={cn(
        'border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer',
        isDragging
          ? 'border-violet-400 bg-violet-500/10'
          : 'border-zinc-700 hover:border-zinc-500 bg-zinc-900/30'
      )}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input
        ref={inputRef}
        type="file"
        accept="audio/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) processFile(file);
        }}
      />
      <Upload className="w-8 h-8 text-zinc-500 mx-auto mb-2" />
      <p className="text-sm text-zinc-400">
        <span className="text-violet-400 font-medium">Click or drag</span> to upload audio
      </p>
      <p className="text-xs text-zinc-600 mt-1">MP3, WAV, OGG, FLAC supported</p>
    </div>
  );
}

export default function TrackView() {
  const { tracks, addTrack, setWaveformData, showMixer, setShowMixer, showLoopPanel, setShowLoopPanel } =
    useDawStore();
  const audioPlayerRef = useRef<{ [key: string]: HTMLAudioElement }>({});

  const handleFileLoaded = useCallback(
    (file: File, audioBuffer: AudioBuffer, waveformData: number[]) => {
      const url = URL.createObjectURL(file);
      const id = addTrack({
        name: file.name.replace(/\.[^/.]+$/, ''),
        type: 'audio',
        buffer: audioBuffer,
        file,
        volume: 0.75,
        pan: 0,
        muted: false,
        solo: false,
        color: '#22c55e',
        waveformData,
        duration: audioBuffer.duration,
      });
      setWaveformData(id, waveformData);

      // Create audio player
      const audio = new Audio(url);
      audioPlayerRef.current[id] = audio;
    },
    [addTrack, setWaveformData]
  );

  return (
    <TooltipProvider delayDuration={300}>
      <div className="flex flex-col flex-1 min-h-0 bg-zinc-900/50">
        {/* Track toolbar */}
        <div className="flex items-center gap-2 px-3 py-1.5 border-b border-zinc-700/50 bg-zinc-900">
          <span className="text-xs text-zinc-400 font-medium">Tracks</span>
          <div className="flex-1" />
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  'h-7 gap-1 text-xs',
                  showMixer ? 'bg-violet-600/20 text-violet-300' : 'text-zinc-400 hover:text-zinc-200'
                )}
                onClick={() => setShowMixer(!showMixer)}
              >
                <Volume2 className="w-3 h-3" />
                Mixer
              </Button>
            </TooltipTrigger>
            <TooltipContent>Toggle Mixer</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  'h-7 gap-1 text-xs',
                  showLoopPanel ? 'bg-violet-600/20 text-violet-300' : 'text-zinc-400 hover:text-zinc-200'
                )}
                onClick={() => setShowLoopPanel(!showLoopPanel)}
              >
                <Repeat className="w-3 h-3" />
                Loops
              </Button>
            </TooltipTrigger>
            <TooltipContent>Loop Regions</TooltipContent>
          </Tooltip>
        </div>

        {/* Track area */}
        <div className="flex-1 min-h-0 overflow-auto">
          {tracks.length === 0 ? (
            <div className="flex items-center justify-center h-full p-8">
              <div className="max-w-sm">
                <Music className="w-12 h-12 text-zinc-700 mx-auto mb-4" />
                <h3 className="text-zinc-400 text-center text-lg font-medium mb-2">No tracks yet</h3>
                <AudioUploader onFileLoaded={handleFileLoaded} />
              </div>
            </div>
          ) : (
            <div className="flex">
              {/* Track headers */}
              <div className="w-[180px] flex-shrink-0 border-r border-zinc-700/50 bg-zinc-900">
                {tracks.map((track) => (
                  <TrackHeader key={track.id} trackId={track.id} />
                ))}
                <div className="p-2 border-b border-zinc-800/50">
                  <AudioUploader onFileLoaded={handleFileLoaded} />
                </div>
              </div>

              {/* Track waveforms */}
              <div className="flex-1 min-w-0">
                {tracks.map((track) => (
                  <TrackWaveform key={track.id} trackId={track.id} />
                ))}
                <div className="h-12 border-b border-zinc-800/50 flex items-center justify-center">
                  <span className="text-xs text-zinc-600">Timeline ruler</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
}

function Repeat({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="m17 2 4 4-4 4" />
      <path d="M3 11v-1a4 4 0 0 1 4-4h14" />
      <path d="m7 22-4-4 4-4" />
      <path d="M21 13v1a4 4 0 0 1-4 4H3" />
    </svg>
  );
}
