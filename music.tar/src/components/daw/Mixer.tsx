'use client';

import React from 'react';
import { useDawStore } from '@/store/daw-store';
import { cn } from '@/lib/utils';
import { Volume2, VolumeX, Headphones } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';

export default function Mixer() {
  const { tracks, masterVolume, updateTrack, setMasterVolume } = useDawStore();

  return (
    <div className="bg-zinc-900 border-t border-zinc-700/50">
      <div className="px-3 py-2 border-b border-zinc-800/50 flex items-center">
        <Volume2 className="w-3.5 h-3.5 text-zinc-400 mr-2" />
        <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Mixer</span>
      </div>
      <div className="flex gap-3 p-3 overflow-x-auto">
        {/* Master Channel */}
        <div className="flex flex-col items-center gap-2 min-w-[60px]">
          <span className="text-[10px] text-zinc-500 font-semibold uppercase">Master</span>
          <div className="relative h-[100px] w-8 bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
            <div
              className="absolute bottom-0 w-full bg-gradient-to-t from-green-500 via-green-400 to-yellow-400 rounded-full transition-all"
              style={{ height: `${masterVolume * 100}%` }}
            />
            <div className="absolute top-0 left-0 right-0 h-full flex flex-col justify-between p-1 pointer-events-none">
              <div className="w-2 h-px bg-red-500/40 mx-auto" />
              <div className="w-2 h-px bg-yellow-500/40 mx-auto" />
            </div>
          </div>
          <div className="h-24 flex items-center justify-center">
            <Slider
              orientation="vertical"
              value={[masterVolume * 100]}
              onValueChange={([v]) => setMasterVolume(v / 100)}
              max={100}
              step={1}
              className="h-full"
            />
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">{Math.round(masterVolume * 100)}%</span>
        </div>

        <div className="w-px bg-zinc-700/50" />

        {/* Track Channels */}
        {tracks.map((track) => (
          <div
            key={track.id}
            className="flex flex-col items-center gap-2 min-w-[60px]"
          >
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: track.color }} />
            <span className="text-[10px] text-zinc-400 font-medium truncate max-w-[60px]">
              {track.name}
            </span>

            {/* VU Meter */}
            <div className="relative h-[100px] w-6 bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
              <div
                className={cn(
                  'absolute bottom-0 w-full rounded-full transition-all',
                  track.muted
                    ? 'bg-zinc-600'
                    : 'bg-gradient-to-t from-green-500 via-green-400 to-yellow-400'
                )}
                style={{ height: `${track.muted ? 0 : track.volume * 100}%` }}
              />
              <div className="absolute top-0 left-0 right-0 h-full flex flex-col justify-between p-0.5 pointer-events-none">
                <div className="w-1.5 h-px bg-red-500/40 mx-auto" />
                <div className="w-1.5 h-px bg-yellow-500/40 mx-auto" />
              </div>
            </div>

            {/* Volume Fader */}
            <div className="h-24 flex items-center justify-center">
              <Slider
                orientation="vertical"
                value={[track.muted ? 0 : track.volume * 100]}
                onValueChange={([v]) => updateTrack(track.id, { volume: v / 100, muted: false })}
                max={100}
                step={1}
                className="h-full"
              />
            </div>

            {/* Controls */}
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  'h-5 w-5',
                  track.muted ? 'text-red-400' : 'text-zinc-500'
                )}
                onClick={() => updateTrack(track.id, { muted: !track.muted })}
              >
                {track.muted ? (
                  <VolumeX className="w-3 h-3" />
                ) : (
                  <Volume2 className="w-3 h-3" />
                )}
              </Button>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">
              {Math.round(track.volume * 100)}%
            </span>
          </div>
        ))}

        {tracks.length === 0 && (
          <div className="flex items-center justify-center flex-1 py-8">
            <span className="text-xs text-zinc-600">Add tracks to see them in the mixer</span>
          </div>
        )}
      </div>
    </div>
  );
}
