'use client';

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useDawStore } from '@/store/daw-store';
import { PIANO_NOTES } from '@/lib/midi-notes';
import {
  Play,
  Square,
  Circle,
  Repeat,
  Timer,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 100);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
}

export default function TransportBar() {
  const {
    isPlaying,
    isRecording,
    isLooping,
    bpm,
    currentTime,
    masterVolume,
    activeSynthPreset,
    metronomeOn,
    setIsPlaying,
    setIsRecording,
    setIsLooping,
    setBpm,
    setCurrentTime,
    setMasterVolume,
    setMetronomeOn,
  } = useDawStore();

  const timerRef = useRef<ReturnType<typeof requestAnimationFrame> | null>(null);
  const lastTimeRef = useRef<number>(0);

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = performance.now();
      const tick = (now: number) => {
        const delta = (now - lastTimeRef.current) / 1000;
        lastTimeRef.current = now;
        setCurrentTime(useDawStore.getState().currentTime + delta);
        timerRef.current = requestAnimationFrame(tick);
      };
      timerRef.current = requestAnimationFrame(tick);
    } else {
      if (timerRef.current) {
        cancelAnimationFrame(timerRef.current);
      }
    }
    return () => {
      if (timerRef.current) cancelAnimationFrame(timerRef.current);
    };
  }, [isPlaying, setCurrentTime]);

  const handleStop = useCallback(() => {
    setIsPlaying(false);
    setIsRecording(false);
    setCurrentTime(0);
  }, [setIsPlaying, setIsRecording, setCurrentTime]);

  return (
    <TooltipProvider delayDuration={300}>
      <div className="flex items-center gap-3 px-4 py-2 bg-zinc-900 border-b border-zinc-700/50 min-h-[56px]">
        {/* Logo / Title */}
        <div className="flex items-center gap-2 mr-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <span className="text-white font-bold text-sm">S</span>
          </div>
          <span className="text-zinc-300 font-semibold text-sm hidden sm:block">Studio Pro</span>
        </div>

        <div className="h-6 w-px bg-zinc-700" />

        {/* BPM Control */}
        <div className="flex items-center gap-2">
          <Timer className="w-4 h-4 text-zinc-400" />
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              onClick={() => setBpm(bpm - 1)}
            >
              <ChevronLeft className="w-3 h-3" />
            </Button>
            <input
              type="number"
              value={bpm}
              onChange={(e) => setBpm(parseInt(e.target.value) || 120)}
              className="w-14 h-7 bg-zinc-800 border border-zinc-600 rounded text-center text-zinc-200 text-sm font-mono focus:outline-none focus:border-violet-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              onClick={() => setBpm(bpm + 1)}
            >
              <ChevronRight className="w-3 h-3" />
            </Button>
          </div>
          <span className="text-zinc-500 text-xs">BPM</span>
        </div>

        <div className="h-6 w-px bg-zinc-700" />

        {/* Transport Controls */}
        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={isPlaying ? 'default' : 'ghost'}
                size="icon"
                className={`h-9 w-9 rounded-full ${
                  isPlaying
                    ? 'bg-green-600 hover:bg-green-500 text-white'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
                }`}
                onClick={() => setIsPlaying(!isPlaying)}
              >
                <Play className="w-4 h-4 ml-0.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Play / Pause</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
                onClick={handleStop}
              >
                <Square className="w-3.5 h-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Stop</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={isRecording ? 'default' : 'ghost'}
                size="icon"
                className={`h-9 w-9 rounded-full ${
                  isRecording
                    ? 'bg-red-600 hover:bg-red-500 text-white animate-pulse'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
                }`}
                onClick={() => setIsRecording(!isRecording)}
              >
                <Circle className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Record</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={isLooping ? 'default' : 'ghost'}
                size="icon"
                className={`h-9 w-9 rounded-full ${
                  isLooping
                    ? 'bg-violet-600 hover:bg-violet-500 text-white'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
                }`}
                onClick={() => setIsLooping(!isLooping)}
              >
                <Repeat className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Loop</TooltipContent>
          </Tooltip>
        </div>

        <div className="h-6 w-px bg-zinc-700" />

        {/* Time Display */}
        <div className="flex items-center gap-2">
          <div className="bg-zinc-950 rounded-lg px-3 py-1.5 border border-zinc-700 min-w-[120px]">
            <span className="text-green-400 font-mono text-sm tracking-wider">
              {formatTime(currentTime)}
            </span>
          </div>
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Metronome */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={metronomeOn ? 'default' : 'ghost'}
              size="sm"
              className={`h-8 gap-1.5 text-xs ${
                metronomeOn
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
              onClick={() => setMetronomeOn(!metronomeOn)}
            >
              🔔 <span className="hidden sm:inline">Metro</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>Metronome</TooltipContent>
        </Tooltip>

        {/* Master Volume */}
        <div className="flex items-center gap-2 ml-2">
          {masterVolume === 0 ? (
            <VolumeX className="w-4 h-4 text-zinc-400" />
          ) : (
            <Volume2 className="w-4 h-4 text-zinc-400" />
          )}
          <Slider
            value={[masterVolume * 100]}
            onValueChange={([v]) => setMasterVolume(v / 100)}
            max={100}
            step={1}
            className="w-20 sm:w-28"
          />
          <span className="text-zinc-500 text-xs font-mono w-8">
            {Math.round(masterVolume * 100)}%
          </span>
        </div>
      </div>
    </TooltipProvider>
  );
}
