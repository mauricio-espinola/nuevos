'use client';

import React, { useCallback, useEffect, useRef } from 'react';
import * as Tone from 'tone';
import { useDawStore } from '@/store/daw-store';

/**
 * AudioPlayer - Manages playback of audio tracks using Tone.js
 * Connects to the DAW transport controls
 */
export default function AudioPlayerEngine() {
  const playersRef = useRef<Map<string, Tone.Player>>(new Map());
  const bpmRef = useRef(120);
  const loopEnabledRef = useRef(false);
  const initializedRef = useRef(false);

  // Initialize Tone.Transport
  useEffect(() => {
    if (initializedRef.current) return;
    initializedRef.current = true;

    Tone.Transport.bpm.value = 120;

    return () => {
      playersRef.current.forEach((player) => player.dispose());
      playersRef.current.clear();
      Tone.Transport.stop();
      Tone.Transport.cancel();
      initializedRef.current = false;
    };
  }, []);

  // Watch for track changes - create/destroy players
  useEffect(() => {
    const state = useDawStore.getState();
    const tracks = state.tracks;

    // Remove players for tracks that no longer exist
    playersRef.current.forEach((player, trackId) => {
      if (!tracks.find((t) => t.id === trackId)) {
        player.dispose();
        playersRef.current.delete(trackId);
      }
    });

    // Create players for new tracks (lazy - they'll be created when a URL is available)
    // Players are created in the TrackAudioPlayer component
  }, [useDawStore.getState().tracks]);

  return null;
}

/**
 * Hook to manage a single audio track's playback
 */
export function useTrackAudioPlayer(trackId: string, url: string | null) {
  const playerRef = useRef<Tone.Player | null>(null);
  const gainRef = useRef<Tone.Gain | null>(null);
  const panRef = useRef<Tone.Panner | null>(null);

  useEffect(() => {
    if (!url) return;

    let cancelled = false;

    const init = async () => {
      try {
        await Tone.start();

        if (cancelled) return;

        const player = new Tone.Player({
          url,
          loop: false,
          autostart: false,
        });

        const gain = new Tone.Gain(0.75).toDestination();
        const pan = new Tone.Panner(0).connect(gain);

        player.connect(pan);
        playerRef.current = player;
        gainRef.current = gain;
        panRef.current = pan;
      } catch (e) {
        console.error('Failed to create player:', e);
      }
    };

    init();

    return () => {
      cancelled = true;
      if (playerRef.current) {
        playerRef.current.dispose();
        playerRef.current = null;
      }
      if (gainRef.current) {
        gainRef.current.dispose();
        gainRef.current = null;
      }
      if (panRef.current) {
        panRef.current.dispose();
        panRef.current = null;
      }
    };
  }, [url]);

  const play = useCallback(() => {
    if (playerRef.current) {
      playerRef.current.start();
    }
  }, []);

  const stop = useCallback(() => {
    if (playerRef.current) {
      playerRef.current.stop();
    }
  }, []);

  const setVolume = useCallback((vol: number) => {
    if (gainRef.current) {
      gainRef.current.gain.value = vol;
    }
  }, []);

  const setPan = useCallback((pan: number) => {
    if (panRef.current) {
      panRef.current.pan.value = pan;
    }
  }, []);

  const setMuted = useCallback((muted: boolean) => {
    if (gainRef.current) {
      gainRef.current.gain.value = muted ? 0 : useDawStore.getState().tracks.find((t) => t.id === trackId)?.volume || 0.75;
    }
  }, [trackId]);

  return { play, stop, setVolume, setPan, setMuted };
}

/**
 * Simple AudioPlayer component for playing audio tracks
 */
export function TrackAudioPlayer({ trackId, url }: { trackId: string; url: string }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { isPlaying, tracks } = useDawStore();
  const track = tracks.find((t) => t.id === trackId);

  useEffect(() => {
    const audio = new Audio(url);
    audio.volume = track?.volume || 0.75;
    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, [url]);

  // Sync volume
  useEffect(() => {
    if (audioRef.current && track) {
      audioRef.current.volume = track.muted ? 0 : track.volume;
    }
  }, [track?.volume, track?.muted]);

  // Play/Stop
  useEffect(() => {
    if (!audioRef.current) return;

    if (isPlaying && !track?.muted) {
      audioRef.current.play().catch(() => {});
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, track?.muted]);

  return null;
}
