'use client';

import React, { useRef, useCallback, useEffect, useState } from 'react';
import * as Tone from 'tone';
import { useDawStore } from '@/store/daw-store';
import { SYNTH_CONFIGS } from '@/lib/audio-engine';
import { Trash2, Play, Square, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { RecordedNote } from '@/lib/audio-engine';

export function RecordingsPanel() {
  const { recordedNotes, clearRecordedNotes, activeSynthPreset } = useDawStore();
  const [isPlayingRecording, setIsPlayingRecording] = useState(false);

  const playRecording = useCallback(async () => {
    if (recordedNotes.length === 0) return;

    await Tone.start();

    const config = SYNTH_CONFIGS[activeSynthPreset] || SYNTH_CONFIGS['grand-piano'];
    const synth = new Tone.PolySynth(Tone.Synth, {
      oscillator: config.oscillator,
      envelope: config.envelope,
    }).toDestination();

    const startTime = recordedNotes[0].time;
    setIsPlayingRecording(true);

    for (const note of recordedNotes) {
      const delay = (note.time - startTime) / 1000;
      setTimeout(() => {
        synth.triggerAttackRelease(note.note, note.duration, Tone.now());
      }, delay * 1000);
    }

    // Stop after last note
    const lastNote = recordedNotes[recordedNotes.length - 1];
    const totalDuration = (lastNote.time - startTime) / 1000 + lastNote.duration + 1;
    setTimeout(() => {
      synth.dispose();
      setIsPlayingRecording(false);
    }, totalDuration * 1000);
  }, [recordedNotes, activeSynthPreset]);

  if (recordedNotes.length === 0) return null;

  return (
    <div className="bg-zinc-900 border-t border-zinc-700/50">
      <div className="px-3 py-2 border-b border-zinc-800/50 flex items-center justify-between">
        <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
          🎙️ Recorded Notes
        </span>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 gap-1 text-xs text-green-400 hover:text-green-300 hover:bg-green-500/10"
            onClick={playRecording}
            disabled={isPlayingRecording}
          >
            <Play className="w-3 h-3" />
            Play
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 gap-1 text-xs text-zinc-400 hover:text-red-400 hover:bg-red-500/10"
            onClick={clearRecordedNotes}
          >
            <Trash2 className="w-3 h-3" />
            Clear
          </Button>
        </div>
      </div>
      <div className="flex gap-1 px-3 py-2 overflow-x-auto">
        {recordedNotes.slice(0, 50).map((note, i) => (
          <div
            key={i}
            className="flex-shrink-0 px-2 py-1 bg-zinc-800 rounded text-[10px] text-zinc-400 font-mono"
          >
            {note.note}
          </div>
        ))}
        {recordedNotes.length > 50 && (
          <div className="flex-shrink-0 px-2 py-1 text-[10px] text-zinc-500">
            +{recordedNotes.length - 50} more
          </div>
        )}
      </div>
    </div>
  );
}
