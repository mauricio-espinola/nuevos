'use client';

import React, { useCallback, useMemo } from 'react';
import { useDawStore } from '@/store/daw-store';
import { SYNTH_PRESETS } from '@/lib/audio-engine';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

export default function SynthSelector() {
  const { activeSynthPreset, setActiveSynthPreset } = useDawStore();

  const categories = useMemo(() => {
    const cats = new Set(SYNTH_PRESETS.map((p) => p.category));
    return Array.from(cats);
  }, []);

  const presetsByCategory = useMemo(() => {
    const map: Record<string, typeof SYNTH_PRESETS> = {};
    for (const cat of categories) {
      map[cat] = SYNTH_PRESETS.filter((p) => p.category === cat);
    }
    return map;
  }, [categories]);

  return (
    <div className="bg-zinc-900 border-r border-zinc-700/50 w-full lg:w-[220px] flex flex-col overflow-hidden">
      <div className="px-3 py-2 border-b border-zinc-700/50">
        <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Instruments</h3>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-3">
          {categories.map((category) => (
            <div key={category}>
              <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest px-1 mb-1">
                {category}
              </p>
              <div className="space-y-0.5">
                {presetsByCategory[category].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setActiveSynthPreset(preset.id)}
                    className={cn(
                      'w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition-all text-sm',
                      activeSynthPreset === preset.id
                        ? 'bg-violet-600/20 text-violet-300 border border-violet-500/30'
                        : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-300 border border-transparent'
                    )}
                  >
                    <span className="text-base">{preset.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{preset.name}</p>
                      <p className="text-[10px] text-zinc-500 truncate">{preset.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        <ScrollBar orientation="vertical" className="w-1" />
      </ScrollArea>
    </div>
  );
}
