import { create } from 'zustand';
import {
  AudioTrack,
  LoopRegion,
  RecordedNote,
  TRACK_COLORS,
  LOOP_COLORS,
} from '@/lib/audio-engine';

interface DawState {
  // Transport
  isPlaying: boolean;
  isRecording: boolean;
  isLooping: boolean;
  bpm: number;
  currentTime: number;
  masterVolume: number;

  // Synth
  activeSynthPreset: string;
  activeOctave: number;
  activeNotes: Set<string>;
  reverbMix: number;
  delayMix: number;
  attack: number;
  release: number;
  filterFreq: number;

  // Tracks
  tracks: AudioTrack[];
  selectedTrackId: string | null;
  metronomeOn: boolean;

  // Recording
  recordedNotes: RecordedNote[];
  recordingStartTime: number;

  // UI
  showMixer: boolean;
  showLoopPanel: boolean;
  waveformsCache: Map<string, number[]>;

  // Actions
  setIsPlaying: (playing: boolean) => void;
  setIsRecording: (recording: boolean) => void;
  setIsLooping: (looping: boolean) => void;
  setBpm: (bpm: number) => void;
  setCurrentTime: (time: number) => void;
  setMasterVolume: (volume: number) => void;
  setActiveSynthPreset: (preset: string) => void;
  setActiveOctave: (octave: number) => void;
  setActiveNotes: (notes: Set<string>) => void;
  addActiveNote: (note: string) => void;
  removeActiveNote: (note: string) => void;
  setReverbMix: (mix: number) => void;
  setDelayMix: (mix: number) => void;
  setAttack: (attack: number) => void;
  setRelease: (release: number) => void;
  setFilterFreq: (freq: number) => void;
  addTrack: (track: Omit<AudioTrack, 'id' | 'loops'>) => string;
  removeTrack: (id: string) => void;
  updateTrack: (id: string, updates: Partial<AudioTrack>) => void;
  setSelectedTrackId: (id: string | null) => void;
  addLoopRegion: (trackId: string, loop: Omit<LoopRegion, 'id'>) => void;
  removeLoopRegion: (trackId: string, loopId: string) => void;
  updateLoopRegion: (trackId: string, loopId: string, updates: Partial<LoopRegion>) => void;
  toggleLoopRegion: (trackId: string, loopId: string) => void;
  setMetronomeOn: (on: boolean) => void;
  addRecordedNote: (note: RecordedNote) => void;
  clearRecordedNotes: () => void;
  setShowMixer: (show: boolean) => void;
  setShowLoopPanel: (show: boolean) => void;
  setWaveformData: (trackId: string, data: number[]) => void;
  setTracks: (tracks: AudioTrack[]) => void;
  reset: () => void;
}

let trackIdCounter = 0;
let loopIdCounter = 0;

export const useDawStore = create<DawState>((set, get) => ({
  // Initial state
  isPlaying: false,
  isRecording: false,
  isLooping: false,
  bpm: 120,
  currentTime: 0,
  masterVolume: 0.75,
  activeSynthPreset: 'grand-piano',
  activeOctave: 4,
  activeNotes: new Set(),
  reverbMix: 0,
  delayMix: 0,
  attack: 0.01,
  release: 0.5,
  filterFreq: 20000,
  tracks: [],
  selectedTrackId: null,
  metronomeOn: false,
  recordedNotes: [],
  recordingStartTime: 0,
  showMixer: false,
  showLoopPanel: false,
  waveformsCache: new Map(),

  // Transport actions
  setIsPlaying: (playing) => set({ isPlaying: playing }),
  setIsRecording: (recording) =>
    set((state) => ({
      isRecording: recording,
      recordingStartTime: recording ? Date.now() : 0,
    })),
  setIsLooping: (looping) => set({ isLooping: looping }),
  setBpm: (bpm) => set({ bpm: Math.max(20, Math.min(300, bpm)) }),
  setCurrentTime: (time) => set({ currentTime: time }),
  setMasterVolume: (volume) => set({ masterVolume: Math.max(0, Math.min(1, volume)) }),

  // Synth actions
  setActiveSynthPreset: (preset) => set({ activeSynthPreset: preset }),
  setActiveOctave: (octave) => set({ activeOctave: Math.max(1, Math.min(7, octave)) }),
  setActiveNotes: (notes) => set({ activeNotes: notes }),
  addActiveNote: (note) =>
    set((state) => {
      const newNotes = new Set(state.activeNotes);
      newNotes.add(note);
      return { activeNotes: newNotes };
    }),
  removeActiveNote: (note) =>
    set((state) => {
      const newNotes = new Set(state.activeNotes);
      newNotes.delete(note);
      return { activeNotes: newNotes };
    }),
  setReverbMix: (mix) => set({ reverbMix: Math.max(0, Math.min(1, mix)) }),
  setDelayMix: (mix) => set({ delayMix: Math.max(0, Math.min(1, mix)) }),
  setAttack: (attack) => set({ attack: Math.max(0.001, Math.min(5, attack)) }),
  setRelease: (release) => set({ release: Math.max(0.01, Math.min(5, release)) }),
  setFilterFreq: (freq) => set({ filterFreq: Math.max(100, Math.min(20000, freq)) }),

  // Track actions
  addTrack: (track) => {
    const id = `track-${++trackIdCounter}`;
    const colorIndex = get().tracks.length % TRACK_COLORS.length;
    const newTrack: AudioTrack = {
      ...track,
      id,
      color: TRACK_COLORS[colorIndex],
      loops: [],
    };
    set((state) => ({ tracks: [...state.tracks, newTrack] }));
    return id;
  },
  removeTrack: (id) =>
    set((state) => ({
      tracks: state.tracks.filter((t) => t.id !== id),
      selectedTrackId: state.selectedTrackId === id ? null : state.selectedTrackId,
    })),
  updateTrack: (id, updates) =>
    set((state) => ({
      tracks: state.tracks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    })),
  setSelectedTrackId: (id) => set({ selectedTrackId: id }),

  // Loop actions
  addLoopRegion: (trackId, loop) => {
    const id = `loop-${++loopIdCounter}`;
    const colorIndex = loopIdCounter % LOOP_COLORS.length;
    const newLoop: LoopRegion = { ...loop, id, color: LOOP_COLORS[colorIndex] };
    set((state) => ({
      tracks: state.tracks.map((t) =>
        t.id === trackId ? { ...t, loops: [...t.loops, newLoop] } : t
      ),
    }));
  },
  removeLoopRegion: (trackId, loopId) =>
    set((state) => ({
      tracks: state.tracks.map((t) =>
        t.id === trackId ? { ...t, loops: t.loops.filter((l) => l.id !== loopId) } : t
      ),
    })),
  updateLoopRegion: (trackId, loopId, updates) =>
    set((state) => ({
      tracks: state.tracks.map((t) =>
        t.id === trackId
          ? {
              ...t,
              loops: t.loops.map((l) => (l.id === loopId ? { ...l, ...updates } : l)),
            }
          : t
      ),
    })),
  toggleLoopRegion: (trackId, loopId) =>
    set((state) => ({
      tracks: state.tracks.map((t) =>
        t.id === trackId
          ? {
              ...t,
              loops: t.loops.map((l) => (l.id === loopId ? { ...l, enabled: !l.enabled } : l)),
            }
          : t
      ),
    })),

  // Metronome
  setMetronomeOn: (on) => set({ metronomeOn: on }),

  // Recording
  addRecordedNote: (note) =>
    set((state) => ({ recordedNotes: [...state.recordedNotes, note] })),
  clearRecordedNotes: () => set({ recordedNotes: [] }),

  // UI
  setShowMixer: (show) => set({ showMixer: show }),
  setShowLoopPanel: (show) => set({ showLoopPanel: show }),
  setWaveformData: (trackId, data) =>
    set((state) => {
      const newCache = new Map(state.waveformsCache);
      newCache.set(trackId, data);
      return { waveformsCache: newCache };
    }),
  setTracks: (tracks) => set({ tracks }),

  // Reset
  reset: () =>
    set({
      isPlaying: false,
      isRecording: false,
      isLooping: false,
      currentTime: 0,
      activeNotes: new Set(),
      recordedNotes: [],
      selectedTrackId: null,
    }),
}));
