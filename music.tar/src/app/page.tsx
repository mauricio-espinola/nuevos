'use client';

import React from 'react';
import { useDawStore } from '@/store/daw-store';
import TransportBar from '@/components/daw/TransportBar';
import SynthSelector from '@/components/daw/SynthSelector';
import TrackView from '@/components/daw/TrackView';
import Piano from '@/components/daw/Piano';
import Mixer from '@/components/daw/Mixer';
import LoopPanel from '@/components/daw/LoopPanel';
import { RecordingsPanel } from '@/components/daw/RecordingsPanel';
import { TrackAudioPlayer } from '@/components/daw/AudioPlayer';

// Store to keep track of blob URLs
const trackUrls: Map<string, string> = new Map();

export default function Home() {
  const { showMixer, showLoopPanel, tracks, setWaveformData, addTrack } = useDawStore();

  // Create blob URLs for tracks that have files
  React.useEffect(() => {
    for (const track of tracks) {
      if (track.file && !trackUrls.has(track.id)) {
        trackUrls.set(track.id, URL.createObjectURL(track.file));
      }
    }
  }, [tracks]);

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-zinc-950 text-zinc-100">
      {/* Transport Bar */}
      <TransportBar />

      {/* Main Content Area */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left Panel - Synth Selector */}
        <SynthSelector />

        {/* Center - Track View */}
        <TrackView />
      </div>

      {/* Audio Players (invisible - for playback) */}
      {tracks.map((track) => {
        const url = trackUrls.get(track.id);
        if (!url) return null;
        return <TrackAudioPlayer key={track.id} trackId={track.id} url={url} />;
      })}

      {/* Bottom Panels */}
      <div className="flex flex-col">
        {/* Recordings */}
        <RecordingsPanel />

        {/* Loop Panel */}
        {showLoopPanel && <LoopPanel />}

        {/* Mixer */}
        {showMixer && <Mixer />}

        {/* Piano */}
        <Piano />
      </div>
    </div>
  );
}
